import { AsignaFuncionarioZona } from "./asignafuncionariozona";
import { FuncionarioDisponible } from "./funcionariodisponible";
import { Zona } from "./zona";

export class DetalleAsignafuncionarioZona {
  numDetalle: number;
  asignacion: AsignaFuncionarioZona;
  zona: Zona;
  funcionarios: FuncionarioDisponible[];
  cantidadFuncionarios: number;
  constructor() { }
}
