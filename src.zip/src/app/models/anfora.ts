import { Datacatalogo } from "./datacatalogo";
import { CabDeclara } from "./cabDeclara";
export class Anfora {
    tipoAnfora: Datacatalogo;    
    numeroCargaLaboral: number;
    numCorreDoc: number;
    indImpoFrecuente:number;
    desImpoFrecuente:string;
    cabDeclara: CabDeclara;
    fechaInclusionDesc: Date;
    tipoDocImportadorDua: string;
    numDocumentoImportadorDua: string;
    constructor() { }
  }