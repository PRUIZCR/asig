import { Anfora } from "./anfora";
import { Sorteo } from "./sorteo";
import { MatTableDataSource} from '@angular/material';
import { CabDeclara } from "./cabDeclara";
import { SelectionModel } from '@angular/cdk/collections';
import { CatEmpleado } from './catempleado';

export class TmpPaquete {
    numPaquete: number;
    numeroSecuenciaPaqueteAnfora:number;
    codigoFuncionario:string;
    cargaLaboralPaquete: number;
    desHorario: string;
    sorteo: Sorteo;
    fecPP:Date;
    codigoTipoLugarCoordinacion: string;
    codigoLugarCoordinacion:string;
    listaDuasAnfora: Anfora[];
    cabDeclara: CabDeclara;
    catEmpleado: CatEmpleado;
    nombreFuncionario: string;
    anforaDS: MatTableDataSource<Anfora>;
    allSelected:boolean;
    selection: SelectionModel<Anfora>;
    numAgrupa: number;
    codigoEstadoPaquete: string;
    detallesPaquete: TmpPaquete[];

    constructor() { }
  }
