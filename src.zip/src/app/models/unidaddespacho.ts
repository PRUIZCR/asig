import { Datacatalogo } from "./datacatalogo";

export class Unidaddespacho {
  numUnidadDespacho: number;
  descripcion: string;
  indSorteoFuncionarioZona: string;
  regimenes: Datacatalogo[];
  fecInicioVigencia: Date;
  fecFinVigencia: Date;
  aduana: Datacatalogo;

  constructor() { }
}
