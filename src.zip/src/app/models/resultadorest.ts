export class ResultadoRest {
  responseAsJson: string;
  successful: boolean;
  constructor() { }
}
