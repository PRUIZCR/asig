import { UnidadSeleccion } from './unidadseleccion';

export class UnidadSeleccionDAM {
  numeroCorrelativoDAM: number;
  aduanaDAM: string;
  anioDAM: number;
  regimenDAM: string;
  numeroDAM: string;
  parcialDAM: number;
  indicadorSINI: boolean;
  indicadorPARCIAL: boolean;
  existeProgramacion: boolean;
  asignada: boolean;
  unidadesSeleccion: UnidadSeleccion[];
  aduanaAsignacion: string;
  unidadSeleccionada: string;
  corrUnidSelecAnfora: number;
  constructor() { }
}
