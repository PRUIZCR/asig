import { ReporteHorario } from './reportehorario';

export class ReporteAsignacion {
  codAnfora: string;
  fechaDesde: Date;
  strFechaDesde: string;
  fechaHasta: Date;
  strFechaHasta: string;
  rucAlmacen: string;
  codFuncionario: string;
  numTurno: number;
  numHorario: number;
  numSorteo: number;
  listaReporteHorarios: ReporteHorario[];

  cosntructor() { }
}
