import { Unidaddespacho } from "./unidaddespacho";
import { Zona } from "./zona";

export class Turno {
  numTurno: number;
  unidadDespacho: Unidaddespacho;
  nombre: string;
  hraInicio: string;
  hraFin: string;
  hraCorte: string;
  zonas: Zona[];
  fecInicioVigencia: Date;
  fecFinVigencia: Date;
  indPermanente: string;
  constructor() { }
}
