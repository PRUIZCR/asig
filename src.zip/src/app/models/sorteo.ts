import { Datacatalogo } from "./datacatalogo";
import { Horariosorteo } from "./horariosorteo";
import { Turno } from "./turno";

export class Sorteo {
  numeroSorteo: number;
  aduana: Datacatalogo;
  regimen: string;
  anfora: Datacatalogo;
  fechaInicioVigencia: Date;
  fechaFinVigencia: Date;
  cantidadSorteos: number;
  numeroCargaMaxima: any;
  horarios: Horariosorteo[];
  indicadorEliminacion: string;
  detalleSorteo: Horariosorteo;
  fechaInicioVigText: string;
  fechaFinVigText: string;
  annioSorteo: number;
  numeroOrdenSorteo: number;
  codigoUsuarioRegistro: string;
  fechaUsuarioRegistro: Date;
  nombreUsuarioRegistro: string;
  fechaUsuarioRegistroText: string;
  turno: Turno;
  indIncluirFeriado: string;
  tipoSorteo: string;
  numMinutosIntervalo: number;
  esProcesoSalida: boolean;
  constructor() { }
}
