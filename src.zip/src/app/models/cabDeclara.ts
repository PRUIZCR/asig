import { Datacatalogo } from "./datacatalogo";
export class CabDeclara {
    numDeclaracion: number;
    numCorreDoc: number;
    aduana: Datacatalogo;
    regimen: Datacatalogo;
    rsocialAlmacenAduanero:string;
    dirAlmacenAduanero: string;
    desGarantia160:string;
    desRiesgoOea: string;
    annPresen: string;
    codLocalAnexo: string;
    serie: string;
    fraude: string;
    detalle: string;
    constructor() { }
  }