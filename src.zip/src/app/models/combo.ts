export class Combo {
  value: string;
  text: string;

  constructor() { }
}
