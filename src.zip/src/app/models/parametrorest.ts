export class ParametroRest{
  numeroOrden: number;
  descripcion: string;
  clase: string;
  nombre: string;
  tipoParametro: string;
}
