import { Datacatalogo } from "./datacatalogo";
import { Unidaddespacho } from "./unidaddespacho";

export class CriterioAsigEspe {
  criterio: Datacatalogo;
  aduana: Datacatalogo;
  regimen: Datacatalogo;
  fecIniVig: Date;
  fecFinVig: Date;
  porCriterio: any;
  numIniCap: string;
  numFinCapitulo: string;
  numParArancel: string;
  cntPeso: number;
  obsObs: string;
  fecIniVigText: string;
  fecFinVigText: string;
  tipoCriterio: Datacatalogo;
  historial: CriterioAsigEspe[];
  unidadDespacho: Unidaddespacho;
  detallesCriterio: CriterioAsigEspe[];
  nombreCriterio: string;
  verHistorial: number;
  codUsuarioModifica: string;
  fechaModifica: Date;
  constructor() { };
}
