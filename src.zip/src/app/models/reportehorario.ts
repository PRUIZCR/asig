import { Datacatalogo } from './datacatalogo';
import { Sorteo } from './sorteo';
import { TmpPaquete } from './TmpPaquete';

export class ReporteHorario {
  aduana: Datacatalogo;
  anfora: Datacatalogo;
  sorteo: Sorteo;
  horario: string;
  fecha: Date;
  totalPaquetes: number;
  listDetallePaquetes: TmpPaquete[];

  constructor() { }
}
