export class TipFun {
  codTipFunc: string;
  constructor() { }
}
