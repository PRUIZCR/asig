export class TipCargoFun {
  codTipCargoFun: string;
  constructor() { }
}
