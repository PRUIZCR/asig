export class Usuariobean {
  id: string;
  ticket: string;
  login: string;
  correo: string;
  nombres: string;
  apePaterno: string;
  apeMaterno: string;
  nombreCompleto: string;
  nroRegistro: string;
  codUO: string;
  desUO: string;
  codCate: string;
  desCate: string;
  nivelUO: number;
  numRUC: string;
  usuarioSOL: string;
  codDepend: string;
  idCelular: string;
  codTOpeComer: string;
  map: Map<string,any>;

  constructor() { }
}
