import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { FuncionesGenerales } from '../utils/funcionesgenerales';
import { ConstantesRest } from '../utils/constantesrest';
import { catchError } from 'rxjs/operators';

@Injectable({
    providedIn: 'root'
  })
export class HorarioService {
    constructor(private http: HttpClient) { }

    obtenerhorarios(codAnfora: string,
                    numeroTurno: string,
                    fechaConsulta: Date,
                    tipoConsulta: number,
                    fechaFin: Date): Observable<any>{
        return this.http.get<HttpResponse<Object>>(
            FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_LISTAR_HORARIO,
                                                                  codAnfora,
                                                                  numeroTurno,
                                                                  fechaConsulta,
                                                                  tipoConsulta,
                                                                  fechaFin)).pipe(
                catchError(e=>{
                    return throwError(e.error);
                })
            );
    }
}
