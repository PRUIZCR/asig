import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { GrupoAlmacen } from '../models/grupoalmacen';
import { FuncionesGenerales } from '../utils/funcionesgenerales';
import { ConstantesRest } from '../utils/constantesrest';
import { catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AlmacenService {

  constructor(private http: HttpClient) { }

  listarAlmacenes(numUnidadDespacho: number) {
    return this.http.get<GrupoAlmacen[]>(FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_LISTAR_LUGARES_RECONOCIMIENTO, numUnidadDespacho));
  }

  registrarAlmacenes(almacenes: GrupoAlmacen[], numUnidadDespacho: number): Observable<any> {
    return this.http.put<HttpResponse<Object>>(FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_GRABAR_LUGARES_RECONOCIMIENTO, numUnidadDespacho),
                                                almacenes, { observe: 'response' }).pipe(
        catchError(e => {
          return throwError(e.error);
        })
      );
  }
}
