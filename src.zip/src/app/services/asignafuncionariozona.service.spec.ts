import { TestBed } from '@angular/core/testing';

import { AsignaFuncionarioZonaService } from './asignafuncionariozona.service';

describe('AsignaFuncionarioZonaService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AsignaFuncionarioZonaService = TestBed.get(AsignaFuncionarioZonaService);
    expect(service).toBeTruthy();
  });
});
