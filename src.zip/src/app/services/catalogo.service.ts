import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ConstantesRest } from '../utils/constantesrest';
import { Datacatalogo } from '../models/datacatalogo';
import { FuncionesGenerales } from '../utils/funcionesgenerales';
import { Usuariobean } from '../models/usuariobean';
import { ConstantesCadenas } from '../utils/constantescadenas';


@Injectable({
  providedIn: 'root'
})

export class CatalogoService {

  constructor(private http: HttpClient) { }

  listarAduanas(filtroSolicitudRF?: string) {
    filtroSolicitudRF = filtroSolicitudRF == undefined || filtroSolicitudRF.trim() == '' ? '' : filtroSolicitudRF;
    let usuario: Usuariobean = JSON.parse(sessionStorage.getItem('usuariobean'));
    let roles: string = sessionStorage.getItem('roles');
    return this.http.get<any>(FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_LISTAR_ADUANAS, usuario.codUO, roles, filtroSolicitudRF));
  }

  listarAnforas(numUnidadDespacho: number) {
    return this.http.get<Datacatalogo[]>(FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_LISTAR_ANFORAS, numUnidadDespacho));
  }

  listarGruposTrabajo() {
    let roles: string = sessionStorage.getItem('roles');
    return this.http.get<Datacatalogo[]>(FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_LISTAR_GRUPOS_TRABAJO, roles));
  }

  listarRegimenes() {
    return this.http.get<Datacatalogo[]>(ConstantesRest.URL_LISTAR_REGIMENES);
  }

  listarOperacionesManuales() {
    let roles: string = sessionStorage.getItem('roles');
    let tipo = sessionStorage.getItem('pagina') == 'asignacion-manual' ? ConstantesCadenas.TIPO_OPERACION_ASIGNACION : ConstantesCadenas.TIPO_OPERACION_REASIGNACION;
    return this.http.get<Datacatalogo[]>(FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_LISTAR_OPERACIONES_MANUALES, tipo, roles));
  }

  listarRegimenesOperacionesManuales(tipoOperacion: string) {
    return this.http.get<Datacatalogo[]>(FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_LISTAR_REGIMENES_OPERACION, tipoOperacion));
  }
}
