import { Injectable } from '@angular/core';
import { FuncionarioDisponible } from '../models/funcionariodisponible';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ConstantesRest } from '../utils/constantesrest';
import { HttpResponse, HttpClient } from '@angular/common/http';
import { FuncionesGenerales } from '../utils/funcionesgenerales';

@Injectable({
  providedIn: 'root'
})
export class CatalogofuncionarioService {

  constructor(private http: HttpClient) { }

  registrarCatalogoFuncionario(objFuncionario: FuncionarioDisponible[], numTurno: number, param2: string, fecha1: Date, fecha2: Date): Observable<any> {
    return this.http.post<HttpResponse<Object>>(
      FuncionesGenerales.getInstance().reemplazarParametros(
        ConstantesRest.URL_GRABAR_CATALOGO_FUNCIONARIOS,
        numTurno,
        param2,
        fecha1,
        fecha2
      ), objFuncionario,
      { observe: 'response' }).pipe(
      catchError(e => {
        return throwError(e.error);
      })
    );
  }

  reporteCatalogoFuncionarios(tipoRegistro: string,
                              unidadDespacho: string,
                              turno: string,
                              grupoFuncionario: string,
                              fechaVigenteDesde: Date,
                              fechaVigenteHasta: Date,
                              campos: string) {
  return this.http.get<any>(FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_EXPORTAR_REPORTE_CATALOGO_FUNCIONARIOS,
                                                                                    tipoRegistro,
                                                                                    unidadDespacho,
                                                                                    turno,
                                                                                    grupoFuncionario,
                                                                                    fechaVigenteDesde,
                                                                                    fechaVigenteHasta, "", campos)).pipe(
      catchError(e => {
        return throwError(e.error);
      })
    );
  }

  reporteCatalogoAsignacionFuncionarios(tipoRegistro: string,
                                        unidadDespacho: string,
                                        fechaVigenteDesde: Date,
                                        fechaVigenteHasta: Date,
                                        codigoFuncionario: string,
                                        campos: string) {
      return this.http.get<any>(FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_EXPORTAR_REPORTE_CATALOGO_FUNCIONARIOS,
                                                                                      tipoRegistro,
                                                                                      unidadDespacho,
                                                                                      '-1',
                                                                                      '',
                                                                                      fechaVigenteDesde,
                                                                                      fechaVigenteHasta,
                                                                                      codigoFuncionario, campos)).pipe(
        catchError(e => {
          return throwError(e.error);
        })
      );
  }
}
