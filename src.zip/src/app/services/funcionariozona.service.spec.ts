import { TestBed } from '@angular/core/testing';

import { FuncionariozonaService } from './funcionariozona.service';

describe('FuncionariozonaService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FuncionariozonaService = TestBed.get(FuncionariozonaService);
    expect(service).toBeTruthy();
  });
});
