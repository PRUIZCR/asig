import { TestBed } from '@angular/core/testing';

import { FuncionariosdisponiblesService } from './funcionariosdisponibles.service';

describe('FuncionariosdisponiblesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FuncionariosdisponiblesService = TestBed.get(FuncionariosdisponiblesService);
    expect(service).toBeTruthy();
  });
});
