import { TestBed } from '@angular/core/testing';

import { UnidaddespachoService } from './unidaddespacho.service';

describe('UnidaddespachoService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UnidaddespachoService = TestBed.get(UnidaddespachoService);
    expect(service).toBeTruthy();
  });
});
