import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ServicioRest } from '../models/serviciorest';
import { FuncionesGenerales } from '../utils/funcionesgenerales';
import { ConstantesRest } from '../utils/constantesrest';
import { ConstantesCadenas } from '../utils/constantescadenas';

@Injectable({
  providedIn: 'root'
})
export class ManualService {

  constructor(private http: HttpClient) { }

  validarOperacionManual(tipoOperacion: string, tipoServicio: string){
    console.log("tipoOperacion: " + tipoOperacion + " - tipoServicio: " + tipoServicio);
    return this.http.get<ServicioRest>(FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_OBTENER_SERVICIO_REST, tipoOperacion, tipoServicio));
  }

  ejecutarServicioRest(servicio: ServicioRest, tipoMetodoHttp: string, ...parametros: any[]){
    //Los parametros deben de ser enviados en orden considerando: PATH_VARIABLE, REQUEST_PARAM, REQUEST_HEADER, REQUEST_BODY
    let paramsPath = servicio.parametros.filter(param => (param.tipoParametro == ConstantesCadenas.TIPO_PARAMETRO_REST_PATH_VARIABLE));
    let paramsReq = servicio.parametros.filter(param => (param.tipoParametro == ConstantesCadenas.TIPO_PARAMETRO_REST_REQUEST_PARAM));
    let paramsHead = servicio.parametros.filter(param => (param.tipoParametro == ConstantesCadenas.TIPO_PARAMETRO_REST_REQUEST_HEADER));
    let paramsBody = servicio.parametros.filter(param => (param.tipoParametro == ConstantesCadenas.TIPO_PARAMETRO_REST_REQUEST_BODY));
    let cantParamPath = (paramsPath != null && paramsPath != undefined && paramsPath.length > 0) ? paramsPath.length : 0;
    let cantParamReq = (paramsReq != null && paramsReq != undefined && paramsReq.length > 0) ? paramsReq.length : 0;
    let cantParamHead = (paramsHead != null && paramsHead != undefined && paramsHead.length > 0) ? paramsHead.length : 0;
    let cantParamBody = (paramsBody != null && paramsBody != undefined && paramsBody.length > 0) ? paramsBody.length : 0;
    let url = servicio.url;
    let incIdx = parametros.length != cantParamReq ? 1 : 0;
    for(let _i = 0; _i < cantParamPath + cantParamReq; _i++)
      url = url.replace("{" + _i + "}", parametros[_i + incIdx]);
    let headers: HttpHeaders = new HttpHeaders();
    if(cantParamHead > 0)
      for(let _i = 0; _i < cantParamHead; _i++)
        headers.set(paramsHead[_i].nombre, parametros[_i] + cantParamPath + cantParamReq);
    let paramBody = cantParamBody > 0 ? parametros[parametros.length - 1] : null;
    switch(tipoMetodoHttp){
      case ConstantesCadenas.METHOD_HTTP_GET:
        return this.http.get<any>(url, { headers: headers });
      case ConstantesCadenas.METHOD_HTTP_POST:
        return paramBody != null ? this.http.post<any>(url, paramBody, { headers: headers }) : this.http.post<any>(url, { headers: headers });
      case ConstantesCadenas.METHOD_HTTP_PUT:
        return paramBody != null ? this.http.put<any>(url, paramBody, { headers: headers }) : this.http.put<any>(url, { headers: headers });
    }
    return null;
  }
}
