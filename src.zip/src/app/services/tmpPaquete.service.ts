import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { ConstantesRest } from 'src/app/utils/constantesrest';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { TmpPaquete } from 'src/app/models/TmpPaquete';

@Injectable({
    providedIn: 'root'
  })

export class TmpPaqueteService {
  constructor(private http: HttpClient) { }

  obtenerDetallesPaquetes(numeroSorteo: number,
                          numSecHorario: number,
                          codAnfora: string,
                          tipoConsulta:number,
                          fecha: Date,
                          fechaHasta: Date,
                          rucAlmacen: string,
                          turno: number,
                          codigoRegistro: string) : Observable<any> {
      return this.http.get<HttpResponse<Object>>(FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_OBTENER_DETALLES_PAQUETE,
                                                                                      numeroSorteo,
                                                                                      numSecHorario,
                                                                                      codAnfora,
                                                                                      tipoConsulta,
                                                                                      fecha, rucAlmacen, fechaHasta, turno, codigoRegistro, { observe: 'response' })).pipe(
        catchError(e => {
          return throwError(e.error);
        })
      );
    }

    registrarOptimizacionPaquetes(objNumSorteo:number,
                                  objNumHorario:number,
                                  objFechaFormacionPaquete:string,
                                  objListaPaquetes: TmpPaquete[]) : Observable<any> {
      return this.http.post<HttpResponse<Object>>(FuncionesGenerales.getInstance().reemplazarParametros(
        ConstantesRest.URL_GRABAR_OPTIMIZACION_PAQUETES,
        objNumSorteo,
        objNumHorario,
        objFechaFormacionPaquete),
        objListaPaquetes,
        { observe: 'response' }).pipe(
        catchError(e => {return throwError(e.error);})
      );
    }

    consultarPaquetesFormados(codAnfora: string,
                              numTurno: number,
                              fecInicio: Date,
                              fecFin: Date) {
        return this.http.get<any>(FuncionesGenerales.getInstance().reemplazarParametros(
                                                                                        ConstantesRest.URL_CONSULTA_PAQUETES_FORMADOS,
                                                                                        codAnfora,
                                                                                        numTurno,
                                                                                        fecInicio,
                                                                                        fecFin, {observe: 'response' })).pipe(
          catchError(e => {
            return throwError(e.error);
          })
        );
    }
  }
