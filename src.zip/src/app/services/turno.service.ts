import { Injectable } from '@angular/core';
import { Turno } from 'src/app/models/turno';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { ConstantesRest } from 'src/app/utils/constantesrest';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TurnoService {

  constructor(private http: HttpClient) { }

  registrarActualizarTurno(objTurno: Turno): Observable<any> {
    return this.http.post<HttpResponse<Object>>(FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_GRABAR_TURNO, "1"),
      objTurno, { observe: 'response' }).pipe(
        catchError(e => {
          return throwError(e.error);
        })
      );
  }

  listarTurnos(unidadDespachoSeleccionado: string,
               estadoSeleccionado: string,
               fechaVigenteDesde: string,
               fechaVigenteHasta: string,
               campos: string,
               tipoValidacionRango?: string,
               indPermanente?: string) {
   tipoValidacionRango = tipoValidacionRango == undefined || tipoValidacionRango == null ? "" :  tipoValidacionRango;
   indPermanente = indPermanente == undefined || indPermanente == null ? "" : indPermanente;
   return this.http.get<Turno[]>(FuncionesGenerales.getInstance().reemplazarParametros(
     ConstantesRest.URL_LISTAR_TURNO,
     unidadDespachoSeleccionado,
     estadoSeleccionado,
     fechaVigenteDesde,
     fechaVigenteHasta,
     tipoValidacionRango,
     indPermanente,
     campos));
  }
}
