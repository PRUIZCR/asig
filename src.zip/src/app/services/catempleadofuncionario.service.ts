import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { ConstantesRest } from 'src/app/utils/constantesrest';
import { catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class CatempleadofuncionarioService {

  constructor(private http: HttpClient) { }

  obtenerAsignacionesFuncionario(tipoRegistro: string,
                              unidadDespacho: string,
                              fechaVigenteDesde: Date,
                              fechaVigenteHasta: Date,
                              codigoFuncionario: string) : Observable<any> {
    return this.http.get<HttpResponse<Object>>(FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_LISTAR_CATALOGO_FUNCIONARIOS,
                                                                                    tipoRegistro,
                                                                                    unidadDespacho,
                                                                                    '-1',
                                                                                    '',
                                                                                    fechaVigenteDesde,
                                                                                    fechaVigenteHasta,
                                                                                    codigoFuncionario,  { observe: 'response' })).pipe(
      catchError(e => {
        return throwError(e.error);
      })
    );
  }

}
