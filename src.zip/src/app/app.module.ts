import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainUnidadDespachoComponent } from './components/unidaddespacho/main/main-unidad-despacho.component';
import { MantenimientoUnidadDespachoComponent } from './components/unidaddespacho/mantenimiento/mantenimiento-unidad-despacho.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { registerLocaleData } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import localeES from '@angular/common/locales/es';
import { ModalModule } from 'ngx-bootstrap/modal';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { MatNativeDateModule,
         MatCheckboxModule,
         MatSortModule,
         MatPaginatorModule,
         MatPaginatorIntl,
         MatCardModule,
         MatProgressSpinnerModule } from '@angular/material';
import { FormsModule } from '@angular/forms';
import { DateAdapter, MAT_DATE_FORMATS } from "@angular/material";
import { AppDateAdapter} from 'src/app/adapters/date.adapter';
import { ConstantesObjetos} from 'src/app/utils/constantesobjetos';
import { MainZonaComponent } from './components/zona/main/main-zona.component';
import { MantenimientoZonaComponent } from './components/zona/mantenimiento/mantenimiento-zona.component';
import { NgxMaterialTimepickerModule } from 'ngx-material-timepicker';
import { MainTurnoComponent } from './components/turno/main/main-turno.component';
import { MantenimientoTurnoComponent } from './components/turno/mantenimiento/mantenimiento-turno.component';
import { ConsultaCriterioComponent } from './components/criterio/consulta/consulta-criterio.component';
import { MDBBootstrapModule } from 'angular-bootstrap-md';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatRadioModule } from '@angular/material/radio';
import { ListaCriterioComponent } from './components/criterio/lista/lista-criterio.component';
import { PonderacionCriterioComponent } from './components/criterio/ponderacion/ponderacion-criterio.component';
import { PonderacionHistoricoComponent } from './components/criterio/ponderacion-historico/ponderacion-historico.component';
import { MainAlmacenComponent } from './components/almacen/main/main-almacen.component';
import { MainFuncionariosComponent } from './components/catalogofuncionarios/main/main-funcionarios.component';
import { FullCalendarModule } from 'ng-fullcalendar';
import { MatIconModule} from '@angular/material';
import { ConsultaSeleccionfuncionariosComponent } from './components/seleccionfuncionarios/consulta/consulta-seleccionfuncionarios.component';
import { TurnoFuncionariosComponent } from './components/catalogofuncionarios/turno/turno-funcionarios.component';
import { ConsultaFuncionarioZonaComponent } from './components/asignacionfuncionarios/consulta-funcionario-zona/consulta-funcionario-zona.component';
import { AsignacionFuncionarioZonaComponent } from './components/asignacionfuncionarios/asignacion-funcionario-zona/asignacion-funcionario-zona.component';
import { FuncionarioAsignadoZonaComponent } from './components/asignacionfuncionarios/funcionario-asignado-zona/funcionario-asignado-zona.component';
import { OptimizacionPaquetesComponent } from './components/optimizacion-paquetes/main/optimizacion-paquetes.component'
import { MainSorteoComponent } from './components/sorteo/main/main-sorteo.component';
import { ConsultaSorteoComponent } from './components/sorteo/consulta/consulta-sorteo.component';
import { InterceptorService } from './interceptors/interceptor.service';
import { ListaPaqueteComponent } from './components/optimizacion-paquetes/lista-paquete/lista-paquete.component';
import { AppPaginatorEs } from './internationalization/paginator-es';
import { MainManualComponent } from './components/manual/main/main-manual.component';
import { ReasignacionBloqueComponent } from './components/reasignacion-bloque/main/reasignacion-bloque.component';
import { DetalleManualComponent } from './components/manual/detalle/detalle-manual.component';
import { ReporteAsignacionBloqueComponent } from './components/reporteasignacionbloque/reporte/reporte-asignacion-bloque.component';
import { ListaAsignacionBloqueComponent } from './components/reporteasignacionbloque/lista/lista-asignacion-bloque.component';
import { DetalleAsignacionBloqueComponent } from './components/reporteasignacionbloque/detalle/detalle-asignacion-bloque.component';
import { ConsultaPaquetesFormadosComponent } from './components/paquetes-formados/consulta/consulta-paquetes-formados.component';
import { DetallePaquetesFormadosComponent } from './components/paquetes-formados/detalle/detalle-paquetes-formados.component';
import { ConsultaFuncionariosComponent } from './components/catalogofuncionarios/consulta/consulta-funcionarios.component';

registerLocaleData(localeES, 'es');

const routes: Routes = [
  { path: '**', redirectTo: sessionStorage.getItem('pagina'), pathMatch: 'full' }
];

@NgModule({
  declarations: [
    AppComponent,
    MainUnidadDespachoComponent,
    MantenimientoUnidadDespachoComponent,
    MainZonaComponent,
    MantenimientoZonaComponent,
    MainTurnoComponent,
    MainSorteoComponent,
    MantenimientoTurnoComponent,
    ConsultaCriterioComponent,
    ListaCriterioComponent,
    PonderacionCriterioComponent,
    PonderacionHistoricoComponent,
    MainAlmacenComponent,
    MainFuncionariosComponent,
    ConsultaSeleccionfuncionariosComponent,
    OptimizacionPaquetesComponent,
    TurnoFuncionariosComponent,
    ConsultaFuncionarioZonaComponent,
    AsignacionFuncionarioZonaComponent,
    FuncionarioAsignadoZonaComponent,
    TurnoFuncionariosComponent,
    ConsultaSorteoComponent,
    MainManualComponent,
    ListaPaqueteComponent,
    ReasignacionBloqueComponent,
    DetalleManualComponent,
    ReporteAsignacionBloqueComponent,
    ListaAsignacionBloqueComponent,
    DetalleAsignacionBloqueComponent,
    ConsultaPaquetesFormadosComponent,
    DetallePaquetesFormadosComponent,
    ConsultaFuncionariosComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ModalModule.forRoot(),
    BrowserAnimationsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatCheckboxModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    FormsModule,
    RouterModule.forRoot(routes),
    NgxMaterialTimepickerModule,
    MDBBootstrapModule.forRoot(),
    MatExpansionModule,
    MatTabsModule,
    FullCalendarModule,
    MatRadioModule,
    MatIconModule,
    MatCardModule,
    MatProgressSpinnerModule
  ],
  exports: [MatSortModule, MatPaginatorModule],
  providers: [{ provide: HTTP_INTERCEPTORS, useClass: InterceptorService, multi: true },
              { provide: DateAdapter, useClass: AppDateAdapter },
              { provide: MAT_DATE_FORMATS, useValue: ConstantesObjetos.APP_DATE_FORMATS },
              { provide: MatPaginatorIntl, useClass: AppPaginatorEs }],

  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
