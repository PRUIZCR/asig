import { Observable } from 'rxjs/Observable';
import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { Unidaddespacho } from 'src/app/models/unidaddespacho';
import { Datacatalogo } from 'src/app/models/datacatalogo';
import { ConstantesListas } from 'src/app/utils/constanteslistas';
import { ConstantesCadenas } from 'src/app/utils/constantescadenas';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { setTheme } from 'ngx-bootstrap/utils';
import { MatTableDataSource } from '@angular/material';
import { MatSort  } from '@angular/material/sort';
import { MatPaginator  } from '@angular/material/paginator';
import { MantenimientoUnidadDespachoComponent } from 'src/app/components/unidaddespacho/mantenimiento/mantenimiento-unidad-despacho.component';
import { CatalogoService } from 'src/app/services/catalogo.service';
import { UnidaddespachoService } from 'src/app/services/unidaddespacho.service';

@Component({
  selector: 'app-main-unidad-despacho',
  templateUrl: './main-unidad-despacho.component.html',
  styleUrls: ['./main-unidad-despacho.component.css']
})
export class MainUnidadDespachoComponent implements OnInit, AfterViewInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MantenimientoUnidadDespachoComponent) child: MantenimientoUnidadDespachoComponent;
  funcionesGenerales: FuncionesGenerales;
  dataTable: any;
  aduanas: Datacatalogo[];
  estados: Datacatalogo[];
  estadoSeleccionado: string;
  aduanaSeleccionada: string;
  lstUnidadDespacho: Unidaddespacho[];
  desabilitarBotonUD: boolean = false;
  objAduanaSeleccionada: Datacatalogo;
  unidadDespacho: Unidaddespacho;
  displayedColumns: string[];
  unidadesDespachoDS : MatTableDataSource<Unidaddespacho>;
  estadoOperacion$: Observable<String>;
  esSoloConsulta: boolean;
  constructor(private catalogoService: CatalogoService,
              private unidadDespachoService: UnidaddespachoService) {
    setTheme('bs4');
  }

  ngOnInit() {
    this.esSoloConsulta = sessionStorage.getItem('esJefeSupervisor') == '0';
    this.catalogoService.listarAduanas().subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.aduanaSeleccionada = result.aduana;
      this.aduanas = result.listaAduanas as Datacatalogo[];
      //if (this.aduanas != null && this.aduanas != undefined && this.aduanas.length > 0) {
      if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.aduanas)) {
        this.cargarControles();
      }
    }, error => console.error(error));

    this.displayedColumns = ConstantesListas.COLUMNAS_GRID_UNIDAD_DESPACHO;
    this.lstUnidadDespacho = [];
    this.unidadesDespachoDS = new MatTableDataSource<Unidaddespacho>(this.lstUnidadDespacho);
    this.funcionesGenerales = FuncionesGenerales.getInstance();
    this.estadoOperacion$ = this.child.getEstadoOperacion$();
    this.estadoOperacion$.subscribe(estado => estado == "X" ? this.cargarUnidadesDespacho() : "");
    this.unidadDespacho = new Unidaddespacho();
    this.unidadDespacho.numUnidadDespacho = -1;
  }

  ngAfterViewInit() {
    this.unidadesDespachoDS.sort = this.sort;
    this.unidadesDespachoDS.paginator = this.paginator;
  }

  cargarControles() {
    this.estados = ConstantesListas.LISTA_ESTADOS;
    this.estadoSeleccionado = ConstantesCadenas.ESTADO_TODOS;
    //this.aduanaSeleccionada = this.aduanas[0].cod_datacat;
    this.objAduanaSeleccionada = this.aduanas.find(element => element.cod_datacat == this.aduanaSeleccionada);
    this.unidadDespacho.aduana = this.objAduanaSeleccionada;
    this.cargarUnidadesDespacho();
  }

  seleccionarAduana(objSeleccionado) {
    this.aduanaSeleccionada = objSeleccionado.target.value;
    if (objSeleccionado.target.value != "") {
      this.objAduanaSeleccionada = this.aduanas.find(element => element.cod_datacat == objSeleccionado.target.value);
      this.unidadDespacho = new Unidaddespacho();
      this.unidadDespacho.numUnidadDespacho = -1;
      this.unidadDespacho.aduana = this.objAduanaSeleccionada;
      this.desabilitarBotonUD = true;
      this.cargarUnidadesDespacho();
    } else {
      this.desabilitarBotonUD = false;
    }
  }

  seleccionarEstado(objSeleccionado) {
    this.estadoSeleccionado = objSeleccionado.target.value;
    this.cargarUnidadesDespacho();
  }

  cargarUnidadesDespacho() {
    let campos: string = "numUnidadDespacho,nombre,indSorteoZona,fecInicio,fecFin,regimenes";
    this.unidadDespachoService.listarUnidadesDespacho(this.aduanaSeleccionada,
                                                      this.estadoSeleccionado,
                                                      campos).subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.lstUnidadDespacho = result as Unidaddespacho[];
      //if (this.aduanaSeleccionada != "" && this.lstUnidadDespacho != null && this.lstUnidadDespacho != undefined) {
      if (this.aduanaSeleccionada != "" && FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.lstUnidadDespacho)) {
        this.lstUnidadDespacho = this.lstUnidadDespacho.sort(FuncionesGenerales.getInstance().ordenarPor("numUnidadDespacho", false));
      } else {
        this.lstUnidadDespacho = [];
        FuncionesGenerales.getInstance().mensajeRegistrosNoEncontrados();
      }
      this.desabilitarBotonUD = true;
      this.unidadesDespachoDS = new MatTableDataSource<Unidaddespacho>(this.lstUnidadDespacho);
      this.unidadesDespachoDS.sort = this.sort;
      this.unidadesDespachoDS.paginator = this.paginator;
    }, error => console.error(error));
  }

  mostrarUnidadDespachoEditable(fecInicioVigencia: Date, fecFinVigencia: Date) {
    let esEditable: boolean = false;
    this.objAduanaSeleccionada = this.aduanas.find(element => element.cod_datacat == this.aduanaSeleccionada);
    /*if (FuncionesGenerales.getInstance().compararFechas(
      FuncionesGenerales.getInstance().formatearFecha(fecInicioVigencia),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
      FuncionesGenerales.getInstance().formatearFecha(fecFinVigencia),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 0) {
        esEditable = true;
    }*/
    if (FuncionesGenerales.getInstance().compararFechas(
      FuncionesGenerales.getInstance().formatearFecha(new Date()),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
      FuncionesGenerales.getInstance().formatearFecha(fecFinVigencia),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 0) {
        esEditable = true;
    }
    return esEditable;
  }

  validarRolUsuarioAutenticado() {
    let esRolUsuario: boolean = true;
    return esRolUsuario;
  }

}
