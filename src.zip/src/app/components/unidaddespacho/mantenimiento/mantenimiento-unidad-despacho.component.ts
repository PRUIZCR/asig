import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { SelectionModel } from '@angular/cdk/collections';
import { Component, OnInit, ViewChild} from '@angular/core';
import { Datacatalogo } from 'src/app/models/datacatalogo';
import { ConstantesListas } from 'src/app/utils/constanteslistas';
import { ConstantesCadenas } from 'src/app/utils/constantescadenas';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { BsModalService, ModalDirective, BsModalRef } from 'ngx-bootstrap/modal';
import { Unidaddespacho } from 'src/app/models/unidaddespacho';
import { MatTableDataSource } from '@angular/material';
import { UnidaddespachoService } from 'src/app/services/unidaddespacho.service';
import { ResponseManager } from 'src/app/models/responsemanager';
import { ResponseErrorManager } from 'src/app/models/responseerrormanager';
import { CatalogoService } from 'src/app/services/catalogo.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'child',
  templateUrl: './mantenimiento-unidad-despacho.component.html',
  styleUrls: ['./mantenimiento-unidad-despacho.component.css']
})

export class MantenimientoUnidadDespachoComponent implements OnInit {
  @ViewChild('childModal') childModal: ModalDirective;
  objUnidadDespacho: Unidaddespacho;
  objUnidadDespachoResponse: Unidaddespacho;
  tituloUnidadDespacho: string;
  dateFormat: Date;
  displayedColumns: string[];
  esFormularioDeRegistro: boolean = false;
  listRegimenes: Datacatalogo[];
  regimenesDS: MatTableDataSource<Datacatalogo>;
  selection: SelectionModel<Datacatalogo>;
  modalAnidado: BsModalRef;
  responseManager: ResponseManager;
  private estadoOperacion$ = new Subject<String>();
  responseErrorManager: ResponseErrorManager;
  esFecIniVigencia: boolean = false;
  btnBotonGrabarUD: boolean = false;
  esfilaDesabilitada: boolean = false;

  constructor(public modalService: BsModalService,
              private catalogoService: CatalogoService,
              private unidadDespachoService: UnidaddespachoService) {
                this.objUnidadDespacho = new Unidaddespacho();
                this.objUnidadDespacho.aduana = new Datacatalogo();
                this.responseManager = new ResponseManager();
              }

  ngOnInit() { }

  validarFechaInicioVigencia() {
    let fechaActual: Date = new Date();
    fechaActual.setHours(0);
    fechaActual.setMinutes(0);
    fechaActual.setSeconds(0);
    if (this.objUnidadDespacho.fecInicioVigencia < fechaActual) {
      this.esFecIniVigencia = true;
    }

    if (fechaActual >= this.objUnidadDespacho.fecInicioVigencia) {
      this.esfilaDesabilitada = true;
    }
  }

  addUnidadDespacho (unidadDespacho: Unidaddespacho,
                     objAduanaSeleccionada: Datacatalogo) {
    this.btnBotonGrabarUD = true;
    this.esfilaDesabilitada = false;
    this.esFecIniVigencia = false;
    this.objUnidadDespacho = FuncionesGenerales.getInstance().clonarObjeto(unidadDespacho);
    if (unidadDespacho.numUnidadDespacho > 0) {
          this.esFormularioDeRegistro = false;
          this.tituloUnidadDespacho = ConstantesCadenas.TITULO_MODIFICAR_UNIDAD_DESPACHO;
          this.objUnidadDespacho.aduana = objAduanaSeleccionada;
          this.objUnidadDespacho.fecInicioVigencia = new Date(unidadDespacho.fecInicioVigencia);
          this.objUnidadDespacho.fecFinVigencia = new Date(unidadDespacho.fecFinVigencia);
          this.validarFechaInicioVigencia();
    } else {
        this.esFormularioDeRegistro = true;
        this.tituloUnidadDespacho = ConstantesCadenas.TITULO_AGREGAR_UNIDAD_DESPACHO;
        this.objUnidadDespacho.descripcion = "";
        this.objUnidadDespacho.indSorteoFuncionarioZona = "0";
        this.objUnidadDespacho.descripcion = "";
        this.objUnidadDespacho.fecInicioVigencia = new Date();
        this.objUnidadDespacho.fecFinVigencia = new Date();
        this.objUnidadDespacho.regimenes = [];
        this.esFecIniVigencia = false;
    }

    this.catalogoService.listarRegimenes().subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.listRegimenes = result as Datacatalogo[];
      this.cargarRegimenes(this.objUnidadDespacho);
    }, error => console.error(error));
    this.childModal.show();
  }

  cargarRegimenes(unidadDespacho: Unidaddespacho) {
    this.displayedColumns = ConstantesListas.COLUMNAS_GRID_REGIMENES;
    this.regimenesDS = new MatTableDataSource<Datacatalogo>(this.listRegimenes);
    this.selection = new SelectionModel<Datacatalogo>(true, []);
    if (unidadDespacho.numUnidadDespacho != 0) {
      for (let i = 0; i < this.regimenesDS.data.length; i++) {
        for (let j = 0; j < this.objUnidadDespacho.regimenes.length; j++) {
          if (this.objUnidadDespacho.regimenes[j].codDatacat == this.regimenesDS.data[i].cod_datacat) {
            this.selection.select(this.regimenesDS.data[i]);
          }
        }
      }
    }
  }

  registrarActualizarUnidadDespacho() {
    this.cargarRegimenesSeleccionados();
    if (!this.validarDatosUnidadDespacho()) {
      return false;
    }

    this.validarServicioUnidadDespacho();
  }

  callback = () : void => {
    this.cerrarUnidadDespacho();
    this.estadoOperacion$.next("X");
  };

  registrarUnidadDespacho(tk: string) {
    this.unidadDespachoService.registrarActualizarUnidadDespacho(this.objUnidadDespacho, tk).subscribe(
      response => {
        console.log(response);
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(
          ConstantesCadenas.MENSAJE_EXITOSO,
          "La Unidad De Despacho se " + (this.objUnidadDespacho.numUnidadDespacho == -1 ? "registro" : "modifico") + " correctamente.",
          "", "", this.callback);
      },
      errorResult => {
        if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
          let responseManager: ResponseManager = new ResponseManager();
          this.responseErrorManager = errorResult as ResponseErrorManager;
          responseManager.cod = errorResult.cod;
          responseManager.errors = [this.responseErrorManager];
          this.responseManager = responseManager;
          this.cargarMensajesServicioUnidadDespacho(this.responseManager);
        } else {
          this.responseManager = errorResult as ResponseManager;
          this.cargarMensajesServicioUnidadDespacho(this.responseManager);
        }
      }
    );
  }

  cargarRegimenesSeleccionados() {
    this.objUnidadDespacho.regimenes = this.selection.selected as Datacatalogo[];
  }

  validarServicioUnidadDespacho() : void {
    this.unidadDespachoService.validarServicioUnidadDespacho(this.objUnidadDespacho)
      .subscribe(
        response => {
        FuncionesGenerales.getInstance().cerrarModalCargando();
        this.responseManager = response as ResponseManager;
        if (this.responseManager.cod == ConstantesCadenas.CODIGO_EXITO_SERVICIO) {
          this.btnBotonGrabarUD = false;
          this.registrarUnidadDespacho(this.responseManager.msg);
        } else {
          let esConfirmacion: boolean = false;
          for (let i = 0; i < this.responseManager.errors.length; i++) {
            if (ConstantesListas.LISTA_MENSAJES_CONFIRMACION.indexOf(this.responseManager.errors[i].cod) > -1) {
              esConfirmacion = true;
              break;
            }
          }
          if (esConfirmacion) {
            Swal.fire({
              title: "Mensajes de Advertencia: ",
              html: FuncionesGenerales.getInstance().mostrarTablaDeErrores(this.responseManager.errors.filter(x => x.cod != "001")),
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              confirmButtonText: "SI",
              cancelButtonColor: '#d33',
              cancelButtonText: "NO"
            }).then((result) => {
              if (result.value) {
                let tokenGenerate: ResponseErrorManager[] = this.responseManager.errors.filter(x => x.cod == "001");
                this.registrarUnidadDespacho(tokenGenerate[0].msg);
              }
            });

          } else {
            this.cargarMensajesServicioUnidadDespacho(this.responseManager);
          }
        }
      },
        errorResult => {
        this.responseManager = errorResult.error as ResponseManager;
        this.cargarMensajesServicioUnidadDespacho(this.responseManager);
      });
  }

  cargarMensajesServicioUnidadDespacho(responseManager: ResponseManager) {
    if (responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO ||
          responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                   "Mensajes de Error: ",
                                                                    "",
                                                                    FuncionesGenerales.getInstance().mostrarTablaDeErrores(this.responseManager.errors));
    }
  }

  validarDatosUnidadDespacho() {
    let errorMensaje: string = "";
    let tituloErrores: string = "Mensajes de Error: ";
    let esValido: boolean = false;

    if (this.objUnidadDespacho.descripcion.length == 0) {
      errorMensaje = "Ingrese la descripción de la unidad de despacho.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (!FuncionesGenerales.getInstance().validarExpresionesRegulares(this.objUnidadDespacho.descripcion, "[0-9A-Za-z ]")) {
      errorMensaje = "La descripción de la unidad de Despacho es inválida.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (!FuncionesGenerales.getInstance().esFechaValida(
          FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objUnidadDespacho.fecInicioVigencia),
          ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO)) {
      errorMensaje = "Fecha de inicio de vigencia es incorrecta.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }
    if (!this.esFecIniVigencia) {
      if (FuncionesGenerales.getInstance().compararFechas(
        FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objUnidadDespacho.fecInicioVigencia),
                                                           ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
        FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(new Date()),
                                                           ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 0) {
        if (FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objUnidadDespacho.fecInicioVigencia) !=
            FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(new Date())) {
              errorMensaje = "Fecha de inicio de vigencia no puede ser menor que la fecha actual.";
              FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                          tituloErrores, errorMensaje, "");
              return false;
            }
      }
    }

    if (!FuncionesGenerales.getInstance().esFechaValida(
          FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objUnidadDespacho.fecFinVigencia),
          ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO)) {
      errorMensaje = "Fecha de término de vigencia es incorrecta.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (FuncionesGenerales.getInstance().compararFechas(
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objUnidadDespacho.fecInicioVigencia),
                                                         ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objUnidadDespacho.fecFinVigencia),
                                                         ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 1) {
      errorMensaje = "Fecha de inicio de vigencia no puede ser mayor que la fecha de término de vigencia.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (FuncionesGenerales.getInstance().compararFechas(
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objUnidadDespacho.fecFinVigencia),
                                                         ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objUnidadDespacho.fecInicioVigencia),
                                                         ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 0) {
      if (FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objUnidadDespacho.fecFinVigencia) !=
          FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objUnidadDespacho.fecInicioVigencia)) {
          errorMensaje = "Fecha de término de vigencia no puede ser menor que la fecha de inicio de vigencia.";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                        tituloErrores, errorMensaje, "");
          return false;
      }
    }

    esValido = true;
    return esValido;
  }

  cerrarUnidadDespacho() {
    this.childModal.hide();
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.regimenesDS.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.regimenesDS.data.forEach(row => this.selection.select(row));
  }

  getEstadoOperacion$(): Observable<String> {
    return this.estadoOperacion$.asObservable();
  }
}
