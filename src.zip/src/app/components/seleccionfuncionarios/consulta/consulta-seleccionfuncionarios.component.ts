import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { Component, OnInit, ViewChild } from '@angular/core';
import { BsModalService, ModalDirective } from 'ngx-bootstrap/modal';
import { CatEmpleado } from 'src/app/models/catempleado';
import { Datacatalogo } from 'src/app/models/datacatalogo';
import { TipCargoFun } from 'src/app/models/tipcargofun';
import { TipFun } from 'src/app/models/tipfun';
import { ConstantesListas } from 'src/app/utils/constanteslistas';
import { ConstantesCadenas } from 'src/app/utils/constantescadenas';
import { MatTableDataSource } from '@angular/material';

@Component({
  selector: 'app-consulta-seleccionfuncionarios',
  templateUrl: './consulta-seleccionfuncionarios.component.html',
  styleUrls: ['./consulta-seleccionfuncionarios.component.css']
})
export class ConsultaSeleccionfuncionariosComponent implements OnInit {
  @ViewChild('childModal') childModal: ModalDirective;
  displayedColumns: string[];
  lstCatEmpleado: CatEmpleado[];
  catEmpleadoDS: MatTableDataSource<CatEmpleado>;
  tituloFuncionarios: string;
  objCatEmpleadoSeleccionado: CatEmpleado;
  private estadoOperacion$ = new Subject<CatEmpleado>();

  constructor(public modalService: BsModalService) { }

  ngOnInit() {
    this.objCatEmpleadoSeleccionado = new CatEmpleado();
    this.objCatEmpleadoSeleccionado.aduana = new Datacatalogo();
    this.objCatEmpleadoSeleccionado.tipCargoFun = new TipCargoFun();
    this.objCatEmpleadoSeleccionado.tipFun = new TipFun();
  }

  mostrarSeleccionDeFuncionarios(lstCatEmpleado: CatEmpleado[]) {
    this.tituloFuncionarios = ConstantesCadenas.TITULO_SELECCION_FUNCIONARIOS;
    this.displayedColumns = ConstantesListas.COLUMNAS_GRID_FUNCIONARIO;
    this.objCatEmpleadoSeleccionado = lstCatEmpleado[0];
    this.catEmpleadoDS = new MatTableDataSource<CatEmpleado>(lstCatEmpleado);
    this.childModal.show();
  }

  cerrarSeleccionDeFuncionarios() {
    this.childModal.hide();
  }

  seleccionarFuncionarios() {
    this.cerrarSeleccionDeFuncionarios();
    this.estadoOperacion$.next(this.objCatEmpleadoSeleccionado);
  }

  obtenerSeleccionado(catEmpleado: CatEmpleado) {
    this.objCatEmpleadoSeleccionado = catEmpleado;
  }

  getEstadoOperacion$(): Observable<CatEmpleado> {
    return this.estadoOperacion$.asObservable();
  }
}
