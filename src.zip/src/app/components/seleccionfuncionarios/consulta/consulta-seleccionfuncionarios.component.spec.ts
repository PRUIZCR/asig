import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsultaSeleccionfuncionariosComponent } from './consulta-seleccionfuncionarios.component';

describe('ConsultaSeleccionfuncionariosComponent', () => {
  let component: ConsultaSeleccionfuncionariosComponent;
  let fixture: ComponentFixture<ConsultaSeleccionfuncionariosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsultaSeleccionfuncionariosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsultaSeleccionfuncionariosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
