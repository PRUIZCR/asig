import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MainFuncionariosComponent } from './main-funcionarios.component';

describe('MainFuncionariosComponent', () => {
  let component: MainFuncionariosComponent;
  let fixture: ComponentFixture<MainFuncionariosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MainFuncionariosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MainFuncionariosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
