import { Observable } from 'rxjs/Observable';
import { Component, OnInit, ViewChild } from '@angular/core';
import { CatalogoService } from 'src/app/services/catalogo.service';
import { setTheme } from 'ngx-bootstrap/utils';
import { ManualService } from 'src/app/services/manual.service';
import { Datacatalogo } from 'src/app/models/datacatalogo';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { ConstantesCadenas } from 'src/app/utils/constantescadenas';
import { ServicioRest } from 'src/app/models/serviciorest';
import { RespuestaInformacionOperacionManual } from 'src/app/models/respuestainformacionoperacionmanual';
import { DetalleManualComponent } from 'src/app/components/manual/detalle/detalle-manual.component';

@Component({
  selector: 'app-main-manual',
  templateUrl: './main-manual.component.html',
  styleUrls: ['./main-manual.component.css']
})
export class MainManualComponent implements OnInit {
  @ViewChild(DetalleManualComponent) modalDetalleManual: DetalleManualComponent;
  estadoAsignacion$: Observable<String>;
  esAsignacion: boolean;
  operaciones: Datacatalogo[];
  aduanas: Datacatalogo[];
  regimenes: Datacatalogo[];
  anio: number;
  objOperacion: Datacatalogo;
  objAduana: Datacatalogo;
  objRegimen: Datacatalogo;
  numero: string;
  tituloModal: string;
  regimenSeleccionado: string;
  aduanaSeleccionada: string;
  seHabilitaParcial: boolean;
  esDiligenciaDespachoRectificacionOficio: boolean;
  esDiligenciaDespacho: boolean;
  parcial: string;
  esReasignacionSolicitud: boolean;
  esAsignacionSolicitud: boolean;
  lstAduanasTmp: Datacatalogo[];
  lstAduanasTmpRF: Datacatalogo[];
  listAduanasFuncionario: string[];

  constructor(private manualService: ManualService, private catalogoService: CatalogoService) {
    setTheme('bs4');
  }

  ngOnInit() {
    this.esAsignacion = sessionStorage.getItem('pagina') == 'asignacion-manual';
    this.anio = (new Date()).getFullYear();
    this.numero = "";
    this.seHabilitaParcial = false;
    this.esDiligenciaDespachoRectificacionOficio = false;
    this.esDiligenciaDespacho = false;
    this.esReasignacionSolicitud = false;
    this.esAsignacionSolicitud = false;
    this.lstAduanasTmpRF = [];
    this.listAduanasFuncionario = [];
    this.parcial = "";
    this.catalogoService.listarOperacionesManuales().subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.operaciones = result as Datacatalogo[];
      //if (this.operaciones != null && this.operaciones != undefined && this.operaciones.length > 0) {
      if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.operaciones)) {
        this.objOperacion = new Datacatalogo();
        this.objOperacion.cod_datacat = this.operaciones[0].cod_datacat;
        this.tituloModal = this.operaciones[0].des_corta;
        this.cargarRegimenes();
      }
    }, error => console.error(error));

    this.catalogoService.listarAduanas().subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.objAduana = new Datacatalogo();
      this.objAduana.cod_datacat = result.aduana;
      this.aduanas = result.listaAduanas as Datacatalogo[];
      this.lstAduanasTmp = result.listaAduanas as Datacatalogo[];
      this.aduanaSeleccionada = result.aduana;
      this.aduanasAsignadasAFuncionario(this.aduanas);
    }, error => console.error(error));

    this.estadoAsignacion$ = this.modalDetalleManual.getEstadoAsignacion();
    this.estadoAsignacion$.subscribe(() => {
      this.ngOnInit();
     }
   );
  }

  aduanasAsignadasAFuncionario(aduanasAsignadas: Datacatalogo[]) {
    if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(aduanasAsignadas)) {
      for (let i = 0; i < aduanasAsignadas.length; i++) {
        this.listAduanasFuncionario.push(aduanasAsignadas[i].cod_datacat);
      }
    }
  }

  seleccionarOperacion(objSeleccionado){
    console.log("indice seleccionado: " + objSeleccionado.target.value);
    this.objOperacion.cod_datacat = this.operaciones[objSeleccionado.target.value].cod_datacat;
    this.tituloModal = this.operaciones[objSeleccionado.target.value].des_corta;
    this.validacionAduanasPorFuncionario(this.objOperacion.cod_datacat);
    console.log("operacion seleccionada: " + this.objOperacion.cod_datacat);
    this.numero = "";
  }

  validacionAduanasPorFuncionario(tipoOperadocion: string) {
    if (FuncionesGenerales.getInstance().incluir(tipoOperadocion,
        ConstantesCadenas.TIPO_ASIGNACION_INDIVIDUAL_SOLICITUD_RECONOCIMIENTO_FISICO,
        ConstantesCadenas.TIPO_REASIGNACION_INDIVIDUAL_SOLICITUD_RECONOCIMIENTO_FISICO)) {
          this.catalogoService.listarAduanas("X").subscribe(result => {
            FuncionesGenerales.getInstance().cerrarModalCargando();
            this.objAduana.cod_datacat = result.aduana;
            this.aduanas = result.listaAduanas as Datacatalogo[];
          }, error => console.error(error));
    } else {
        this.aduanas = FuncionesGenerales.getInstance().clonarObjeto(this.lstAduanasTmp);
        this.objAduana.cod_datacat = this.aduanas.find(x => x.cod_datacat == this.aduanaSeleccionada).cod_datacat;
        //this.objAduana.cod_datacat = this.aduanas[0].cod_datacat;
    }
    this.cargarRegimenes();
  }

  seleccionarAduana(objSeleccionado) {
    this.aduanaSeleccionada = objSeleccionado.target.value;
    if (objSeleccionado.target.value != "") {
      this.objAduana = this.aduanas.find(element => element.cod_datacat == this.aduanaSeleccionada);
    }
  }

  seleccionarRegimen(objSeleccionado) {
    this.regimenSeleccionado = objSeleccionado.target.value;
    if (objSeleccionado.target.value != "") {
      this.objRegimen = this.regimenes.find(element => element.cod_datacat == this.regimenSeleccionado);
      this.cargaDeFlagAsignacionReasignacion();
    }
  }

  cargarRegimenes(){
    if(this.objOperacion != null && this.objOperacion.cod_datacat != null){
      this.catalogoService.listarRegimenesOperacionesManuales(this.objOperacion.cod_datacat).subscribe(result => {
        FuncionesGenerales.getInstance().cerrarModalCargando();
        this.regimenes = result as Datacatalogo[];
        if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.regimenes)) {
          this.objRegimen = this.regimenes[0];
          this.cargaDeFlagAsignacionReasignacion();
        } else {
          let tituloErrores: string = "Mensaje de Error: ";
          let errorMensaje = "La operación seleccionada no tiene regímenes asociados.";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                        tituloErrores, errorMensaje, "");
        }
      }, error => console.error(error));
    }
  }

  buscar() {
    let tituloErrores: string = "Mensajes de Error: ";
    let errorMensaje: string = "";
    if (this.validarDatosAsignacionReasignacionManual(tituloErrores, errorMensaje)) {
      this.manualService.validarOperacionManual(this.objOperacion.cod_datacat, ConstantesCadenas.TIPO_SERVICIO_VALIDACION).subscribe(result => {
        FuncionesGenerales.getInstance().cerrarModalCargando();
        if(result != null && result != undefined)
          this.validarDatos(result as ServicioRest);
        else{
          errorMensaje = "La operación no tiene asociada ningún servicio de validación.";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR, tituloErrores, errorMensaje, "");
        }
      }, error => console.error(error));
    }
  }

  validarDatosAsignacionReasignacionManual(tituloErrores: string, errorMensaje: string) {
    if (this.objOperacion == null || this.objOperacion.cod_datacat == null) {
      errorMensaje = "Debe seleccionar tipo de asignación.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR, tituloErrores, errorMensaje, "");
      return false;
    } else if (this.objAduana == null || this.objAduana.cod_datacat == null) {
      errorMensaje = "Debe seleccionar aduana.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR, tituloErrores, errorMensaje, "");
      return false;
    } else if (this.anio == null || this.anio == undefined) {
      errorMensaje = "Debe ingresar año.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR, tituloErrores, errorMensaje, "");
      return false;
    } else if (this.anio < 2019 || this.anio > (new Date()).getFullYear()){
      errorMensaje = "Año ingresado es incorrecto.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR, tituloErrores, errorMensaje, "");
      return false;
    } else if (this.objRegimen == null || this.objRegimen.cod_datacat == null){
      errorMensaje = "Debe seleccionar régimen.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR, tituloErrores, errorMensaje, "");
      return false;
    } else if (this.seHabilitaParcial && this.parcial != "" && this.parcial != undefined) {
      if (!FuncionesGenerales.getInstance().esEntero(this.parcial)) {
        errorMensaje = "El parcial ingresado es incorrecto.";
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR, tituloErrores, errorMensaje, "");
        return false;
      }
    } else if (this.numero == null || this.numero == undefined || !FuncionesGenerales.getInstance().esEntero(this.numero.toString()) || this.numero.length == 0) {
      if (this.esAsignacionSolicitud || this.esReasignacionSolicitud) {
        if (this.numero.length > 6) {
          errorMensaje = "Debe ingresar número de solicitud.";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR, tituloErrores, errorMensaje, "");
        }
      } else {
        if (this.numero.length > 8) {
          errorMensaje = "Debe ingresar número de declaración.";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR, tituloErrores, errorMensaje, "");
        }
      }
      return false;
    }
    return true;
  }

  cargaDeFlagAsignacionReasignacion() {
    this.esDiligenciaDespachoRectificacionOficio = (ConstantesCadenas.REGIMEN_EER == this.objRegimen.cod_datacat &&
                                            FuncionesGenerales.getInstance().incluir(this.objOperacion.cod_datacat,
                                            ConstantesCadenas.TIPO_ASIGNACION_INDIVIDUAL_DILIGENCIA_RECTIFICACION_OFICIO_EER,
                                            ConstantesCadenas.TIPO_REASIGNACION_INDIVIDUAL_DILIGENCIA_RECTIFICACION_OFICIO_EER,
                                            ConstantesCadenas.TIPO_ASIGNACION_INDIVIDUAL_DILIGENCIA_DESPACHO,
                                            ConstantesCadenas.TIPO_REASIGNACION_INDIVIDUAL_DILIGENCIA_DESPACHO));
    this.esDiligenciaDespacho = (ConstantesCadenas.REGIMEN_EER == this.objRegimen.cod_datacat &&
                                 FuncionesGenerales.getInstance().incluir(this.objOperacion.cod_datacat,
                                 ConstantesCadenas.TIPO_ASIGNACION_INDIVIDUAL_DILIGENCIA_DESPACHO,
                                 ConstantesCadenas.TIPO_REASIGNACION_INDIVIDUAL_DILIGENCIA_DESPACHO,
                                 ConstantesCadenas.TIPO_ASIGNACION_INDIVIDUAL_SOLICITUD_LEGAJAMIENTO,
                                 ConstantesCadenas.TIPO_REASIGNACION_INDIVIDUAL_SOLICITUD_LEGAJAMIENTO
                                ));
    this.seHabilitaParcial = (ConstantesCadenas.REGIMEN_EXPORTACION == this.objRegimen.cod_datacat &&
                              FuncionesGenerales.getInstance().incluir(this.objOperacion.cod_datacat,
                              ConstantesCadenas.TIPO_ASIGNACION_INDIVIDUAL_SOLICITUD_RECONOCIMIENTO_FISICO,
                              ConstantesCadenas.TIPO_REASIGNACION_INDIVIDUAL_SOLICITUD_RECONOCIMIENTO_FISICO));
    this.esAsignacionSolicitud = ((ConstantesCadenas.REGIMEN_EXPORTACION == this.objRegimen.cod_datacat &&
                                FuncionesGenerales.getInstance().incluir(this.objOperacion.cod_datacat,
                                ConstantesCadenas.TIPO_ASIGNACION_INDIVIDUAL_SOLICITUD_RECTIFICACION_DAM,
                                ConstantesCadenas.TIPO_ASIGNACION_INDIVIDUAL_SOLICITUD_RECONOCIMIENTO_FISICO_LOCAL_EXPORTADOR,
                                ConstantesCadenas.TIPO_ASIGNACION_INDIVIDUAL_SOLICITUD_REGULARIZACION,
                                ConstantesCadenas.TIPO_ASIGNACION_INDIVIDUAL_SOLICITUD_RECTIFICACION_RECEPCION_MERCANCIA,
                                ConstantesCadenas.TIPO_ASIGNACION_INDIVIDUAL_SOLICITUD_RECTIFICACION_RELACION_CARGA_EMBARCAR,
                                ConstantesCadenas.TIPO_ASIGNACION_INDIVIDUAL_SOLICITUD_ANULACION_DAM,
                                ConstantesCadenas.TIPO_ASIGNACION_INDIVIDUAL_SOLICITUD_REVERSION_ANULACION_DAM,
                                ConstantesCadenas.TIPO_ASIGNACION_INDIVIDUAL_SOLICITUD_LUGAR_DESIGNADO_ADMINISTRACION_ADUANERA,
                                ConstantesCadenas.TIPO_ASIGNACION_INDIVIDUAL_SOLICITUD_BOLETIN_QUIMICO
                                )) || (ConstantesCadenas.REGIMEN_MANIFIESTO == this.objRegimen.cod_datacat &&
                                FuncionesGenerales.getInstance().incluir(this.objOperacion.cod_datacat,
                                ConstantesCadenas.TIPO_ASIGNACION_INDIVIDUAL_SOLICITUD_MANIFIESTO,
                                ConstantesCadenas.TIPO_ASIGNACION_INDIVIDUAL_SOLICITUD_OPERACION_ASOCIADA_MANIFIESTO)
                                ) || (ConstantesCadenas.REGIMEN_EER == this.objRegimen.cod_datacat &&
                                FuncionesGenerales.getInstance().incluir(this.objOperacion.cod_datacat,
                                ConstantesCadenas.TIPO_ASIGNACION_INDIVIDUAL_SOLICITUD_RECTIFICACION_DSEER_EVALUACION)));
    this.esReasignacionSolicitud = ((ConstantesCadenas.REGIMEN_EXPORTACION == this.objRegimen.cod_datacat &&
                                  FuncionesGenerales.getInstance().incluir(this.objOperacion.cod_datacat,
                                  ConstantesCadenas.TIPO_REASIGNACION_INDIVIDUAL_SOLICITUD_RECTIFICACION_DAM,
                                  ConstantesCadenas.TIPO_REASIGNACION_INDIVIDUAL_SOLICITUD_RECONOCIMIENTO_FISICO_LOCAL_EXPORTADOR,
                                  ConstantesCadenas.TIPO_REASIGNACION_INDIVIDUAL_SOLICITUD_REGULARIZACION,
                                  ConstantesCadenas.TIPO_REASIGNACION_INDIVIDUAL_SOLICITUD_RECTIFICACION_RECEPCION_MERCANCIA,
                                  ConstantesCadenas.TIPO_REASIGNACION_INDIVIDUAL_SOLICITUD_RECTIFICACION_RELACION_CARGA_EMBARCAR,
                                  ConstantesCadenas.TIPO_REASIGNACION_INDIVIDUAL_SOLICITUD_ANULACION_DAM,
                                  ConstantesCadenas.TIPO_REASIGNACION_INDIVIDUAL_SOLICITUD_REVERSION_ANULACION_DAM,
                                  ConstantesCadenas.TIPO_REASIGNACION_INDIVIDUAL_SOLICITUD_LUGAR_DESIGNADO_ADMINISTRACION_ADUANERA,
                                  ConstantesCadenas.TIPO_REASIGNACION_INDIVIDUAL_SOLICITUD_BOLETIN_QUIMICO
                                  )) || (ConstantesCadenas.REGIMEN_MANIFIESTO == this.objRegimen.cod_datacat &&
                                  FuncionesGenerales.getInstance().incluir(this.objOperacion.cod_datacat,
                                  ConstantesCadenas.TIPO_REASIGNACION_INDIVIDUAL_SOLICITUD_MANIFIESTO,
                                  ConstantesCadenas.TIPO_REASIGNACION_INDIVIDUAL_SOLICITUD_OPERACION_ASOCIADA_MANIFIESTO)
                                  ) || (ConstantesCadenas.REGIMEN_EER == this.objRegimen.cod_datacat &&
                                    FuncionesGenerales.getInstance().incluir(this.objOperacion.cod_datacat,
                                    ConstantesCadenas.TIPO_REASIGNACION_INDIVIDUAL_SOLICITUD_RECTIFICACION_DSEER_EVALUACION)));
  }

  validarDatos(servicioRest: ServicioRest){
    let parametroAdicional: any;
    if (this.seHabilitaParcial || this.esDiligenciaDespachoRectificacionOficio) {
      if (this.esDiligenciaDespachoRectificacionOficio) {
        parametroAdicional = this.esDiligenciaDespacho ? "0" : this.objOperacion.cod_datacat;
      } else {
        parametroAdicional = this.parcial == "" ? 0 : parseInt(this.parcial);
      }

       this.manualService.ejecutarServicioRest(servicioRest, ConstantesCadenas.METHOD_HTTP_GET, this.objOperacion.cod_datacat, this.anio, this.objAduana.cod_datacat, this.objRegimen.cod_datacat, parseInt(this.numero), parametroAdicional).subscribe(
         result => {
           FuncionesGenerales.getInstance().cerrarModalCargando();
           this.modalDetalleManual.abrirModal(result as RespuestaInformacionOperacionManual, this.tituloModal, this.objAduana.cod_datacat, this.objRegimen.cod_datacat, this.anio, parseInt(this.numero), this.objOperacion, this.listAduanasFuncionario);
         },
         error => {
           FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                          "Mensajes de Error: ",
                                                                           "",
                                                                           FuncionesGenerales.getInstance().mostrarTablaDeErrores(error.error.errors));
         }
       );
    } else {
      this.manualService.ejecutarServicioRest(servicioRest, ConstantesCadenas.METHOD_HTTP_GET, this.objOperacion.cod_datacat, this.anio, this.objAduana.cod_datacat, this.objRegimen.cod_datacat, parseInt(this.numero)).subscribe(
        result => {
          FuncionesGenerales.getInstance().cerrarModalCargando();
          this.modalDetalleManual.abrirModal(result as RespuestaInformacionOperacionManual, this.tituloModal, this.objAduana.cod_datacat, this.objRegimen.cod_datacat, this.anio, parseInt(this.numero), this.objOperacion, this.listAduanasFuncionario);
        },
        error => {
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                         "Mensajes de Error: ",
                                                                          "",
                                                                          FuncionesGenerales.getInstance().mostrarTablaDeErrores(error.error.errors));
        }
      );
    }

  }
}
