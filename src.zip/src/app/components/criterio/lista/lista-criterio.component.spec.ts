import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListaCriterioComponent } from './lista-criterio.component';

describe('ListaCriterioComponent', () => {
  let component: ListaCriterioComponent;
  let fixture: ComponentFixture<ListaCriterioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListaCriterioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListaCriterioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
