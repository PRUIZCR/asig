import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MainZonaComponent } from './main-zona.component';

describe('MainZonasComponent', () => {
  let component: MainZonaComponent;
  let fixture: ComponentFixture<MainZonaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MainZonaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MainZonaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
