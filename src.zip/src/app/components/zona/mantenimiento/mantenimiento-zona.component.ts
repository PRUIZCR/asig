import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Zona } from 'src/app/models/zona';
import { Unidaddespacho } from 'src/app/models/unidaddespacho';
import { Datacatalogo } from 'src/app/models/datacatalogo';
import { ConstantesCadenas } from 'src/app/utils/constantescadenas';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { ResponseManager } from 'src/app/models/responsemanager';
import { ResponseErrorManager } from 'src/app/models/responseerrormanager';
import { ZonaService } from 'src/app/services/zona.service';
import { ModalDirective } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-mantenimiento-zona',
  templateUrl: './mantenimiento-zona.component.html',
  styleUrls: ['./mantenimiento-zona.component.css']
})
export class MantenimientoZonaComponent implements OnInit {
  @ViewChild('childZonaModal') childZonaModal : ModalDirective;
  tituloZona: string;
  objZona: Zona;
  esFormularioDeRegistro: boolean = false;
  responseManager: ResponseManager;
  responseErrorManager: ResponseErrorManager;
  private estadoOperacion$ = new Subject<String>();
  esFecIniVigencia: boolean = false;

  constructor(private zonaService: ZonaService) {
     this.objZona = new Zona();
     this.objZona.unidadDespacho = new Unidaddespacho();
     this.objZona.unidadDespacho.aduana = new Datacatalogo();
  }

  ngOnInit() {
  }

  validarFechaInicioVigencia() {
    let fechaActual: Date = new Date();
    fechaActual.setHours(0);
    fechaActual.setMinutes(0);
    fechaActual.setSeconds(0);
    if (this.objZona.fecInicioVigencia < fechaActual) {
      this.esFecIniVigencia = true;
    }
  }

  addZona(zonas: Zona, objUnidadDespachoSeleccionado: Unidaddespacho) {
    this.objZona = FuncionesGenerales.getInstance().clonarObjeto(zonas);
    this.esFecIniVigencia = false;
    if (zonas.numZona > 0) {
      this.esFormularioDeRegistro = false;
      this.tituloZona = ConstantesCadenas.TITULO_MODIFICAR_ZONA;
      this.objZona.unidadDespacho = objUnidadDespachoSeleccionado;
      this.objZona.fecInicioVigencia = new Date(zonas.fecInicioVigencia);
      this.objZona.fecFinVigencia = new Date(zonas.fecFinVigencia);
      this.validarFechaInicioVigencia();
    } else {
      this.esFormularioDeRegistro = true;
      this.tituloZona = ConstantesCadenas.TITULO_AGREGAR_ZONA;
      this.objZona.unidadDespacho = objUnidadDespachoSeleccionado;
      this.objZona.descripcion = "";
      this.objZona.nombre = "";
      this.objZona.numZona = -1;
      this.objZona.indSusceptible = "1";
      this.objZona.fecInicioVigencia = new Date();
      this.objZona.fecFinVigencia = new Date();
      this.esFecIniVigencia = false;
    }
    this.childZonaModal.show();
  }

  cerrarZona() {
    this.childZonaModal.hide();
  }

  registrarActualizarZona() {
    if (!this.validarDatosZonas()) {
      return false;
    }

    this.registrarZona();
  }

  callback = () : void => {
    this.cerrarZona();
    this.estadoOperacion$.next("X");
  };

  registrarZona() {
    this.zonaService.registrarActualizarZona(this.objZona).subscribe(
      response => {
        console.log(response);
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(
          ConstantesCadenas.MENSAJE_EXITOSO,
          "La zona se " + (this.objZona.numZona == -1 ? "registro" : "modifico") + " correctamente.",
          "", "", this.callback);
      },
      errorResult => {
        if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
          let responseManager: ResponseManager = new ResponseManager();
          this.responseErrorManager = errorResult as ResponseErrorManager;
          responseManager.cod = errorResult.cod;
          responseManager.errors = [this.responseErrorManager];
          this.responseManager = responseManager;
          this.cargarMensajesServicioZona(this.responseManager);
        } else {
          this.responseManager = errorResult as ResponseManager;
          this.cargarMensajesServicioZona(this.responseManager);
        }
      }
    );
  }

  cargarMensajesServicioZona(responseManager: ResponseManager) {
    if (responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO ||
        responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                   "Mensajes de Error: ",
                                                                    "",
                                                                    FuncionesGenerales.getInstance().mostrarTablaDeErrores(this.responseManager.errors));
    }
  }

  validarDatosZonas() {
    let errorMensaje: string = "";
    let tituloErrores: string = "Mensajes de Error: ";
    let esValido: boolean = false;
    //let regExpNombre = "^[áéíóúÁÉÍÓÚñÑa-zA-Z0-9".concat("\\").concat("s,()-._").concat("\\/").concat("]{2,60}$");
    let regExpNombre = "^[A-Za-z0-9][A-Za-z0-9 -_".concat(String.fromCharCode(39)).concat(String.fromCharCode(34)).concat("]*[A-Za-z0-9]{1,60}$"); //String.fromCharCode(34) //String.fromCharCode(39)
    let regExpDescripcion = "^[áéíóúÁÉÍÓÚñÑa-zA-Z0-9".concat("\\").concat("s,()-._").concat("\\/").concat("]{2,200}$");
    if (this.objZona.nombre.length == 0) {
      errorMensaje = "Debe ingresar el nombre de la Zona.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (!FuncionesGenerales.getInstance().validarExpresionesRegulares(this.objZona.nombre, regExpNombre)) {
      if (this.objZona.nombre.length == 2) {
        errorMensaje = "Ingrese al menos 2 caracteres del nombre de la zona.";
      } else {
        errorMensaje = "La nombre de la zona es incorrecto.";
      }
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (this.objZona.descripcion.length == 0) {
      errorMensaje = "Debe ingresar la descripción de la Zona.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (!FuncionesGenerales.getInstance().validarExpresionesRegulares(this.objZona.descripcion, regExpDescripcion)) {
      errorMensaje = "Ingrese al menos 2 caracteres de la descripción de la zona.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (!FuncionesGenerales.getInstance().esFechaValida(
          FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objZona.fecInicioVigencia),
          ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO)) {
      errorMensaje = "La fecha de inicio de vigencia es incorrecta.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (!this.esFecIniVigencia) {
      if (FuncionesGenerales.getInstance().compararFechas(
        FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objZona.fecInicioVigencia),
                                                           ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
        FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(new Date()),
                                                           ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 0) {
        if (FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objZona.fecInicioVigencia) !=
            FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(new Date())) {
              errorMensaje = "Fecha de inicio de vigencia no puede ser menor que la fecha actual.";
              FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                          tituloErrores, errorMensaje, "");
              return false;
            }
      }
    }

    if (!FuncionesGenerales.getInstance().esFechaValida(
          FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objZona.fecFinVigencia),
          ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO)) {
      errorMensaje = "Fecha de término de vigencia es incorrecta.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (FuncionesGenerales.getInstance().compararFechas(
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objZona.fecInicioVigencia),
                                                         ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objZona.fecFinVigencia),
                                                         ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 1) {
      errorMensaje = "Fecha de inicio de vigencia no puede ser mayor que la fecha de término de vigencia.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (FuncionesGenerales.getInstance().compararFechas(
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objZona.fecFinVigencia),
                                                         ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objZona.fecInicioVigencia),
                                                         ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 0) {
      if (FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objZona.fecFinVigencia) !=
          FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objZona.fecInicioVigencia)) {
          errorMensaje = "Fecha de término de vigencia no puede ser menor que la fecha de inicio de vigencia.";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                        tituloErrores, errorMensaje, "");
          return false;
      }
    }

    esValido = true;
    return esValido;
  }

  getEstadoOperacion$(): Observable<String> {
    return this.estadoOperacion$.asObservable();
  }

}
