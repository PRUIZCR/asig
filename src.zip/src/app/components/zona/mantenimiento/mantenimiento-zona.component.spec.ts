import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MantenimientoZonaComponent } from './mantenimiento-zona.component';

describe('MantenimientoZonasComponent', () => {
  let component: MantenimientoZonaComponent;
  let fixture: ComponentFixture<MantenimientoZonaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MantenimientoZonaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MantenimientoZonaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
