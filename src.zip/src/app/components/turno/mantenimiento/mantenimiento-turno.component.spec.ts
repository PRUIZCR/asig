import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MantenimientoTurnoComponent } from './mantenimiento-turno.component';

describe('MantenimientoTurnoComponent', () => {
  let component: MantenimientoTurnoComponent;
  let fixture: ComponentFixture<MantenimientoTurnoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MantenimientoTurnoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MantenimientoTurnoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
