import { Observable } from 'rxjs/Observable';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { MatSort  } from '@angular/material/sort';
import { MatPaginator  } from '@angular/material/paginator';
import { setTheme } from 'ngx-bootstrap/utils';
import { ConstantesListas } from 'src/app/utils/constanteslistas';
import { Datacatalogo } from 'src/app/models/datacatalogo';
import { Unidaddespacho } from 'src/app/models/unidaddespacho';
import { Turno } from 'src/app/models/turno';
import { ConstantesCadenas } from 'src/app/utils/constantescadenas';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { MantenimientoTurnoComponent } from 'src/app/components/turno/mantenimiento/mantenimiento-turno.component';
import { CatalogoService } from 'src/app/services/catalogo.service';
import { UnidaddespachoService } from 'src/app/services/unidaddespacho.service';
import { TurnoService } from 'src/app/services/turno.service';

@Component({
  selector: 'app-main-turno',
  templateUrl: './main-turno.component.html',
  styleUrls: ['./main-turno.component.css']
})
export class MainTurnoComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MantenimientoTurnoComponent) child: MantenimientoTurnoComponent;
  aduanas: Datacatalogo[];
  estados: Datacatalogo[];
  lstUnidadDespacho: Unidaddespacho[];
  unidadDespachoSeleccionado: string;
  aduanaSeleccionada: string;
  estadoSeleccionado: string;
  objAduanaSeleccionada: Datacatalogo;
  objUnidadDespachoSeleccionado: Unidaddespacho;
  desabilitarBotonTurno: boolean = false;
  turno: Turno;
  lstTurnos: Turno[];
  turnosDS: MatTableDataSource<Turno>;
  displayedColumns: string[];
  funcionesGenerales: FuncionesGenerales;
  estadoOperacion$: Observable<String>;
  esSoloConsulta: boolean;

  constructor(private catalogoService: CatalogoService,
              private unidadDespachoService: UnidaddespachoService,
              private turnoService: TurnoService) {
    setTheme('bs4');
  }

  ngOnInit() {
    this.esSoloConsulta = sessionStorage.getItem('esJefeSupervisor') == '0';
    this.catalogoService.listarAduanas().subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.aduanaSeleccionada = result.aduana;
      this.aduanas = result.listaAduanas as Datacatalogo[];
      if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.aduanas)) {
        this.cargarControles();
      }
    }, error => console.error(error));
    this.displayedColumns = ConstantesListas.COLUMNAS_GRID_TURNOS;
    this.lstTurnos = [];
    this.turnosDS = new MatTableDataSource<Turno>(this.lstTurnos);
    this.funcionesGenerales = FuncionesGenerales.getInstance();
    this.estadoOperacion$ = this.child.getEstadoOperacion$();
    this.estadoOperacion$.subscribe(estado => estado == "X" ? this.cargarTurnos() : "");
    this.turno = new Turno();
    this.turno.numTurno = -1;
  }

  cargarControles() {
    this.estados = ConstantesListas.LISTA_ESTADOS;
    this.lstUnidadDespacho = [];
    this.unidadDespachoSeleccionado = "";
    this.estadoSeleccionado = ConstantesCadenas.ESTADO_TODOS;
    //this.aduanaSeleccionada = this.aduanas[0].cod_datacat;
    this.objAduanaSeleccionada = this.aduanas.find(element => element.cod_datacat == this.aduanaSeleccionada);
    this.cargarUnidadesDespacho();
  }

  seleccionarAduana(objSeleccionado) {
    this.aduanaSeleccionada = objSeleccionado.target.value;
    if (objSeleccionado.target.value != "") {
      this.objAduanaSeleccionada = this.aduanas.find(element => element.cod_datacat == objSeleccionado.target.value);
      this.cargarUnidadesDespacho();
    }
  }

  cargarUnidadesDespacho() {
    let campos: string = "numUnidadDespacho,nombre";
    this.unidadDespachoService.listarUnidadesDespacho(this.aduanaSeleccionada,
                                                      ConstantesCadenas.ESTADO_VIGENTE,
                                                      campos).subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.lstUnidadDespacho = result as Unidaddespacho[];
      //if (this.aduanaSeleccionada != "" && this.lstUnidadDespacho != null && this.lstUnidadDespacho != undefined) {
      if (this.aduanaSeleccionada != "" && FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.lstUnidadDespacho)) {
        this.desabilitarBotonTurno = true;
        this.lstUnidadDespacho = this.lstUnidadDespacho.sort(FuncionesGenerales.getInstance().ordenarPor("numUnidadDespacho", false)); //cchavezt ATENCION BUGS 
        this.unidadDespachoSeleccionado = this.lstUnidadDespacho[0].numUnidadDespacho.toString();
        this.objUnidadDespachoSeleccionado = this.lstUnidadDespacho.find(element => element.numUnidadDespacho == parseInt(this.unidadDespachoSeleccionado));
        this.objUnidadDespachoSeleccionado.aduana = this.objAduanaSeleccionada;
        this.cargarTurnos();
      } else {
        this.lstUnidadDespacho = [];
        this.lstTurnos = [];
        this.turnosDS = new MatTableDataSource<Turno>(this.lstTurnos);
        let tituloErrores: string = "Mensaje de Error: ";
        let errorMensaje: string = "No existen unidades de despacho asignadas a la Aduana " + this.objAduanaSeleccionada.des_corta;
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                      tituloErrores, errorMensaje, "");
      }
    }, error => console.error(error));
  }

  seleccionarUnidadDespacho(objSeleccionado) {
    this.unidadDespachoSeleccionado = objSeleccionado.target.value;
    if (objSeleccionado.target.value != "") {
      this.objUnidadDespachoSeleccionado = this.lstUnidadDespacho.find(element => element.numUnidadDespacho == objSeleccionado.target.value);
      this.turno = new Turno();
      this.turno.numTurno = -1;
      this.turno.unidadDespacho = this.objUnidadDespachoSeleccionado;
      this.turno.unidadDespacho.aduana = this.objAduanaSeleccionada;
      this.desabilitarBotonTurno = true;
      this.cargarTurnos();
    } else {
      this.desabilitarBotonTurno = false;
    }
  }

  seleccionarEstado(objSeleccionado) {
    this.estadoSeleccionado = objSeleccionado.target.value;
    if (this.unidadDespachoSeleccionado != "" &&
        this.unidadDespachoSeleccionado != null &&
        this.unidadDespachoSeleccionado != undefined) {
      this.cargarTurnos();
    }
  }

  cargarTurnos() {
    let campos: string = "numTurno,nombre,hraInicio,hraFin,hraCorte,zonas,fecInicioVigencia,fecFinVigencia";
    this.turnoService.listarTurnos(this.unidadDespachoSeleccionado,
                      this.estadoSeleccionado, "", "",
                      campos).subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.lstTurnos = result as Turno[];
      //if (this.unidadDespachoSeleccionado != "" && this.lstTurnos != null && this.lstTurnos != undefined) {
      if (this.unidadDespachoSeleccionado != "" && FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.lstTurnos)) {
        this.lstTurnos = this.lstTurnos.sort(FuncionesGenerales.getInstance().ordenarPor("numTurno", false));
      } else {
        this.lstTurnos = [];
        FuncionesGenerales.getInstance().mensajeRegistrosNoEncontrados();
      }
      this.turnosDS = new MatTableDataSource<Turno>(this.lstTurnos);
      this.turnosDS.sort = this.sort;
      this.turnosDS.paginator = this.paginator;
    }, error => console.error(error));
  }

  mostrarTurnosEditable(fecInicioVigencia: Date, fecFinVigencia: Date) {
    let esEditable: boolean = false;
    this.objUnidadDespachoSeleccionado = this.lstUnidadDespacho.find(
      element => element.numUnidadDespacho == parseInt(this.unidadDespachoSeleccionado)
    );
    /*if (FuncionesGenerales.getInstance().compararFechas(
      FuncionesGenerales.getInstance().formatearFecha(fecInicioVigencia),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
      FuncionesGenerales.getInstance().formatearFecha(fecFinVigencia),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 0) {
        esEditable = true;
    }*/
    if (FuncionesGenerales.getInstance().compararFechas(
      FuncionesGenerales.getInstance().formatearFecha(new Date()),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
      FuncionesGenerales.getInstance().formatearFecha(fecFinVigencia),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 0) {
        esEditable = true;
    }
    return esEditable;
  }
}
