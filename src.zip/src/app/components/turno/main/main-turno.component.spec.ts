import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MainTurnoComponent } from './main-turno.component';

describe('MainTurnoComponent', () => {
  let component: MainTurnoComponent;
  let fixture: ComponentFixture<MainTurnoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MainTurnoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MainTurnoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
