import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReporteAsignacionBloqueComponent } from './reporte-asignacion-bloque.component';

describe('ReporteAsignacionBloqueComponent', () => {
  let component: ReporteAsignacionBloqueComponent;
  let fixture: ComponentFixture<ReporteAsignacionBloqueComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReporteAsignacionBloqueComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReporteAsignacionBloqueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
