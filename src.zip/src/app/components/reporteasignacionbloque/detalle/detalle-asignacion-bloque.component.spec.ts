import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetalleAsignacionBloqueComponent } from './detalle-asignacion-bloque.component';

describe('DetalleAsignacionBloqueComponent', () => {
  let component: DetalleAsignacionBloqueComponent;
  let fixture: ComponentFixture<DetalleAsignacionBloqueComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetalleAsignacionBloqueComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetalleAsignacionBloqueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
