import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { setTheme } from 'ngx-bootstrap/utils';
import { Datacatalogo } from 'src/app/models/datacatalogo';
import { Sorteo } from 'src/app/models/sorteo';
import { Unidaddespacho } from 'src/app/models/unidaddespacho';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { ConstantesCadenas } from 'src/app/utils/constantescadenas';
import { Turno } from 'src/app/models/turno';
import { Horariosorteo } from 'src/app/models/horariosorteo';
import { ResponseManager } from 'src/app/models/responsemanager';
import { ResponseErrorManager } from 'src/app/models/responseerrormanager';
import { SorteoService } from 'src/app/services/sorteo.service';
import { ActivatedRoute, Params } from '@angular/router';
import { CatalogoService } from 'src/app/services/catalogo.service';
import { TurnoService } from 'src/app/services/turno.service';
import { UnidaddespachoService } from 'src/app/services/unidaddespacho.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-main-sorteo',
  templateUrl: './main-sorteo.component.html',
  styleUrls: ['./main-sorteo.component.css']
})
export class MainSorteoComponent implements OnInit {
  responseManager: ResponseManager;
  responseErrorManager: ResponseErrorManager;
  aduanas: Datacatalogo[];
  anforas: Datacatalogo[];
  unidadesDespacho: Unidaddespacho[];
  objAduanaSeleccionada: Datacatalogo;
  turnos: Turno[];
  txtFecha: string;
  txtHora: string;
  txtHora15: string;
  objSorteo: Sorteo;
  esCargaInicial: boolean;
  esEdicion: boolean;
  esFechaInicioMenor: boolean;
  funcionesGenerales: FuncionesGenerales;
  esProcesoEXPOEER: boolean = false;

  constructor(private route: ActivatedRoute,
              private location: Location,
              private sorteoService: SorteoService,
              private catalogoService: CatalogoService,
              private turnoService: TurnoService,
              private unidadDespachoService: UnidaddespachoService) {
    setTheme('bs4');
  }

  ngOnInit() {
    this.esProcesoEXPOEER = false;
    this.funcionesGenerales = FuncionesGenerales.getInstance();
    this.esCargaInicial = true;
    let fechaActual = new Date();
    this.cambiarHorarios();
    this.objSorteo = new Sorteo();
    this.esFechaInicioMenor = false;
    this.route.params.forEach((params: Params) => {
      if (params['numSorteo'] !== undefined) {
        this.esCargaInicial = false;
        this.esEdicion = true;
        this.objSorteo = JSON.parse(sessionStorage.getItem('numSorteo'));
        this.objSorteo.fechaInicioVigencia = new Date(this.objSorteo.fechaInicioVigencia);
        this.objSorteo.fechaFinVigencia = new Date(this.objSorteo.fechaFinVigencia);
        this.esFechaInicioMenor = (new Date()).setHours(0,0,0,0) > this.objSorteo.fechaInicioVigencia.setHours(0,0,0,0);
      } else {
        this.esCargaInicial = true;
        this.esEdicion = false;
        this.objSorteo.numeroSorteo = -1;
        this.objSorteo.aduana = new Datacatalogo();
        this.objSorteo.fechaInicioVigencia = fechaActual;
        this.objSorteo.fechaFinVigencia = fechaActual;
        this.objSorteo.anfora = new Datacatalogo();
        this.objSorteo.anfora.codDatacat = '-1';
        this.objSorteo.numeroCargaMaxima = 0;
        this.objSorteo.indIncluirFeriado = '0';
        this.objSorteo.tipoSorteo = '1';
        this.objSorteo.numMinutosIntervalo = 0;
        this.objSorteo.cantidadSorteos = 1;
        this.objSorteo.horarios = [];
        this.objSorteo.turno = new Turno();
        this.objSorteo.turno.unidadDespacho = new Unidaddespacho();
        this.cambiarCantidadHorarios();
      }
    });

    this.catalogoService.listarAduanas().subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.objSorteo.aduana.codDatacat = result.aduana;
      this.aduanas = result.listaAduanas as Datacatalogo[];
      if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.aduanas)) {
        //this.objSorteo.aduana.codDatacat = this.aduanas[0].cod_datacat;
        this.objAduanaSeleccionada = this.aduanas.find(element => element.cod_datacat == this.objSorteo.aduana.codDatacat);
        this.cargarUnidadesDespacho();
      }
    }, error => console.error(error));
  }

  seleccionarAduana(objSeleccionado) {
    this.objSorteo.aduana.codDatacat = objSeleccionado.target.value;
    if (objSeleccionado.target.value != "") {
      this.objAduanaSeleccionada = this.aduanas.find(element => element.cod_datacat == objSeleccionado.target.value);
      this.cargarUnidadesDespacho();
    }

  }

  seleccionarUnidadDespacho(objSeleccionado) {
    this.objSorteo.turno.unidadDespacho = this.unidadesDespacho[objSeleccionado.target.value];
    this.esProcesoEXPOEER = this.setProcesoExportacionEER();
    if (!this.esProcesoEXPOEER) this.cambiarHorarios();
    this.cambiarCantidadHorarios();
    this.cargarTurnos();
    this.cargarAnforas();
  }

  seleccionarAnfora(objSeleccionado) {
    this.objSorteo.anfora.codDatacat = objSeleccionado.target.value;
  }

  seleccionarTurno(objSeleccionado) {
    let turnoSeleccionado = this.turnos[objSeleccionado.target.value];
    this.objSorteo.turno.numTurno = turnoSeleccionado.numTurno;
    this.objSorteo.turno.hraFin = turnoSeleccionado.hraFin;
    this.objSorteo.turno.hraInicio = turnoSeleccionado.hraInicio;
  }

  setProcesoExportacionEER() {
    let esProcesoExpoEER: boolean = false;
    let unidadDespacho: Unidaddespacho = this.unidadesDespacho.find(x => x.numUnidadDespacho == this.objSorteo.turno.unidadDespacho.numUnidadDespacho);
    for (let regimen of unidadDespacho.regimenes) {
      if (FuncionesGenerales.getInstance().incluir(regimen.codDatacat, ConstantesCadenas.REGIMEN_EXPORTACION, ConstantesCadenas.REGIMEN_EER)) {
        esProcesoExpoEER = true;
        break;
      }
    }
    return esProcesoExpoEER;
  }

  cargarUnidadesDespacho() {
    if (this.objSorteo.aduana.codDatacat != "-1") {
      let campos: string = "numUnidadDespacho,nombre,regimenes";
      this.unidadDespachoService.listarUnidadesDespacho(this.objSorteo.aduana.codDatacat,
                                                        ConstantesCadenas.ESTADO_VIGENTE,
                                                        campos).subscribe(result => {
        FuncionesGenerales.getInstance().cerrarModalCargando();
        this.unidadesDespacho = result as Unidaddespacho[];
        //if (this.unidadesDespacho != null && this.unidadesDespacho != undefined && this.unidadesDespacho.length > 0) {
        if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.unidadesDespacho)) {
            this.unidadesDespacho = this.unidadesDespacho.sort(FuncionesGenerales.getInstance().ordenarPor("numUnidadDespacho", false)); //cchavezt ATENCION BUGS
          if (this.esCargaInicial) {
            this.objSorteo.turno.unidadDespacho = this.unidadesDespacho[0];
            this.esProcesoEXPOEER = this.setProcesoExportacionEER();
            if (this.esProcesoEXPOEER) this.cambiarCantidadHorarios();
          }
          this.cargarTurnos();
          this.cargarAnforas();
        } else {
          this.objSorteo.turno.unidadDespacho.numUnidadDespacho = -1
          this.objSorteo.turno.numTurno = -1
          this.objSorteo.turno.hraFin = '';
          this.objSorteo.turno.hraInicio = '';
          this.unidadesDespacho = [];
          this.turnos = [];
          let tituloErrores: string = "Mensaje de Error: ";
          let errorMensaje: string = "No existen unidades de despacho asignadas a la Aduana " + this.objAduanaSeleccionada.des_corta;
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                        tituloErrores, errorMensaje, "");
        }
      }, error => console.error(error));
    } else {
      this.objSorteo.turno.unidadDespacho.numUnidadDespacho = -1
      this.objSorteo.turno.numTurno = -1
      this.objSorteo.turno.hraFin = '';
      this.objSorteo.turno.hraInicio = '';
      this.unidadesDespacho = [];
      this.turnos = [];
    }
  }

  cargarAnforas() {
    if (this.objSorteo.turno.unidadDespacho.numUnidadDespacho == -1) {
      this.objSorteo.anfora.codDatacat = '-1';
      this.anforas = [];
    } else {
      this.catalogoService.listarAnforas(this.objSorteo.turno.unidadDespacho.numUnidadDespacho).subscribe(result => {
        FuncionesGenerales.getInstance().cerrarModalCargando();
        this.anforas = result as Datacatalogo[];
        if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.anforas)) {
          if(!this.esEdicion)
            this.objSorteo.anfora.codDatacat = this.anforas[0].cod_datacat;
        } else {
          this.objSorteo.anfora.codDatacat = "-1";
        }
      }, error => console.error(error));
    }
  }

  cargarTurnos() {
    if (this.objSorteo.turno.unidadDespacho.numUnidadDespacho == -1) {
      this.objSorteo.turno.numTurno = -1;
      this.objSorteo.turno.hraFin = '';
      this.objSorteo.turno.hraInicio = '';
      this.turnos = [];
    } else {
      let campos: string = "numTurno,nombre,hraInicio,hraFin";
      this.turnoService.listarTurnos(this.objSorteo.turno.unidadDespacho.numUnidadDespacho.toString(),
                                     ConstantesCadenas.ESTADO_VIGENTE, "", "",
                                     campos).subscribe(result => {
       FuncionesGenerales.getInstance().cerrarModalCargando();
       this.turnos = result as Turno[];
       //if(this.turnos.length > 0){
       if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.turnos)) {
         this.turnos = this.turnos.sort(FuncionesGenerales.getInstance().ordenarPor("hraInicio", false));
         if(this.esCargaInicial){
           this.objSorteo.turno.numTurno = this.turnos[0].numTurno;
           this.objSorteo.turno.hraFin = this.turnos[0].hraFin;
           this.objSorteo.turno.hraInicio = this.turnos[0].hraInicio;
         } else {
          this.esProcesoEXPOEER = this.setProcesoExportacionEER();
         }
       } else {
         this.turnos = [];
         this.objSorteo.turno.numTurno = -1;
         this.objSorteo.turno.hraFin = '';
         this.objSorteo.turno.hraInicio = '';
         let tituloErrores: string = "Mensajes de Error: ";
         let errorMensaje = "La unidad de despacho seleccionada no tiene turnos asociados.";
         FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                       tituloErrores, errorMensaje, "");
       }
      }, error => console.error(error));
    }
  }

  cambiarFechaInicio(objSeleccionado) {
    this.objSorteo.fechaInicioVigencia = objSeleccionado.value;
  }

  cambiarFechaFin(objSeleccionado) {
    this.objSorteo.fechaFinVigencia = objSeleccionado.value;
  }

  cambiarTipoSorteo() {
    if (this.objSorteo.tipoSorteo == ConstantesCadenas.TIPO_SORTEO_INTERVALOS) {
      this.setearSorteoIntervalos();
    } else {
      if (this.objSorteo.numMinutosIntervalo > 0) {
        Swal.fire({
          title: "Mensajes de Advertencia: ",
          text: "¿Desea seleccionar el intervalo por horarios fijos?",
          type: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          confirmButtonText: "SI",
          cancelButtonColor: '#d33',
          cancelButtonText: "NO"
        }).then((result) => {
          if (result.value) {
            this.setearSorteoIntervalos();
          } else {
            this.objSorteo.tipoSorteo = "0";
          }
        });
      } else {
        this.setearSorteoIntervalos();
      }
    }
  }

  setearSorteoIntervalos() {
    this.objSorteo.numMinutosIntervalo = 0;
    if (this.objSorteo.tipoSorteo == ConstantesCadenas.TIPO_SORTEO_INTERVALOS){
      this.objSorteo.cantidadSorteos =  0;
      this.objSorteo.horarios = [];
      this.objSorteo.tipoSorteo = '0';
    } else {
      this.objSorteo.tipoSorteo = '1';
      this.objSorteo.cantidadSorteos =  1;
      let horario: Horariosorteo;
      horario = new Horariosorteo();
      horario.numSecHorario = 1;
      if (this.esProcesoEXPOEER) {
        this.setHoraCorteSorteo(horario);
      } else {
        horario.horaCorte = this.txtHora15;
        horario.horaSorteo = this.txtHora15;
      }
      this.objSorteo.horarios = [horario];
    }
  }

  setHoraCorteSorteo(horario: Horariosorteo) {
    let fechaActual = new Date();
    this.txtHora = ("00" + fechaActual.getHours()).slice(-2) + ":" +
                   ("00" + fechaActual.getMinutes()).slice(-2) + ":" +
                   ("00" + fechaActual.getSeconds()).slice(-2);
    this.txtHora15 = this.txtHora.substring(0,5);
    let minuto15 = this.txtHora.substring(3,5);
    if ("00,05,10,15,20,25,30,35,40,45,50,55".indexOf(minuto15) < 0) {
      if (+minuto15 > 0 && +minuto15 < 5) {
        minuto15 = "00";
      } else if (+minuto15 > 5 && +minuto15 < 10) {
        minuto15 = "05";
      } else if (+minuto15 > 10 && +minuto15 < 15) {
        minuto15 = "10";
      } else if (+minuto15 > 15 && +minuto15 < 20) {
        minuto15 = "15";
      } else if (+minuto15 > 20 && +minuto15 < 25) {
        minuto15 = "20";
      } else if (+minuto15 > 25 && +minuto15 < 30) {
        minuto15 = "25";
      } else if (+minuto15 > 30 && +minuto15 < 35) {
        minuto15 = "30";
      } else if (+minuto15 > 35 && +minuto15 < 40) {
        minuto15 = "35";
      } else if (+minuto15 > 40 && +minuto15 < 45) {
        minuto15 = "40";
      } else if (+minuto15 > 45 && +minuto15 < 50) {
        minuto15 = "45";
      } else if (+minuto15 > 50 && +minuto15 < 55) {
        minuto15 = "50";
      } else if (+minuto15 > 55 && +minuto15 < 60) {
        minuto15 = "55";
      }
    }
    this.txtHora15 = this.txtHora.substring(0, 2) + ":" + minuto15;


    let fecActual = new Date(fechaActual.getFullYear(),
                             fechaActual.getMonth(),
                             fechaActual.getDate(),
                             +this.txtHora15.substring(0, 2),
                             +this.txtHora15.substring(3, 5),
                             0);
    let fecResult =
      FuncionesGenerales.getInstance().momentRestarHorasMinutos(fecActual,
        ConstantesCadenas.FORMATO_UNIDAD_TIEMPO_MINUTOS,
         5
      );

    horario.horaCorte = ("00" + fecResult.getHours()).slice(-2) + ":" +
                        ("00" + fecResult.getMinutes()).slice(-2);
    horario.horaSorteo = this.txtHora15;
  }

  cambiarCantidadHorarios(){
    if(!this.esEdicion && this.objSorteo.cantidadSorteos == undefined || this.objSorteo.cantidadSorteos < 1 || this.objSorteo.cantidadSorteos >= 50 || this.objSorteo.cantidadSorteos % 1 != 0){ //cchavezt ATENCION DE BUGS
      let tituloErrores: string = "Mensaje de Error: ";
      let errorMensaje = "La cantidad de sorteos en bloque, no es válida.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      this.objSorteo.cantidadSorteos = this.objSorteo.horarios.length;
    } else {
      let horarios: Horariosorteo[];
      horarios = this.objSorteo.horarios;
      this.objSorteo.horarios = [];
      for(let i = 0; i < this.objSorteo.cantidadSorteos; i++){
        if (i < horarios.length) {
          if (this.esProcesoEXPOEER) {
            let horario: Horariosorteo;
            horario = new Horariosorteo();
            horario.numSecHorario = -1;
            this.setHoraCorteSorteo(horario);
            this.objSorteo.horarios[i] = horario;
          } else {
            this.objSorteo.horarios[i] = horarios[i];
          }
        } else{
          let horario: Horariosorteo;
          horario = new Horariosorteo();
          horario.numSecHorario = -1;
          if (this.esProcesoEXPOEER) {
            this.setHoraCorteSorteo(horario);
          } else {
            horario.horaCorte = this.txtHora15;
            horario.horaSorteo = this.txtHora15;
          }
          this.objSorteo.horarios[i]=horario;
        }
      }
    }
  }

  cambiarHoraCorte(indice: number, objSeleccionado: any){
    if (this.esProcesoEXPOEER) {
      objSeleccionado.currentTarget.value = this.obtenerHorarioCorteCorrectoEXPOEER(objSeleccionado.currentTarget.value);
    } else {
      objSeleccionado.currentTarget.value = this.obtenerHorarioCorteCorrecto(objSeleccionado.currentTarget.value);
    }
    this.objSorteo.horarios[indice].horaCorte = objSeleccionado.currentTarget.value;
    this.mensajeValidacionHorarioCorteDiaAnterior(this.objSorteo.horarios[indice].horaCorte,
                                                  this.objSorteo.horarios[indice].horaSorteo);
  }

  cambiarHoraSorteo(indice: number, objSeleccionado: any) {
    if (this.esProcesoEXPOEER) {
      objSeleccionado.currentTarget.value = this.obtenerHorarioCorrectoEXPOEER(objSeleccionado.currentTarget.value);
    } else {
      objSeleccionado.currentTarget.value = this.obtenerHorarioCorrecto(objSeleccionado.currentTarget.value);
    }
    this.objSorteo.horarios[indice].horaSorteo = objSeleccionado.currentTarget.value;
    this.mensajeValidacionHorarioCorteDiaAnterior(this.objSorteo.horarios[indice].horaCorte,
                                                  this.objSorteo.horarios[indice].horaSorteo);
  }

  mensajeValidacionHorarioCorteDiaAnterior(horaCorte: string, horaSorteo: string) {
    let fechaCorte: Date = new Date();
    let fechaSorteo: Date = new Date();
    if (horaCorte.indexOf(":") > 0 && horaSorteo.indexOf(":") > 0) {
      fechaCorte.setHours(parseInt(horaCorte.split(':')[0]));
      fechaCorte.setMinutes(parseInt(horaCorte.split(':')[1]));
      fechaCorte.setSeconds(0);

      fechaSorteo.setHours(parseInt(horaSorteo.split(':')[0]));
      fechaSorteo.setMinutes(parseInt(horaSorteo.split(':')[1]));
      fechaSorteo.setSeconds(0);

      if (fechaCorte > fechaSorteo) {
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ADVERTENCIA,
                                                                     "Advertencia: ",
                                                                     "Horario de corte del día anterior", "");
      }
    }
  }

  obtenerHorarioCorrectoEXPOEER(horario: string) {
    let tituloErrores: string = "Mensaje de Error: ";
    let errorMensaje;
    let hora;
    let minuto;
    let tieneError: boolean = false;
    if (horario == undefined){
      errorMensaje = "El horario ingresado no es válido";
      let fechaActual = new Date();
      hora = ("00" + fechaActual.getHours()).slice(-2);
      minuto = "00";
      tieneError = true;
    } else {
      hora = horario.substring(0,2);
      minuto = horario.substring(3,5);
      if ("00,05,10,15,20,25,30,35,40,45,50,55".indexOf(minuto) < 0){
        errorMensaje = "Los horarios del sorteo deben ser múltiplo de 5";
        tieneError = true;
        if (+minuto > 0 && +minuto < 5) {
          minuto = "00";
        } else if (+minuto > 5 && +minuto < 10) {
          minuto = "10";
        } else if (+minuto > 10 && +minuto < 15) {
          minuto = "15";
        } else if (+minuto > 15 && +minuto < 20) {
          minuto = "20";
        } else if (+minuto > 20 && +minuto < 25) {
          minuto = "25";
        } else if (+minuto > 25 && +minuto < 30) {
          minuto = "30";
        } else if (+minuto > 30 && +minuto < 35) {
          minuto = "35";
        } else if (+minuto > 35 && +minuto < 40) {
          minuto = "40";
        } else if (+minuto > 40 && +minuto < 45) {
          minuto = "45";
        } else if (+minuto > 45 && +minuto < 50) {
          minuto = "50";
        } else if (+minuto > 50 && +minuto < 55) {
          minuto = "55";
        }
      }
    }
    if(tieneError)
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR, tituloErrores, errorMensaje, "");
    return hora + ":" + minuto;
  }

  obtenerHorarioCorrecto(horario: string){
    let tituloErrores: string = "Mensaje de Error: ";
    let errorMensaje;
    let hora;
    let minuto;
    let tieneError: boolean = false;
    if(horario == undefined){
      errorMensaje = "El horario ingresado no es válido";
      let fechaActual = new Date();
      hora = ("00" + fechaActual.getHours()).slice(-2);
      minuto = "00";
      tieneError = true;
    }else{
      hora = horario.substring(0,2);
      minuto = horario.substring(3,5);
      if("00,15,30,45".indexOf(minuto) < 0){
        errorMensaje = "Los horarios del sorteo deben ser múltiplo de 15";
        tieneError = true;
        if(+minuto > 0 && +minuto < 15){
          minuto = "00";
        }else if(+minuto > 15 && +minuto < 30){
          minuto = "15";
        }else if(+minuto > 30 && +minuto < 45){
          minuto = "30";
        }else if(+minuto > 45 && +minuto < 60){
          minuto = "45";
        }
      }
    }
    if(tieneError)
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR, tituloErrores, errorMensaje, "");
    return hora + ":" + minuto;
  }

  obtenerHorarioCorteCorrectoEXPOEER(horario: string) {
    let tituloErrores: string = "Mensaje de Error: ";
    let errorMensaje;
    let hora;
    let minuto;
    let tieneError: boolean = false;
    if (horario == undefined){
      errorMensaje = "El horario ingresado no es válido";
      let fechaActual = new Date();
      hora = ("00" + fechaActual.getHours()).slice(-2);
      minuto = "00";
      tieneError = true;
    } else {
      hora = horario.substring(0,2);
      minuto = horario.substring(3,5);
      if ("00,05,10,15,20,25,30,35,40,45,50,55".indexOf(minuto) < 0) {
        errorMensaje = "Los horarios de la hora de corte del sorteo deben ser múltiplo de 5";
        tieneError = true;
        if (+minuto > 0 && +minuto < 5) {
          minuto = "00";
        } else if (+minuto > 5 && +minuto < 10) {
          minuto = "10";
        } else if (+minuto > 10 && +minuto < 15) {
          minuto = "15";
        } else if (+minuto > 15 && +minuto < 20) {
          minuto = "20";
        } else if (+minuto > 20 && +minuto < 25) {
          minuto = "25";
        } else if (+minuto > 25 && +minuto < 30) {
          minuto = "30";
        } else if (+minuto > 30 && +minuto < 35) {
          minuto = "35";
        } else if (+minuto > 35 && +minuto < 40) {
          minuto = "40";
        } else if (+minuto > 40 && +minuto < 45) {
          minuto = "45";
        } else if (+minuto > 45 && +minuto < 50) {
          minuto = "50";
        } else if (+minuto > 50 && +minuto < 55) {
          minuto = "55";
        }
      }
    }
    if(tieneError)
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR, tituloErrores, errorMensaje, "");
    return hora + ":" + minuto;
  }

  obtenerHorarioCorteCorrecto(horario: string){
    let tituloErrores: string = "Mensaje de Error: ";
    let errorMensaje;
    let hora;
    let minuto;
    let tieneError: boolean = false;
    if (horario == undefined){
      errorMensaje = "El horario ingresado no es válido";
      let fechaActual = new Date();
      hora = ("00" + fechaActual.getHours()).slice(-2);
      minuto = "00";
      tieneError = true;
    } else {
      hora = horario.substring(0,2);
      minuto = horario.substring(3,5);
      if ("00,15,30,45".indexOf(minuto) < 0) {
        errorMensaje = "Los horarios de la hora de corte del sorteo deben ser múltiplo de 15";
        tieneError = true;
        if (+minuto > 0 && +minuto < 15) {
          minuto = "00";
        } else if (+minuto > 15 && +minuto < 30) {
          minuto = "15";
        } else if (+minuto > 30 && +minuto < 45) {
          minuto = "30";
        } else if (+minuto > 45 && +minuto < 60) {
          minuto = "45";
        }
      }
    }
    if(tieneError)
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR, tituloErrores, errorMensaje, "");
    return hora + ":" + minuto;
  }

  darFormatoHorario() {
    for (let i = 0; i < this.objSorteo.horarios.length; i++) {
      this.objSorteo.horarios[i].horaCorte = this.objSorteo.horarios[i].horaCorte.substring(0, 5);
      this.objSorteo.horarios[i].horaSorteo = this.objSorteo.horarios[i].horaSorteo.substring(0, 5);
    }
  }

  registrar(){
    if(this.validarDatos()){
      this.darFormatoHorario();
      this.objSorteo.esProcesoSalida = this.esProcesoEXPOEER;
      this.sorteoService.registrarActualizarSorteo(this.objSorteo).subscribe(
        response => {
          console.log(response);
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(
            ConstantesCadenas.MENSAJE_EXITOSO,
            "El sorteo se " + (this.objSorteo.numeroSorteo == -1 ? "registró" : "modificó") + " correctamente.", "", "", this.callback);
          /*if(this.esEdicion) {
            this.location.back();
          } else {
            setTimeout(() => { this.ngOnInit(); }, 2000);
          }*/
        },
        errorResult => {
          if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
            let responseManager: ResponseManager = new ResponseManager();
            this.responseErrorManager = errorResult as ResponseErrorManager;
            responseManager.cod = errorResult.cod;
            responseManager.errors = [this.responseErrorManager];
            this.responseManager = responseManager;
          } else {
            this.responseManager = errorResult as ResponseManager;
          }
          if (this.responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO ||
              this.responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
            FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                         "Mensajes de Error: ",
                                                                          "",
                                                                          FuncionesGenerales.getInstance().mostrarTablaDeErrores(this.responseManager.errors));
          }
        }
      );
    }
  }

  callback = () : void => {
    if(this.esEdicion)
      this.location.back();
    else
      this.ngOnInit();
  };

  cancelar() {
    if(this.esEdicion) {
      Swal.fire({
        title: "Mensajes de Advertencia: ",
        text: "¿Está seguro de salir sin grabar los cambios?",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        confirmButtonText: "SI",
        cancelButtonColor: '#d33',
        cancelButtonText: "NO"
      }).then((result) => {
        if (result.value) {
          this.location.back();
        }
      });
    } else{
      this.ngOnInit();
    }
  }

  validarDatos(){
    let tituloErrores: string = "Mensajes de Error: ";
    let errorMensaje;
    if(this.objSorteo.turno.unidadDespacho.numUnidadDespacho == -1){
      errorMensaje = "Debe seleccionar unidad de despacho";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }else if(this.objSorteo.fechaFinVigencia == undefined || this.objSorteo.fechaFinVigencia == null){
      errorMensaje = "Ingrese fecha de inicio de vigencia";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }else if(!this.esFechaInicioMenor && (new Date()).setHours(0,0,0,0) > this.objSorteo.fechaInicioVigencia.setHours(0,0,0,0)){
      errorMensaje = "La fecha de inicio de vigencia de los parámetros para el sorteo y asignación en bloque debe ser mayor o igual a la fecha en que se registra";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }else if(this.objSorteo.fechaInicioVigencia.setHours(0,0,0,0) > this.objSorteo.fechaFinVigencia.setHours(0,0,0,0)){
      errorMensaje = "La fecha de término de vigencia de los parámetros para el sorteo y asignación en Bloque debe ser mayor o igual a la fecha de inicio de vigencia";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }else if(this.objSorteo.anfora.codDatacat == '-1'){
      errorMensaje = "Debe seleccionar ánfora";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }else if(this.objSorteo.numeroCargaMaxima == undefined ||
             this.objSorteo.numeroCargaMaxima == null ||
             this.objSorteo.numeroCargaMaxima < 0 ||
             !FuncionesGenerales.getInstance().esEntero(this.objSorteo.numeroCargaMaxima.toString())){
      errorMensaje = "La cantidad máxima de carga laboral, no es válida";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }else if(this.objSorteo.numeroCargaMaxima > 999){
      errorMensaje = "La cantidad máxima de carga laboral, no debe ser mayor que 999";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }
    if (this.objSorteo.tipoSorteo == ConstantesCadenas.TIPO_SORTEO_INTERVALOS) {

      if (this.esProcesoEXPOEER) {
        if (this.objSorteo.numMinutosIntervalo == undefined ||
            this.objSorteo.numMinutosIntervalo == null ||
            this.objSorteo.numMinutosIntervalo < 10) {
          errorMensaje = "Intervalo de tiempo entre sorteos debe de ser mayor o igual que 10 minutos";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                      tituloErrores, errorMensaje, "");
          return false;
        } else if (this.objSorteo.numMinutosIntervalo % 5 != 0) {
          errorMensaje = "El intervalo de tiempo ingresado debe ser múltiplo de 5";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                      tituloErrores, errorMensaje, "");
          return false;
        }
      } else {
        if (this.objSorteo.numMinutosIntervalo == undefined ||
            this.objSorteo.numMinutosIntervalo == null ||
            this.objSorteo.numMinutosIntervalo < 30) {
          errorMensaje = "Intervalo de tiempo entre sorteos debe de ser mayor o igual que 30 minutos";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                      tituloErrores, errorMensaje, "");
          return false;
        } else if(this.objSorteo.numMinutosIntervalo % 15 != 0) {
          errorMensaje = "El intervalo de tiempo ingresado debe ser múltiplo de 15";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                      tituloErrores, errorMensaje, "");
          return false;
        }
      }
    } else {
      if(this.objSorteo.cantidadSorteos == undefined ||
          this.objSorteo.cantidadSorteos == null ||
          this.objSorteo.cantidadSorteos < 0 ||
          this.objSorteo.cantidadSorteos > 50){
        errorMensaje = "La cantidad de sorteos en bloque, no es válida";
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    tituloErrores, errorMensaje, "");
        return false;
      } else {
        let faltanDatos = false;
        let horaFueraRango = false;
        let horaInicioTurno = this.objSorteo.turno.hraInicio;
        horaInicioTurno = horaInicioTurno.replace(':','');
        let horaFinTurno = this.objSorteo.turno.hraFin;
        horaFinTurno = horaFinTurno.replace(':','');
        let mismoDia = +horaInicioTurno < +horaFinTurno;
        let horaCorteLst;
        let horaSorteoLst;
        for(let i = 0; i < this.objSorteo.cantidadSorteos; i++){
          if(this.objSorteo.horarios[i].horaCorte == undefined || this.objSorteo.horarios[i].horaCorte == null ||
            this.objSorteo.horarios[i].horaSorteo == undefined || this.objSorteo.horarios[i].horaSorteo == null)
            faltanDatos = true;
          else{
            horaCorteLst = this.objSorteo.horarios[i].horaCorte;
            horaSorteoLst = this.objSorteo.horarios[i].horaSorteo;
            horaCorteLst = horaCorteLst.replace(':','');
            horaSorteoLst = horaSorteoLst.replace(':','');
            if((mismoDia && (+horaCorteLst < +horaInicioTurno || +horaCorteLst > +horaFinTurno || +horaSorteoLst < +horaInicioTurno || +horaSorteoLst > +horaFinTurno)) ||
              (!mismoDia && ((+horaCorteLst < +horaInicioTurno && +horaCorteLst > +horaFinTurno) || (+horaSorteoLst < +horaInicioTurno && +horaSorteoLst > +horaFinTurno)))){
              horaFueraRango = true;
            }
          }
        }
        if(faltanDatos){
          errorMensaje = "Debe ingresar todos los horarios de sorteo";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                      tituloErrores, errorMensaje, "");
          return false;
        }
        if(horaFueraRango){
          errorMensaje = "Los horarios ingresados deben de encontrarse dentro del horario del turno seleccionado";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                      tituloErrores, errorMensaje, "");
          return false;
        }

        if (this.validarTraslapeHorarioSorteo()) {
          errorMensaje = "Los horarios de los sorteos no deben traslaparse.";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                      tituloErrores, errorMensaje, "");
          return false;
        }

        if (this.validarHorarioSorteoAscendente() == 1) {
          errorMensaje = "Los horarios de corte deben registrarse de forma ascendente.";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                      tituloErrores, errorMensaje, "");
          return false;
        }

        if (this.validarHorarioSorteoAscendente() == 2) {
          errorMensaje = "Los horarios de sorteo deben registrarse de forma ascendente.";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                      tituloErrores, errorMensaje, "");
          return false;
        }
      }
    }
    return true;
  }

  validarHorarioSorteoAscendente() {
    let horaCorteLst;
    let horaCorteAnt;
    let horaSorteoLst;
    let horaSorteoAnt;
    let valHoraCorte;
    for (let i = 0; i < this.objSorteo.cantidadSorteos; i++) {
      horaCorteLst = this.objSorteo.horarios[i].horaCorte;
      horaSorteoLst = this.objSorteo.horarios[i].horaSorteo;
      horaCorteLst = horaCorteLst.replace(':','');
      horaSorteoLst = horaSorteoLst.replace(':','');

      if (+horaCorteLst > +horaSorteoLst) {
        valHoraCorte = +horaCorteLst;
      } else {
        valHoraCorte = 1440 + +horaCorteLst;
      }

      if (i > 0) {
        if (+horaSorteoLst < horaSorteoAnt) {
          return 2;
        }

        if (valHoraCorte < horaCorteAnt) {
          return 1;
        }
      }
      horaSorteoAnt = +horaSorteoLst;
      horaCorteAnt = valHoraCorte;
    }
    return 0;
  }

  validarCargaMaximaFuncionarios(objSeleccionado) {
    if (objSeleccionado.target.value < 0 || !FuncionesGenerales.getInstance().esEntero(objSeleccionado.target.value.toString())) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  "Mensaje de Error: ", "La cantidad máxima de carga laboral, no es válida.", "");
    } else if(objSeleccionado.target.value > 999) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  "Mensaje de Error: ", "La cantidad máxima de carga laboral, no debe ser mayor que 999.", "");
    }
  }

  validarTraslapeHorarioSorteo() {
    let esHorarioTraslapado: boolean = false;
      if (this.objSorteo.horarios.length > 0) {
        this.objSorteo.horarios.map(x => {
          let horaCorte: number = FuncionesGenerales.getInstance().convertirHoraCorteSorteoAEntero(x.horaCorte);
          let horaSorteo: number = FuncionesGenerales.getInstance().convertirHoraCorteSorteoAEntero(x.horaSorteo);
          if (horaSorteo < horaCorte) {
            horaSorteo = horaSorteo + 2400;
          }
          this.objSorteo.horarios.map(y => {
            if (y.numSecHorario != x.numSecHorario) {
              let horaCorteY: number = FuncionesGenerales.getInstance().convertirHoraCorteSorteoAEntero(y.horaCorte);
              let horaSorteoY: number = FuncionesGenerales.getInstance().convertirHoraCorteSorteoAEntero(y.horaSorteo);
              if (horaSorteoY < horaCorteY) {
                horaSorteoY = horaSorteoY + 2400;
              }
              if (
                  (horaCorte >= horaCorteY &&
                    horaCorte <= horaSorteoY) ||
                  (horaSorteo >= horaCorteY &&
                    horaSorteo <= horaSorteoY)
                 ) {
                esHorarioTraslapado = true;
              }
            }
        });
        return esHorarioTraslapado;
      });
    }
    return esHorarioTraslapado;
  }

  cambiarHorarios() {
    let fechaActual = new Date();
    this.txtFecha = ("00" + fechaActual.getDate()).slice(-2) + "/" +
                    ("00" + (fechaActual.getMonth() + 1)).slice(-2) + "/" +
                    fechaActual.getFullYear();
    this.txtHora = ("00" + fechaActual.getHours()).slice(-2) + ":" +
                   ("00" + fechaActual.getMinutes()).slice(-2) + ":" +
                   ("00" + fechaActual.getSeconds()).slice(-2);
    this.txtHora15 = this.txtHora.substring(0, 5);
    let minuto15 = this.txtHora.substring(3, 5);
    if ("00,15,30,45".indexOf(minuto15) < 0) {
      if (+minuto15 > 0 && +minuto15 < 15) {
        minuto15 = "00";
      } else if (+minuto15 > 15 && +minuto15 < 30) {
        minuto15 = "15";
      } else if (+minuto15 > 30 && +minuto15 < 45) {
        minuto15 = "30";
      } else if (+minuto15 > 45 && +minuto15 < 60) {
        minuto15 = "45";
      }
    }
    this.txtHora15 = this.txtHora.substring(0,2) + ":" + minuto15;
  }
}
