import { Component, OnInit, ViewChild } from '@angular/core';
import { setTheme } from 'ngx-bootstrap/utils';
import { Datacatalogo } from 'src/app/models/datacatalogo';
import { Sorteo } from 'src/app/models/sorteo';
import { Unidaddespacho } from 'src/app/models/unidaddespacho';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { ConstantesCadenas } from 'src/app/utils/constantescadenas';
import { Turno } from 'src/app/models/turno';
import { ResponseManager } from 'src/app/models/responsemanager';
import { ResponseErrorManager } from 'src/app/models/responseerrormanager';
import { MatTableDataSource } from '@angular/material';
import { ConstantesListas } from 'src/app/utils/constanteslistas';
import { SorteoService } from 'src/app/services/sorteo.service';
import { Router } from '@angular/router';
import { CatalogoService } from 'src/app/services/catalogo.service';
import { UnidaddespachoService } from 'src/app/services/unidaddespacho.service';
import { TurnoService } from 'src/app/services/turno.service';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { Horariosorteo } from 'src/app/models/horariosorteo';

@Component({
  selector: 'app-consulta-sorteo',
  templateUrl: './consulta-sorteo.component.html',
  styleUrls: ['./consulta-sorteo.component.css']
})
export class ConsultaSorteoComponent implements OnInit {
  @ViewChild('modalHorarios') modalHorarios: ModalDirective;
  responseManager: ResponseManager;
  responseErrorManager: ResponseErrorManager;
  aduanas: Datacatalogo[];
  anforas: Datacatalogo[];
  objAduanaSeleccionada: Datacatalogo;
  unidadesDespacho: Unidaddespacho[];
  turnos: Turno[];
  txtFecha: string;
  txtHora: string;
  objSorteoConsulta: Sorteo;
  sorteosDS: MatTableDataSource<Sorteo>;
  displayedColumns: string[];
  displayedColumnsHorarios: string[];
  funcionesGenerales: FuncionesGenerales;
  txtTitulo: string;
  esConsulta: boolean;
  esConsultaModificacion: boolean=true; //cchavezt
  tieneDatos: boolean;
  horariosDS: MatTableDataSource<Horariosorteo>;

  constructor(private sorteoService: SorteoService,
              private catalogoService: CatalogoService,
              private unidadDespachoService: UnidaddespachoService,
              private turnoService: TurnoService,
              private router: Router) {
    setTheme('bs4');
  }

  ngOnInit() {
    this.anforas = [];

    let fechaActual = new Date();
    this.txtFecha = ("00" + fechaActual.getDate()).slice(-2) + "/" +
                    ("00" + (fechaActual.getMonth() + 1)).slice(-2) + "/" +
                    fechaActual.getFullYear();
    this.txtHora = ("00" + fechaActual.getHours()).slice(-2) + ":" +
                   ("00" + fechaActual.getMinutes()).slice(-2) + ":" +
                   ("00" + fechaActual.getSeconds()).slice(-2);
    this.objSorteoConsulta = new Sorteo();
    this.objSorteoConsulta.numeroSorteo = -1;
    this.objSorteoConsulta.aduana = new Datacatalogo();
    this.objSorteoConsulta.fechaInicioVigencia = fechaActual;
    this.objSorteoConsulta.fechaFinVigencia = fechaActual;
    this.objSorteoConsulta.anfora = new Datacatalogo();
    this.objSorteoConsulta.anfora.codDatacat = '-1';
    this.objSorteoConsulta.turno = new Turno();
    this.objSorteoConsulta.turno.unidadDespacho = new Unidaddespacho();

    this.catalogoService.listarAduanas().subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.objSorteoConsulta.aduana.codDatacat = result.aduana;
      this.aduanas = result.listaAduanas as Datacatalogo[];
      if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.aduanas)) {
        //this.objSorteoConsulta.aduana.codDatacat = this.aduanas[0].cod_datacat;
        this.objAduanaSeleccionada = this.aduanas.find(element => element.cod_datacat == this.objSorteoConsulta.aduana.codDatacat);
        this.cargarUnidadesDespacho();
      }
    }, error => console.error(error));

    this.funcionesGenerales = FuncionesGenerales.getInstance();
    this.esConsulta = sessionStorage.getItem('pagina') == 'consulta-sorteo';
    this.txtTitulo = (this.esConsulta ? "CONSULTA" : "MODIFICACIÓN") + " DE PARÁMETROS PARA EL SORTEO Y ASIGNACIÓN";
    this.displayedColumns = this.esConsulta ? ConstantesListas.COLUMNAS_GRID_SORTEOS_CONSULTA : ConstantesListas.COLUMNAS_GRID_SORTEOS_EDICION;
    this.tieneDatos = false;
    this.sorteosDS = new MatTableDataSource<Sorteo>();
  }

  seleccionarAduana(objSeleccionado) {
    this.objSorteoConsulta.aduana.codDatacat = objSeleccionado.target.value;
    if (objSeleccionado.target.value != "") {
      this.objAduanaSeleccionada = this.aduanas.find(element => element.cod_datacat == objSeleccionado.target.value);
      this.cargarUnidadesDespacho();
    }
  }

  seleccionarUnidadDespacho(objSeleccionado) {
    this.objSorteoConsulta.turno.unidadDespacho = this.unidadesDespacho[objSeleccionado.target.value];
    this.cargarTurnos();
    this.cargarAnforas();
  }

  seleccionarAnfora(objSeleccionado) {
    this.objSorteoConsulta.anfora.codDatacat = objSeleccionado.target.value;
  }

  seleccionarTurno(objSeleccionado) {
    let turnoSeleccionado = this.turnos[objSeleccionado.target.value];
    this.objSorteoConsulta.turno.numTurno = turnoSeleccionado.numTurno;
    this.objSorteoConsulta.turno.hraFin = turnoSeleccionado.hraFin;
    this.objSorteoConsulta.turno.hraInicio = turnoSeleccionado.hraInicio;
  }

  cargarUnidadesDespacho() {
    if (this.objSorteoConsulta.aduana.codDatacat != "-1") {
      let campos: string = "numUnidadDespacho,nombre";
      this.unidadDespachoService.listarUnidadesDespacho(this.objSorteoConsulta.aduana.codDatacat,
                                                        ConstantesCadenas.ESTADO_VIGENTE,
                                                        campos).subscribe(result => {
        FuncionesGenerales.getInstance().cerrarModalCargando();
        this.unidadesDespacho = result as Unidaddespacho[];
        //if (this.unidadesDespacho != null && this.unidadesDespacho != undefined && this.unidadesDespacho.length > 0) {
        if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.unidadesDespacho)) {
          this.unidadesDespacho = this.unidadesDespacho.sort(FuncionesGenerales.getInstance().ordenarPor("numUnidadDespacho", false)); //cchavezt ATENCION BUGS
          this.objSorteoConsulta.turno.unidadDespacho = this.unidadesDespacho[0];
          this.cargarTurnos();
          this.cargarAnforas();
        } else {
          this.objSorteoConsulta.turno.unidadDespacho.numUnidadDespacho = -1
          this.objSorteoConsulta.turno.numTurno = -1
          this.unidadesDespacho = [];
          this.turnos = [];
          let tituloErrores: string = "Mensaje de Error: ";
          let errorMensaje: string = "No existen unidades de despacho asignadas a la Aduana " + this.objAduanaSeleccionada.des_corta;
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                        tituloErrores, errorMensaje, "");
        }
      }, error => console.error(error));
    } else {
      this.objSorteoConsulta.turno.unidadDespacho.numUnidadDespacho = -1
      this.objSorteoConsulta.turno.numTurno = -1
      this.unidadesDespacho = [];
      this.turnos = [];
    }
  }

  cargarAnforas() {
    if (this.objSorteoConsulta.turno.unidadDespacho.numUnidadDespacho == -1) {
      this.objSorteoConsulta.anfora.codDatacat = '-1';
      this.anforas = [];
    } else {
      this.catalogoService.listarAnforas(this.objSorteoConsulta.turno.unidadDespacho.numUnidadDespacho).subscribe(result => {
        FuncionesGenerales.getInstance().cerrarModalCargando();
        this.anforas = result as Datacatalogo[];
      }, error => console.error(error));
    }
  }

  cargarTurnos() {
    if (this.objSorteoConsulta.turno.unidadDespacho.numUnidadDespacho == -1) {
      this.objSorteoConsulta.turno.numTurno = -1;
      this.turnos = [];
    } else {
      let campos: string = "numTurno,nombre,hraInicio,hraFin";
      this.turnoService.listarTurnos(this.objSorteoConsulta.turno.unidadDespacho.numUnidadDespacho.toString(),
                                     ConstantesCadenas.ESTADO_VIGENTE, "", "",
                                    campos).subscribe(result => {
        FuncionesGenerales.getInstance().cerrarModalCargando();
        this.turnos = result as Turno[];
        //if (this.turnos != null && this.turnos != undefined && this.turnos.length > 0){
        if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.turnos)) {
          this.turnos = this.turnos.sort(FuncionesGenerales.getInstance().ordenarPor("hraInicio", false));
          this.objSorteoConsulta.turno.numTurno = this.turnos[0].numTurno;
        } else {
          this.turnos = [];
          this.objSorteoConsulta.turno.numTurno = -1;
          let tituloErrores: string = "Mensajes de Error: ";
          let errorMensaje = "La unidad de despacho seleccionada no tiene turnos asociados.";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                        tituloErrores, errorMensaje, "");
        }
      }, error => console.error(error));
    }
  }

  cambiarFechaInicio(objSeleccionado){
    this.objSorteoConsulta.fechaInicioVigencia = objSeleccionado.value;
  }

  cambiarFechaFin(objSeleccionado){
    this.objSorteoConsulta.fechaFinVigencia = objSeleccionado.value;
  }

  esSorteoEditable(sorteo: Sorteo){
    let fechaActual = new Date();
    let fechaFin = new Date(sorteo.fechaFinVigencia);
    return fechaFin.setHours(0,0,0,0) >= fechaActual.setHours(0,0,0,0);
  }

  consultar(){
    if(this.validarDatos()){
      this.sorteoService.listarSorteos(this.objSorteoConsulta).subscribe(result => {
          FuncionesGenerales.getInstance().cerrarModalCargando();
          let lstSorteo : Sorteo[] = result as Sorteo[];
          if (lstSorteo.length == 0) {
            FuncionesGenerales.getInstance().mensajeRegistrosNoEncontrados();
          }
          this.sorteosDS = new MatTableDataSource<Sorteo>(lstSorteo);
          this.tieneDatos = lstSorteo.length > 0;
      }, error => console.error(error));
    }
  }

  cancelar(){
    this.ngOnInit();
  }

  validarDatos(){
    let tituloErrores: string = "Mensajes de Error: ";
    let errorMensaje;
    if(this.objSorteoConsulta.turno.unidadDespacho.numUnidadDespacho == -1){
      errorMensaje = "Debe seleccionar unidad de despacho";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }else if(this.objSorteoConsulta.fechaFinVigencia == undefined || this.objSorteoConsulta.fechaFinVigencia == null){
      errorMensaje = "Ingrese fecha de inicio de vigencia";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }else if(this.objSorteoConsulta.fechaInicioVigencia.setHours(0,0,0,0) > this.objSorteoConsulta.fechaFinVigencia.setHours(0,0,0,0)){
      errorMensaje = "La fecha de término de vigencia de los parámetros para el sorteo y asignación en Bloque debe ser mayor o igual a la fecha de inicio de vigencia";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }else if(this.objSorteoConsulta.anfora.codDatacat == '-1'){
      errorMensaje = "Debe seleccionar ánfora";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }
    return true;
  }

  modificarSorteo(sorteoEditar: Sorteo){
    this.sorteoService.obtenerSorteo(sorteoEditar.numeroSorteo).subscribe(
      result => {
          FuncionesGenerales.getInstance().cerrarModalCargando();
          sorteoEditar = result.find(x => x.numeroSorteo == sorteoEditar.numeroSorteo);
          sessionStorage.setItem('numSorteo', JSON.stringify(sorteoEditar));
          this.router.navigate(['/modificar-sorteo/', JSON.stringify("1")]);
      }, error => console.error(error)
    );
  }

  exportar() {
    this.exportarPDFExcel(ConstantesCadenas.NOMBRE_REPORTE_CONSULTA_SORTEO_ASIGNACION_XLS, ConstantesCadenas.TIPO_MIME_EXCEL);
  }

  imprimir() {
    this.exportarPDFExcel(ConstantesCadenas.NOMBRE_REPORTE_CONSULTA_SORTEO_ASIGNACION_PDF, ConstantesCadenas.TIPO_MIME_PDF);
  }

  exportarPDFExcel(nombreSorteoAsignacion: string, tipoMime: string) {
    let tipoReporte: string = tipoMime == ConstantesCadenas.TIPO_MIME_EXCEL ? ConstantesCadenas.TIPO_REPORTE_XLS : ConstantesCadenas.TIPO_REPORTE_PDF;
    this.reporteSorteosYAsignacion(tipoReporte, nombreSorteoAsignacion, tipoMime);
  }

  reporteSorteosYAsignacion(tipoReporte: string, nombreSorteoAsignacion: string, tipoMime: string) {
    this.sorteoService.reporteSorteosYAsignacion(
      tipoReporte,
      "numSorteo,turno,unidadDespacho,anfora,fechaInicio,fechaFin,numCargaMaxima,horarios,tipoSorteo",
      this.objSorteoConsulta
    ).subscribe(response => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      if (response != undefined && response != null) {
        let strBase64 = FuncionesGenerales.getInstance().base64ToArrayBuffer(response);
        FuncionesGenerales.getInstance().saveByteArray(nombreSorteoAsignacion, strBase64, tipoMime);
      } else {
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    "Mensajes de Error: ",
                                                                    "Ocurrio un error, comuníquese con el área de sistemas", '');
      }
    },
    errorResult => {
      if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
        let responseManager: ResponseManager = new ResponseManager();
        this.responseErrorManager = errorResult as ResponseErrorManager;
        responseManager.cod = errorResult.cod;
        responseManager.errors = [this.responseErrorManager];
        this.responseManager = responseManager;
        this.cargarMensajesSorteoAsignacion(this.responseManager);
      } else {
        this.responseManager = errorResult as ResponseManager;
        this.cargarMensajesSorteoAsignacion(this.responseManager);
      }
    });
  }

  cargarMensajesSorteoAsignacion(responseManager: ResponseManager) {
    if (responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO ||
        responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                   'Mensajes de Error: ',
                                                                    '',
                                                                    FuncionesGenerales.getInstance().mostrarTablaDeErrores(this.responseManager.errors));
    }
  }

  verHorarios(horarios: Horariosorteo[]) {
    this.displayedColumnsHorarios = ConstantesListas.COLUMNAS_GRID_HORARIOS;
    this.horariosDS = new MatTableDataSource<Horariosorteo>(horarios);
    this.modalHorarios.show();
  }

  cerrarModalHorarios() {
    this.modalHorarios.hide();
  }
}
