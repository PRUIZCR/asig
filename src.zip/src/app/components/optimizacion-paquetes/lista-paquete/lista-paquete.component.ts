import { Component, OnInit, Input } from '@angular/core';
import { TmpPaquete } from 'src/app/models/TmpPaquete';
import { ConstantesListas } from 'src/app/utils/constanteslistas';

@Component({
  selector: 'app-lista-paquete',
  templateUrl: './lista-paquete.component.html',
  styleUrls: ['./lista-paquete.component.css']
})
export class ListaPaqueteComponent implements OnInit {
  @Input() paquete: TmpPaquete;
  displayedColumns: string[];
  constructor() { }

  ngOnInit() {
    this.displayedColumns = ConstantesListas.COLUMNAS_GRID_DECLARACIONES;
  }

  isAllSelected() {
    const numSelected = this.paquete.selection.selected.length;
    const numRows = this.paquete.listaDuasAnfora.length;
    return numSelected === numRows;
  }
  masterToggle() {
    this.isAllSelected() ?
        this.paquete.selection.clear() :
        this.paquete.listaDuasAnfora.forEach(row => this.paquete.selection.select(row));
  }

}
