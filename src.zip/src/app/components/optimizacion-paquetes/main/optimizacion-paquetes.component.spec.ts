import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OptimizacionPaquetesComponent } from './optimizacion-paquetes.component';

describe('OptimizacionPaquetesComponent', () => {
  let component: OptimizacionPaquetesComponent;
  let fixture: ComponentFixture<OptimizacionPaquetesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OptimizacionPaquetesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OptimizacionPaquetesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
