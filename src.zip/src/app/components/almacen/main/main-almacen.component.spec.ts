import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MainAlmacenComponent } from './main-almacen.component';

describe('MainAlmacenComponent', () => {
  let component: MainAlmacenComponent;
  let fixture: ComponentFixture<MainAlmacenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MainAlmacenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MainAlmacenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
