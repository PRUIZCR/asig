import { Component, OnInit, ViewChild } from '@angular/core';
import { setTheme } from 'ngx-bootstrap/utils';
import { Datacatalogo } from 'src/app/models/datacatalogo';
import { Unidaddespacho } from 'src/app/models/unidaddespacho';
import { ConstantesCadenas } from 'src/app/utils/constantescadenas';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { CatalogoService } from 'src/app/services/catalogo.service';
import { UnidaddespachoService } from 'src/app/services/unidaddespacho.service';
import { AlmacenService } from 'src/app/services/almacen.service';
import { GrupoAlmacen } from 'src/app/models/grupoalmacen';
import { ConstantesListas } from 'src/app/utils/constanteslistas';
import { ZonaService } from 'src/app/services/zona.service';
import { Zona } from 'src/app/models/zona';
import { ResponseManager } from 'src/app/models/responsemanager';
import { ResponseErrorManager } from 'src/app/models/responseerrormanager';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-main-almacen',
  templateUrl: './main-almacen.component.html',
  styleUrls: ['./main-almacen.component.css']
})
export class MainAlmacenComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  aduanas: Datacatalogo[];
  lstUnidadDespacho: Unidaddespacho[];
  unidadDespachoSeleccionado: number;
  aduanaSeleccionada: string;
  objAduanaSeleccionada: Datacatalogo;
  objUnidadDespachoSeleccionado: Unidaddespacho;
  lstGrupoAlmacenes: any;
  displayedColumns: string[];
  grupoAlmacenesDS: MatTableDataSource<any>;
  zonas: Zona[];
  gruposModificados: GrupoAlmacen[];
  esSoloConsulta: boolean;

  constructor(private catalogoService: CatalogoService,
              private almacenService: AlmacenService,
              private zonaService: ZonaService,
              private unidadDespachoService: UnidaddespachoService) {
    setTheme('bs4');
  }

  ngOnInit() {
    this.esSoloConsulta = sessionStorage.getItem('esJefeSupervisor') == '0';
    this.displayedColumns = ConstantesListas.COLUMNAS_GRID_GRUPO_ALMACENES;
    this.catalogoService.listarAduanas().subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.aduanaSeleccionada = result.aduana;
      this.aduanas = result.listaAduanas as Datacatalogo[];
      if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.aduanas)) {
        //this.aduanaSeleccionada = this.aduanas[0].cod_datacat;
        this.cargarUnidadesDespacho();
      }
    }, error => console.error(error));
    this.gruposModificados = [];
  }

  seleccionarAduana(objSeleccionado) {
    this.aduanaSeleccionada = objSeleccionado.target.value;
    if (objSeleccionado.target.value != "") {
      this.objAduanaSeleccionada = this.aduanas.find(element => element.cod_datacat == objSeleccionado.target.value);
      this.cargarUnidadesDespacho();
    }
  }

  cargarUnidadesDespacho() {
    if (this.aduanaSeleccionada != "") {
      let campos: string = "numUnidadDespacho,nombre";
      this.unidadDespachoService.listarUnidadesDespacho(this.aduanaSeleccionada,
                                                        ConstantesCadenas.ESTADO_VIGENTE,
                                                        campos).subscribe(result => {
        FuncionesGenerales.getInstance().cerrarModalCargando();
        this.lstUnidadDespacho = result as Unidaddespacho[];
        if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.lstUnidadDespacho)) {
          this.lstUnidadDespacho = this.lstUnidadDespacho.sort(FuncionesGenerales.getInstance().ordenarPor("numUnidadDespacho", false)); //cchavezt ATENCION BUGS
          this.unidadDespachoSeleccionado = this.lstUnidadDespacho[0].numUnidadDespacho;
          this.cargarZonas();
          this.cargarGruposAlmacenesAduaneros();
        } else {
          this.unidadDespachoSeleccionado = -1;
          this.lstGrupoAlmacenes = [];
          let tituloErrores: string = "Mensaje de Error: ";
          let errorMensaje: string = "No existen unidades de despacho asignadas a la Aduana " + this.objAduanaSeleccionada.des_corta;
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                        tituloErrores, errorMensaje, "");
        }
      }, error => console.error(error));
    } else {
      this.unidadDespachoSeleccionado = -1;
      this.lstGrupoAlmacenes = [];
    }
  }

  seleccionarUnidadDespacho(objSeleccionado) {
    this.unidadDespachoSeleccionado = objSeleccionado.target.value;
    this.lstGrupoAlmacenes = [];
    if (objSeleccionado.target.value != "") {
      this.objUnidadDespachoSeleccionado = this.lstUnidadDespacho.find(element => element.numUnidadDespacho == objSeleccionado.target.value);
      this.cargarZonas();
    }
  }

  cargarZonas(){
    this.zonaService.listarZonas(this.unidadDespachoSeleccionado + '', ConstantesCadenas.ESTADO_ACTIVO, "numZona,nombre").subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.zonas = result as Zona[];
      if (!FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.zonas)) {
        this.zonas = [];
      }
      this.cargarGruposAlmacenesAduaneros();
    }, error => console.error(error));
  }

  cargarGruposAlmacenesAduaneros() {
    this.almacenService.listarAlmacenes(this.unidadDespachoSeleccionado).subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.lstGrupoAlmacenes = result as GrupoAlmacen[];
      this.grupoAlmacenesDS = new MatTableDataSource<any>(this.lstGrupoAlmacenes);
      this.grupoAlmacenesDS.sort = this.sort;
      this.grupoAlmacenesDS.paginator = this.paginator;
    }, error => console.error(error));
  }

  seleccionarZona(grupoSeleccionado: GrupoAlmacen, objSeleccionado: any){
    let indice = this.gruposModificados.indexOf(grupoSeleccionado);
    grupoSeleccionado.zona = new Zona();
    grupoSeleccionado.zona.numZona = objSeleccionado.target.value;
    if (indice > -1)
      this.gruposModificados[indice] = grupoSeleccionado;
    else
      this.gruposModificados.push(grupoSeleccionado);
  }

  //cchavezt ATENCION BUGS 
  limpiar() {


        Swal.fire({
        title: "Mensaje de Confirmación: ",
        text: "¿Está seguro que desea deshacer los cambios?",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        confirmButtonText: "SI",
        cancelButtonColor: '#d33',
        cancelButtonText: "NO"
      }).then((result) => {
        if (result.value) {
          this.ngOnInit();
        }
      });
    }//cchavezt ATENCION BUGS 



  callback = () : void => {
    this.ngOnInit();
  };

  registrar() {


    Swal.fire({
    title: "Mensaje de Confirmación: ",
    text: "¿Desea grabar los datos ingresados?",
    type: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    confirmButtonText: "SI",
    cancelButtonColor: '#d33',
    cancelButtonText: "NO"
  }).then((result) => {
    if (result.value) {
      this.registrarConfirmado();
    }
  });
}

  registrarConfirmado() {
    this.almacenService.registrarAlmacenes(this.gruposModificados, this.unidadDespachoSeleccionado).subscribe(
      response => {
        console.log(response);
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(
          ConstantesCadenas.MENSAJE_EXITOSO,
          "Los almacenes se grabaron correctamente.", "", "", this.callback);

      },
      errorResult => {
        let responseErrorManager;
        let responseManager;
        if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
          let responseManager: ResponseManager = new ResponseManager();
          responseErrorManager = errorResult as ResponseErrorManager;
          responseManager.cod = errorResult.cod;
          responseManager.errors = [responseErrorManager];
          responseManager = responseManager;
        } else {
          responseManager = errorResult as ResponseManager;
        }
        if (responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO ||
            responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                       "Mensajes de Error: ",
                                                                        "",
                                                                        FuncionesGenerales.getInstance().mostrarTablaDeErrores(responseManager.errors));
        }
      }
    );
  }

  filtrar(filterValue: string) {
    this.grupoAlmacenesDS.filter = filterValue.trim().toLowerCase();
  }
}
