import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReasignacionBloqueComponent } from './reasignacion-bloque.component';

describe('ReasignacionBloqueComponent', () => {
  let component: ReasignacionBloqueComponent;
  let fixture: ComponentFixture<ReasignacionBloqueComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReasignacionBloqueComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReasignacionBloqueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
