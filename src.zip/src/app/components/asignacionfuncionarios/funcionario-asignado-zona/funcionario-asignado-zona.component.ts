import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FuncionariosZonaDetalle } from 'src/app/models/funcionarioszonadetalle';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { ConstantesCadenas } from 'src/app/utils/constantescadenas';
import { ConstantesListas } from 'src/app/utils/constanteslistas';
import { ResponseManager } from 'src/app/models/responsemanager';
import { ResponseErrorManager } from 'src/app/models/responseerrormanager';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { AsignaFuncionarioZona } from 'src/app/models/asignafuncionariozona';
import { DetalleAsignafuncionarioZona } from 'src/app/models/detalleasignafuncionariozona';
import { MatTableDataSource } from '@angular/material';
import { MatSort  } from '@angular/material/sort';
import { MatPaginator  } from '@angular/material/paginator';
import { AsignaFuncionarioZonaService } from 'src/app/services/asignafuncionariozona.service';
import { FuncionariosAsignados } from 'src/app/models/funcionariosasignados';
import { FuncionarioDisponible } from 'src/app/models/funcionariodisponible';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-funcionario-asignado-zona',
  templateUrl: './funcionario-asignado-zona.component.html',
  styleUrls: ['./funcionario-asignado-zona.component.css']
})
export class FuncionarioAsignadoZonaComponent implements OnInit {
  @ViewChild('childModal') childModal: ModalDirective;
  @ViewChild(MatPaginator) paginatorZA: MatPaginator;
  @ViewChild(MatSort) sortZA: MatSort;
  funcionarioZonaDetalle: FuncionariosZonaDetalle;
  aduanaSeleccionada: string;
  unidadDespachoSeleccionado: string;
  nombreTurno: string;
  anfora: string;
  fecha: string;
  tituloFuncionariosAsignadosAZona: string;
  tipoAsignacion: string;
  displayedColumns: string[];
  asignaFuncionarioZona: AsignaFuncionarioZona;
  funcionarioAsignadosDS: MatTableDataSource<FuncionariosAsignados>;
  listDetallesAsignacion: DetalleAsignafuncionarioZona[];
  spans = [];
  DATA: FuncionariosAsignados[];
  funcionariosAsignados: FuncionariosAsignados[];
  responseManager: ResponseManager;
  responseErrorManager: ResponseErrorManager;
  mostrarBtnRevertirCerrar: boolean = false;
  mostrarBtnGrabarCerrar: boolean = true;
  motivo: string;
  desabilitarBotonGrabar: boolean;
  desabilitarBotonRevertir: boolean = true;
  private estadoOperacion$ = new Subject<String>();

  constructor(private asignaFuncionarioZonaService: AsignaFuncionarioZonaService) { }

  ngOnInit() { }

  /**
   * Evaluated and store an evaluation of the rowspan for each row.
   * The key determines the column it affects, and the accessor determines the
   * value that should be checked for spanning.
  */
  cacheSpan(key, accessor) {
    for (let i = 0; i < this.DATA.length;) {
      let currentValue = accessor(this.DATA[i]);
      let count = 1;

      // Iterate through the remaining rows to see how many match
      // the current value as retrieved through the accessor.
      for (let j = i + 1; j < this.DATA.length; j++) {
        if (currentValue != accessor(this.DATA[j])) {
          break;
        }

        count++;
      }

      if (!this.spans[i]) {
        this.spans[i] = {};
      }

      // Store the number of similar values that were found (the span)
      // and skip i to the next unique row.
      this.spans[i][key] = count;
      i += count;
    }
  }


  getRowSpan(col, index) {
    return this.spans[index] && this.spans[index][col];
  }

  cargarAsignacionDeFuncionarioAZona(aduanaSeleccionada: string,
                                     unidadDespachoSeleccionado: string,
                                     funcionarioZonaDetalle: FuncionariosZonaDetalle,
                                     fechaEvento: Date) {
   let fechaActual: Date = new Date();
   this.funcionarioZonaDetalle = FuncionesGenerales.getInstance().clonarObjeto(funcionarioZonaDetalle);
   this.aduanaSeleccionada = aduanaSeleccionada;
   this.unidadDespachoSeleccionado = unidadDespachoSeleccionado;
   this.nombreTurno = this.funcionarioZonaDetalle.nombreTurno;
   this.anfora = this.funcionarioZonaDetalle.anfora;
   this.fecha = FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(fechaEvento);
   this.tituloFuncionariosAsignadosAZona = ConstantesCadenas.TITULO_FUNCIONARIO_ASIGNADO_A_ZONA;
   this.obtenerAsignacionFuncionariosAZonas(this.funcionarioZonaDetalle.numAsigFuncZona);
   this.mostrarBtnGrabarCerrar = true;
   this.mostrarBtnRevertirCerrar = false;
   this.motivo = "";
   this.desabilitarBotonGrabar = true;
   this.desabilitarBotonRevertir = true;
   if (fechaEvento.setHours(0,0,0,0) < fechaActual.setHours(0,0,0,0)) {
     this.desabilitarBotonRevertir = false;
   }

   this.childModal.show();
  }

  cargarFuncionariosDisponiblesListaAgrupada(detallesAsignacion: DetalleAsignafuncionarioZona[]) {
    this.funcionariosAsignados = [];

    for (let i = 0; i < detallesAsignacion.length; i++) {
      let funcionarioAsignado: FuncionariosAsignados = new FuncionariosAsignados();
      funcionarioAsignado.cantidad = detallesAsignacion[i].cantidadFuncionarios;
      funcionarioAsignado.zona = detallesAsignacion[i].zona.nombre;
      funcionarioAsignado.funcionarios = this.obtenerFuncionarios(detallesAsignacion[i].funcionarios);
      this.funcionariosAsignados.push(funcionarioAsignado);
    }
    this.DATA = [];
    this.spans = [];
    this.DATA = this.funcionariosAsignados.reduce((current, next) => {
        next.funcionarios.forEach(x => {
          current.push({ zona: next.zona,
                         cantidad: next.cantidad,
                         funcionarios: x })
        });
        return current;
    }, []);

    this.displayedColumns = ConstantesListas.COLUMNAS_GRID_ZONA_ASIGNADA;
    this.funcionarioAsignadosDS = new MatTableDataSource<FuncionariosAsignados>(this.DATA);
    this.cacheSpan('zona', x => x.zona);
    this.cacheSpan('cantidad', x => x.zona + x.cantidad);
    this.cacheSpan('funcionario', x => x.zona + x.cantidad + x.funcionarios);
  }

  obtenerFuncionarios(funcionarios: FuncionarioDisponible[]) {
    let resultData: string[] = [];
    for (let i = 0; i < funcionarios.length; i++) {
      resultData.push(funcionarios[i].catEmpleado.apPate.trim() + " " +
                      funcionarios[i].catEmpleado.apMate.trim() + " " +
                      funcionarios[i].catEmpleado.nombres.trim());
    }
    return resultData;
  }

  cerrarAsignacionDeFuncionarioAZona() {
    this.funcionarioAsignadosDS = new MatTableDataSource<FuncionariosAsignados>([]);
    this.childModal.hide();
  }

  cancelarAsignacionDeFuncionarioAZona() {
    this.mostrarBtnGrabarCerrar = true;
    this.mostrarBtnRevertirCerrar = false;
    this.motivo = "";
  }

  revertirFuncionariosAsignadosAZona() {
    this.mostrarBtnRevertirCerrar = true;
    this.mostrarBtnGrabarCerrar = false;
  }

  callback = () : void => {
    this.funcionarioAsignadosDS = new MatTableDataSource<FuncionariosAsignados>([]);
    this.cerrarAsignacionDeFuncionarioAZona();
    this.estadoOperacion$.next("X");
  };

  grabarAsignacionDeFuncionarioAZona() {
    let errorMensaje: string = "Ingrese motivo de reversión. Debe contener al menos 20 caracteres.";
    let tituloErrores: string = "Mensajes de Error: ";
    let regExpMotivo = "^[áéíóúÁÉÍÓÚñÑa-zA-Z0-9".concat("\\").concat("s,()-._").concat("\\/").concat("]{20,200}$");

    if (!FuncionesGenerales.getInstance().validarExpresionesRegulares(this.motivo, regExpMotivo)) {
      errorMensaje = "Ingrese al menos 20 caracteres del motivo.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (this.motivo.length > 200) {
      errorMensaje = "No debe contener mas de 200 caracteres.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    this.ConfirmarGrabarAsignacionDeFuncionarioAZona();
  }

  ConfirmarGrabarAsignacionDeFuncionarioAZona() { //cchavezt atencion de bugs
    Swal.fire({
      title: "Mensaje de Confirmación: ",
      text: "¿Está seguro de continuar con la reversión?",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      confirmButtonText: "SI",
      cancelButtonColor: '#d33',
      cancelButtonText: "NO"
    }).then((result) => {
      if (result.value) {
        this.RealizarGrabarAsignacionDeFuncionarioAZona();
      }
    });
  }

  RealizarGrabarAsignacionDeFuncionarioAZona(){
    this.desabilitarBotonGrabar = false;

    this.asignaFuncionarioZona.motivo = this.motivo;
    this.asignaFuncionarioZonaService.revertirAsignacionFuncionariosAZonas(this.asignaFuncionarioZona).subscribe(
      response => {
        console.log(response);
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(
          ConstantesCadenas.MENSAJE_EXITOSO,
          "Se realizo la reversión correctamente.",
          "", "", this.callback);
      },
      errorResult => {
        if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
          let responseManager: ResponseManager = new ResponseManager();
          this.responseErrorManager = errorResult as ResponseErrorManager;
          responseManager.cod = errorResult.cod;
          responseManager.errors = [this.responseErrorManager];
          this.responseManager = responseManager;
          this.cargarMensajesAsignacionFuncionariosZona(this.responseManager);
        } else {
          this.responseManager = errorResult as ResponseManager;
          this.cargarMensajesAsignacionFuncionariosZona(this.responseManager);
        }
      }
    );

  }



  obtenerTipoDeAsignacion(tipoAsignacion: string) {
    let tipoAsigna: string = "";
    if (tipoAsignacion == ConstantesCadenas.TIPO_ASIGNACION_ALEATORIA_SIN_REPETICION) {
      tipoAsigna = ConstantesCadenas.TITULO_ASIGNACION_ALEATORIA_SIN_REPETICION;
    } else if (tipoAsignacion == ConstantesCadenas.TIPO_ASIGNACION_ALEATORIA_CON_REPETICION) {
      tipoAsigna = ConstantesCadenas.TITULO_ASIGNACION_ALEATORIA_CON_REPETICION;
    } else {
      tipoAsigna = ConstantesCadenas.TITULO_ASIGNACION_MANUAL;
    }
    return tipoAsigna;
  }

  obtenerAsignacionFuncionariosAZonas(numAsigFuncZona: number) {
    this.asignaFuncionarioZonaService.obtenerAsignacionFuncionariosAZonas(numAsigFuncZona).subscribe(
      response => {
        FuncionesGenerales.getInstance().cerrarModalCargando();
        this.asignaFuncionarioZona = response as AsignaFuncionarioZona;
        this.tipoAsignacion = this.obtenerTipoDeAsignacion(this.asignaFuncionarioZona.tipoAsignacion);
        this.cargarFuncionariosDisponiblesListaAgrupada(this.asignaFuncionarioZona.detallesAsignacion);
      },
      errorResult => {
        if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
          let responseManager: ResponseManager = new ResponseManager();
          this.responseErrorManager = errorResult as ResponseErrorManager;
          responseManager.cod = errorResult.cod;
          responseManager.errors = [this.responseErrorManager];
          this.responseManager = responseManager;
          this.cargarMensajesAsignacionFuncionariosZona(this.responseManager);
        } else {
          this.responseManager = errorResult as ResponseManager;
          this.cargarMensajesAsignacionFuncionariosZona(this.responseManager);
        }
      }
    );
  }

  cargarMensajesAsignacionFuncionariosZona(responseManager: ResponseManager) {
    if (responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO ||
        responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR ||
        responseManager.cod == "999") {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                   "Mensajes de Error: ",
                                                                    "",
                                                                    FuncionesGenerales.getInstance().mostrarTablaDeErrores(this.responseManager.errors));
    }
  }

  getEstadoOperacion$(): Observable<String> {
    return this.estadoOperacion$.asObservable();
  }
}
