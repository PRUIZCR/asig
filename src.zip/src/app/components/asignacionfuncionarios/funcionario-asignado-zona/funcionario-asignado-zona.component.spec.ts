import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FuncionarioAsignadoZonaComponent } from './funcionario-asignado-zona.component';

describe('FuncionarioAsignadoZonaComponent', () => {
  let component: FuncionarioAsignadoZonaComponent;
  let fixture: ComponentFixture<FuncionarioAsignadoZonaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FuncionarioAsignadoZonaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FuncionarioAsignadoZonaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
