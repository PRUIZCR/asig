import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AsignacionFuncionarioZonaComponent } from './asignacion-funcionario-zona.component';

describe('AsignacionFuncionarioZonaComponent', () => {
  let component: AsignacionFuncionarioZonaComponent;
  let fixture: ComponentFixture<AsignacionFuncionarioZonaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AsignacionFuncionarioZonaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AsignacionFuncionarioZonaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
