import { Observable } from 'rxjs/Observable';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Datacatalogo } from 'src/app/models/datacatalogo';
import { Unidaddespacho } from 'src/app/models/unidaddespacho';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { FuncionariosZonaDetalle } from 'src/app/models/funcionarioszonadetalle';
import { setTheme } from 'ngx-bootstrap/utils';
import { ConstantesCadenas } from 'src/app/utils/constantescadenas';
import { ConstantesListas } from 'src/app/utils/constanteslistas';
import { FuncionariosZonaDetalleService } from 'src/app/services/funcionarioszonadetalle.service';
import { ResponseManager } from 'src/app/models/responsemanager';
import { ResponseErrorManager } from 'src/app/models/responseerrormanager';
import { AsignacionFuncionarioZonaComponent } from 'src/app/components/asignacionfuncionarios/asignacion-funcionario-zona/asignacion-funcionario-zona.component';
import { FuncionarioAsignadoZonaComponent } from 'src/app/components/asignacionfuncionarios/funcionario-asignado-zona/funcionario-asignado-zona.component';
import { CatalogoService } from 'src/app/services/catalogo.service';
import { UnidaddespachoService } from 'src/app/services/unidaddespacho.service';

import esLocale from '@fullcalendar/core/locales/es';
import { CalendarComponent } from 'ng-fullcalendar';
import interactionPlugin from '@fullcalendar/interaction';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import { OptionsInput } from '@fullcalendar/core';

@Component({
  selector: 'app-consulta-funcionario-zona',
  templateUrl: './consulta-funcionario-zona.component.html',
  styleUrls: ['./consulta-funcionario-zona.component.css']
})
export class ConsultaFuncionarioZonaComponent implements OnInit {
  @ViewChild(CalendarComponent) ufullcalendar: CalendarComponent;
  @ViewChild(AsignacionFuncionarioZonaComponent) childAsigFuncZona: AsignacionFuncionarioZonaComponent;
  @ViewChild(FuncionarioAsignadoZonaComponent) childFuncAsigZona: FuncionarioAsignadoZonaComponent;
  aduanaSeleccionada: string;
  aduanas: Datacatalogo[];
  objAduanaSeleccionada: Datacatalogo;
  lstUnidadDespacho: Unidaddespacho[];
  estados: Datacatalogo[];
  unidadDespachoSeleccionado: string;
  estadoSeleccionado: string;
  objUnidadDespachoSeleccionado: Unidaddespacho;
  options: OptionsInput;
  listFuncionariosZonaDetalle: FuncionariosZonaDetalle[];
  responseManager: ResponseManager;
  responseErrorManager: ResponseErrorManager;
  tituloCalendario: string;
  funcionarioZonaDetalle: FuncionariosZonaDetalle;
  estadoOperacion$: Observable<String>;
  estadoOperacionAsignacion$: Observable<String>;

  constructor(private catalogoService: CatalogoService,
              private funcionariosZonaDetalleService: FuncionariosZonaDetalleService,
              private unidadDespachoService: UnidaddespachoService) {
    setTheme('bs4');
  }

  ngOnInit() {

    this.catalogoService.listarAduanas().subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.aduanaSeleccionada = result.aduana;
      this.aduanas = result.listaAduanas as Datacatalogo[];
      if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.aduanas)) {
        this.cargarControles();
      }
    }, error => console.error(error));

    this.listFuncionariosZonaDetalle = [];
    this.options = {
       editable: false,
       events:  this.listFuncionariosZonaDetalle,
       height: 700,
       contentHeight: 650,
       aspectRatio: 1.75,
       timeZone: 'UTC',
       defaultView: 'dayGridMonth',
       locale: esLocale,
       eventTextColor: '#FFF',
       header: {
         left: '',//'prev,next today',
         center: 'title',
         right: ''
       },
       plugins: [ interactionPlugin, dayGridPlugin, timeGridPlugin ]
     };
     this.estadoOperacion$ = this.childFuncAsigZona.getEstadoOperacion$();
     this.estadoOperacion$.subscribe(estado => estado == "X" ? this.obtenerAsignacionFuncionariosXZonas(this.ufullcalendar.calendar.getDate().getMonth() + 1,
                                              this.ufullcalendar.calendar.getDate().getFullYear()) : "");
     this.estadoOperacionAsignacion$ = this.childAsigFuncZona.getEstadoOperacionAsignacion$();
     this.estadoOperacionAsignacion$.subscribe(estado => estado == "Y" ? this.obtenerAsignacionFuncionariosXZonas(this.ufullcalendar.calendar.getDate().getMonth() + 1,
                                              this.ufullcalendar.calendar.getDate().getFullYear()) : "");
  }

  cargarControles() {
    this.estados = ConstantesListas.LISTA_ESTADOS;
    this.lstUnidadDespacho = [];
    this.unidadDespachoSeleccionado = "";
    this.estadoSeleccionado = ConstantesCadenas.ESTADO_TODOS;
    //this.aduanaSeleccionada = this.aduanas[0].cod_datacat;
    this.objAduanaSeleccionada = this.aduanas.find(element => element.cod_datacat == this.aduanaSeleccionada);
    this.cargarUnidadesDespacho();
  }

  seleccionarAduana(objSeleccionado) {
    this.aduanaSeleccionada = objSeleccionado.target.value;
    if (objSeleccionado.target.value != "") {
      this.objAduanaSeleccionada = this.aduanas.find(element => element.cod_datacat == objSeleccionado.target.value);
      this.cargarUnidadesDespacho();
    }
  }

  seleccionarUnidadDespacho(objSeleccionado) {
    this.unidadDespachoSeleccionado = objSeleccionado.target.value;
    if (objSeleccionado.target.value != "") {
      this.objUnidadDespachoSeleccionado = this.lstUnidadDespacho.find(element => element.numUnidadDespacho == objSeleccionado.target.value);
      this.obtenerAsignacionFuncionariosXZonas(new Date().getMonth() + 1, new Date().getFullYear());
    } else {
      this.cargarCalendario([]);
    }
  }

  cargarCalendario(funcionariosDetalle: FuncionariosZonaDetalle[]) {
    this.listFuncionariosZonaDetalle = funcionariosDetalle;
    console.log(this.listFuncionariosZonaDetalle);
    this.ufullcalendar.calendar.removeAllEvents();
    this.ufullcalendar.calendar.addEventSource(this.listFuncionariosZonaDetalle);
    this.ufullcalendar.calendar.refetchEvents();
  }

  cargarUnidadesDespacho() {
    let campos: string = "numUnidadDespacho,nombre";
    this.unidadDespachoService.listarUnidadesDespacho(this.aduanaSeleccionada,
                                                      ConstantesCadenas.ESTADO_VIGENTE,
                                                      campos).subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.lstUnidadDespacho = result as Unidaddespacho[];
      if (this.aduanaSeleccionada != "" && FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.lstUnidadDespacho)) {
      //this.lstUnidadDespacho != null && this.lstUnidadDespacho != undefined && this.lstUnidadDespacho.length > 0) {
        this.lstUnidadDespacho = this.lstUnidadDespacho.sort(FuncionesGenerales.getInstance().ordenarPor("numUnidadDespacho", false));
        this.unidadDespachoSeleccionado = this.lstUnidadDespacho[0].numUnidadDespacho.toString();
        this.objUnidadDespachoSeleccionado = this.lstUnidadDespacho.find(element => element.numUnidadDespacho == parseInt(this.unidadDespachoSeleccionado));
        this.obtenerAsignacionFuncionariosXZonas(new Date().getMonth() + 1, new Date().getFullYear());
      } else {
        this.lstUnidadDespacho = [];
        this.unidadDespachoSeleccionado = "";
        let tituloErrores: string = "Mensaje de Error: ";
        let errorMensaje: string = "No existen unidades de despacho asignadas a la Aduana " + this.objAduanaSeleccionada.des_corta;
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                        tituloErrores, errorMensaje, "");
      }
    }, error => console.error(error));
  }

  eventClick(model) {
    let objFechaActual: Date = model.event.start;
    objFechaActual.setDate(objFechaActual.getDate() + 1);
    //console.log(model);
    //console.log(model.el.ownerDocument.lastModified as string);
    let funcionariosDetalle: FuncionariosZonaDetalle = new FuncionariosZonaDetalle();
    this.funcionarioZonaDetalle = model.event._def.extendedProps as FuncionariosZonaDetalle;
    funcionariosDetalle = FuncionesGenerales.getInstance().clonarObjeto(this.funcionarioZonaDetalle);
    let nombreTurno: string = this.funcionarioZonaDetalle.nombreTurno;
    let nombreCompletoTurno: string = "";
    let horarioInicio: string;
    let horarioFin: string;
    let horario: string;
    nombreTurno = nombreTurno.replace(/ /g, "");
    horario = nombreTurno;
    nombreTurno = nombreTurno.substring(0, nombreTurno.indexOf(":"));
    horario = horario.substring(horario.indexOf(":") + 1, horario.length);
    horarioInicio = horario.split('-')[0];
    horarioFin = horario.split('-')[1];
    nombreCompletoTurno = nombreTurno + ": " + FuncionesGenerales.getInstance().darFormatoAMPM(horarioInicio) + " - " + FuncionesGenerales.getInstance().darFormatoAMPM(horarioFin);
    funcionariosDetalle.nombreTurno = nombreCompletoTurno;
    if (this.funcionarioZonaDetalle.indEstado == ConstantesCadenas.ESTADO_NO_VIGENTE_ASIGNACION_FUNCIONARIOS_A_ZONA) {
      this.childAsigFuncZona.cargarAsignacionDeFuncionarioAZona(this.objAduanaSeleccionada.cod_datacat + " - " + this.objAduanaSeleccionada.des_corta,
                                                                this.objUnidadDespachoSeleccionado.numUnidadDespacho.toString() + " - " + this.objUnidadDespachoSeleccionado.descripcion,
                                                                funcionariosDetalle,
                                                                objFechaActual);
    } else {
      this.childFuncAsigZona.cargarAsignacionDeFuncionarioAZona(this.objAduanaSeleccionada.cod_datacat + " - " + this.objAduanaSeleccionada.des_corta,
                                                                this.objUnidadDespachoSeleccionado.numUnidadDespacho.toString() + " - " + this.objUnidadDespachoSeleccionado.descripcion,
                                                                funcionariosDetalle,
                                                                objFechaActual);
    }
  }

  cargarMensajesCatalogoFuncionarios(responseManager: ResponseManager) {
    if (responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO ||
        responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                   "Mensajes de Error: ",
                                                                    "",
                                                                    FuncionesGenerales.getInstance().mostrarTablaDeErrores(this.responseManager.errors));
    }
  }

  eventoSiguienteAtrasCalendario(esAtras: boolean) {
    this.ufullcalendar.calendar.incrementDate({ months: (esAtras ? -1 : 1) });
    this.obtenerAsignacionFuncionariosXZonas(this.ufullcalendar.calendar.getDate().getMonth() + 1,
                                             this.ufullcalendar.calendar.getDate().getFullYear());
  }

  obtenerAsignacionFuncionariosXZonas(month: number, year: number) {
    this.funcionariosZonaDetalleService.obtenerAsignacionFuncionariosAZonas(
      this.unidadDespachoSeleccionado,
      (month).toString(),
      (year).toString()).subscribe(
        response => {
          FuncionesGenerales.getInstance().cerrarModalCargando();
          this.cargarCalendario(response as FuncionariosZonaDetalle[]);
      },
      errorResult => {
          if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
            let responseManager: ResponseManager = new ResponseManager();
            this.responseErrorManager = errorResult as ResponseErrorManager;
            responseManager.cod = errorResult.cod;
            responseManager.errors = [this.responseErrorManager];
            this.responseManager = responseManager;
            this.cargarMensajesCatalogoFuncionarios(this.responseManager);
          } else {
            this.responseManager = errorResult as ResponseManager;
            this.cargarMensajesCatalogoFuncionarios(this.responseManager);
          }
    });
  }

}
