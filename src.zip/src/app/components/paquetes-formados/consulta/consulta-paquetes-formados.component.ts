import { Component, OnInit, ViewChild } from '@angular/core';
import { ConstantesCadenas } from 'src/app/utils/constantescadenas';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { setTheme } from 'ngx-bootstrap/utils';
import { Datacatalogo } from 'src/app/models/datacatalogo';
import { UnidaddespachoService } from 'src/app/services/unidaddespacho.service';
import { Unidaddespacho } from 'src/app/models/unidaddespacho';
import { TurnoService } from 'src/app/services/turno.service';
import { Turno } from 'src/app/models/turno';
import { CatalogoService } from 'src/app/services/catalogo.service';
import { TmpPaqueteService } from 'src/app/services/tmpPaquete.service';
import { PaquetesFormados } from 'src/app/models/paquetesformados';

import esLocale from '@fullcalendar/core/locales/es';
import { CalendarComponent } from 'ng-fullcalendar';
import interactionPlugin from '@fullcalendar/interaction';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import { OptionsInput } from '@fullcalendar/core';
import { Router } from '@angular/router';
import { MatDatepickerInputEvent } from '@angular/material';
import { ConstantesExcepciones } from 'src/app/utils/constantesExcepciones';

@Component({
  selector: 'app-consulta-paquetes-formados',
  templateUrl: './consulta-paquetes-formados.component.html',
  styleUrls: ['./consulta-paquetes-formados.component.css']
})
export class ConsultaPaquetesFormadosComponent implements OnInit {
  @ViewChild(CalendarComponent) ufullcalendar: CalendarComponent;
  txtFecha: string;
  txtHora: string;
  fechaActual: Date;
  fechaDesde: Date;
  fechaHasta: Date;
  aduanaSeleccionada: string;
  aduanas: Datacatalogo[];
  objAduanaSeleccionada: Datacatalogo;
  lstUnidadDespacho: Unidaddespacho[];
  unidadDespachoSeleccionado: string;
  objUnidadDespachoSeleccionado: Unidaddespacho;
  turnos: Turno[];
  turnoSeleccionado: string;
  anforaSeleccionada: string;
  anforas: Datacatalogo[];
  objAnforaSeleccionada: Datacatalogo;
  objTurnoSeleccionado: Turno;
  unidadDespacho: Unidaddespacho;
  listPaquetesFormados: PaquetesFormados[];
  options: OptionsInput;
  paqueteFormado: PaquetesFormados;
  funcionesGenerales: FuncionesGenerales;

  constructor(private unidadDespachoService: UnidaddespachoService,
              private turnoService: TurnoService,
              private catalogoService: CatalogoService,
              private tmpPaqueteService: TmpPaqueteService,
              private router: Router) {
    setTheme('bs4');
  }

  ngOnInit() {
    this.fechaActual = new Date();
    this.fechaDesde = new Date();
    this.fechaHasta = new Date();
    this.txtFecha = ('00' + this.fechaActual.getDate()).slice(-2) + '/' +
                    ('00' + (this.fechaActual.getMonth() + 1)).slice(-2) + '/' +
                    this.fechaActual.getFullYear();
    this.txtHora = FuncionesGenerales.getInstance().darFormatoAMPM(('00' + this.fechaActual.getHours()).slice(-2) + ':' +
                   ('00' + this.fechaActual.getMinutes()).slice(-2) + ':' +
                   ('00' + this.fechaActual.getSeconds()).slice(-2));
     this.catalogoService.listarAduanas().subscribe(result => {
       FuncionesGenerales.getInstance().cerrarModalCargando();
       this.aduanaSeleccionada = result.aduana;
       this.aduanas = result.listaAduanas as Datacatalogo[];
       if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.aduanas)) {
         this.cargarControles();
       }
     }, error => console.error(error));
     this.listPaquetesFormados = [];
     this.options = {
        editable: false,
        events:  this.listPaquetesFormados,
        height: 700,
        contentHeight: 650,
        aspectRatio: 1.75,
        timeZone: 'UTC',
        defaultView: 'dayGridMonth',
        locale: esLocale,
        eventTextColor: '#FFF',
        header: {
          left: '',//'prev,next today',
          center: 'title',
          right: ''
        },
        plugins: [ interactionPlugin, dayGridPlugin, timeGridPlugin ]
      };
      this.funcionesGenerales = FuncionesGenerales.getInstance();
  }

  cargarControles() {
    this.unidadDespacho = new Unidaddespacho();
    this.unidadDespacho.numUnidadDespacho = -1;
    //this.aduanaSeleccionada = this.aduanas[0].cod_datacat;
    this.objAduanaSeleccionada = this.aduanas.find(element => element.cod_datacat == this.aduanaSeleccionada);
    this.unidadDespacho.aduana = this.objAduanaSeleccionada;
    this.cargarUnidadesDespacho();
  }

  seleccionarAduana(objSeleccionado) {
    this.aduanaSeleccionada = objSeleccionado.target.value;
    if (objSeleccionado.target.value != "") {
      this.objAduanaSeleccionada = this.aduanas.find(element => element.cod_datacat == objSeleccionado.target.value);
      this.cargarUnidadesDespacho();
    }
  }

  cargarUnidadesDespacho() {
    let campos: string = "numUnidadDespacho,nombre";
    this.unidadDespachoService.listarUnidadesDespacho(this.aduanaSeleccionada,
                                                      ConstantesCadenas.ESTADO_VIGENTE,
                                                      campos).subscribe(result => {
     FuncionesGenerales.getInstance().cerrarModalCargando();
     this.lstUnidadDespacho = result as Unidaddespacho[];
     if (this.aduanaSeleccionada != "" && FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.lstUnidadDespacho)) {
       this.lstUnidadDespacho = this.lstUnidadDespacho.sort(FuncionesGenerales.getInstance().ordenarPor("numUnidadDespacho", false));
       this.unidadDespachoSeleccionado = this.lstUnidadDespacho[0].numUnidadDespacho.toString();
       this.objUnidadDespachoSeleccionado = this.lstUnidadDespacho.find(element => element.numUnidadDespacho == parseInt(this.unidadDespachoSeleccionado));
       this.objUnidadDespachoSeleccionado.aduana = this.objAduanaSeleccionada;
       this.cargarTurnos();
       this.cargarAnforas();
     } else {
       this.lstUnidadDespacho = [];
       this.turnos = [];
       this.anforas = [];
       let tituloErrores: string = "Mensaje de Error: ";
       let errorMensaje: string = "No existen unidades de despacho asignadas a la Aduana " + this.objAduanaSeleccionada.des_corta;
       FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                     tituloErrores, errorMensaje, "");
     }
    }, error => console.error(error));
  }

  changeVigenteDesde(obj: MatDatepickerInputEvent<Date>){
    if (this.fechaHasta != undefined && this.fechaHasta != null) {
      if (FuncionesGenerales.getInstance().compararFechas(
        FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(obj.value),
        ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
        FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaHasta),
        ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 1) {
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ADVERTENCIA,
          ConstantesExcepciones.DEFAULT_TITTLE_EXCEPTION, ConstantesExcepciones.EXCEPCION_DOS, "");
        return false;
      }  else {
        this.cargarTurnos();
      }
    } else {
      this.cargarTurnos();
    }
  }

  changeVigenteHasta(obj: MatDatepickerInputEvent<Date>){
    if (this.fechaDesde != undefined && this.fechaDesde != null) {
      if (FuncionesGenerales.getInstance().compararFechas(
        FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaDesde),
        ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
        FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(obj.value),
        ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 1) {
         FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ADVERTENCIA,
          ConstantesExcepciones.DEFAULT_TITTLE_EXCEPTION, ConstantesExcepciones.EXCEPCION_DOS, "");
        return false;
      } else {
        this.cargarTurnos();
      }
    } else {
      this.cargarTurnos();
    }
  }

  cargarTurnos() {
    if (this.objUnidadDespachoSeleccionado.numUnidadDespacho == -1) {
      this.turnos = [];
      this.turnoSeleccionado = "";
    } else {
      let campos: string = "numTurno,nombre,hraInicio,hraFin";
      this.turnoService.listarTurnos(this.objUnidadDespachoSeleccionado.numUnidadDespacho.toString(),
                                     ConstantesCadenas.ESTADO_ACTIVO,
                                     FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaDesde),
                                     FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaHasta),
                                     campos,
                                     "X").subscribe(result => {
       FuncionesGenerales.getInstance().cerrarModalCargando();
       this.turnos = result as Turno[];
       //if (this.turnos != null && this.turnos != undefined && this.turnos.length > 0) {
       if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.turnos)) {
         this.turnos = this.turnos.sort(FuncionesGenerales.getInstance().ordenarPor("hraInicio", false));
         this.turnoSeleccionado = this.turnos[0].numTurno.toString();
         this.objTurnoSeleccionado = this.turnos.find(element => element.numTurno == parseInt(this.turnoSeleccionado));
       } else {
         this.turnos = [];
         this.turnoSeleccionado = "";
         let tituloErrores: string = "Mensaje de Error: ";
         let errorMensaje = "La unidad de despacho seleccionada no tiene turnos asociados.";
         FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                       tituloErrores, errorMensaje, "");
       }
      }, error => console.error(error));
    }
  }

  cargarAnforas() {
    if (this.objUnidadDespachoSeleccionado.numUnidadDespacho == -1) {
      this.anforas = [];
      this.anforaSeleccionada = "";
    } else {
      this.catalogoService.listarAnforas(this.objUnidadDespachoSeleccionado.numUnidadDespacho).subscribe(result => {
        FuncionesGenerales.getInstance().cerrarModalCargando();
        this.anforas = result as Datacatalogo[];
        //if (this.anforas != null && this.anforas != undefined && this.anforas.length > 0) {
        if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.anforas)) {
          this.anforas = this.anforas.sort(FuncionesGenerales.getInstance().ordenarPor("cod_datacat", false));
          this.anforaSeleccionada = this.anforas[0].cod_datacat;
          this.objAnforaSeleccionada = this.anforas.find(element => element.cod_datacat == this.anforaSeleccionada);
        }
      }, error => console.error(error));
    }
  }

  seleccionarUnidadDespacho(objSeleccionado) {
    this.unidadDespachoSeleccionado = objSeleccionado.target.value;
    if (objSeleccionado.target.value != "") {
      this.objUnidadDespachoSeleccionado = this.lstUnidadDespacho.find(element => element.numUnidadDespacho == objSeleccionado.target.value);
      this.cargarTurnos();
      this.cargarAnforas();
    }
  }

  seleccionarAnfora(objSeleccionado) {
    this.anforaSeleccionada = objSeleccionado.target.value;
    if (objSeleccionado.target.value != "") {
      this.objAnforaSeleccionada = this.anforas.find(element => element.cod_datacat == this.anforaSeleccionada);
    }
  }

  seleccionarTurno(objSeleccionado) {
    this.turnoSeleccionado = objSeleccionado.target.value;
    if (objSeleccionado.target.value != "") {
      this.objTurnoSeleccionado = this.turnos.find(element => element.numTurno == parseInt(this.turnoSeleccionado));
    }
  }

  consultarPaquetesFormados() {
    if (!this.validarDatosDeConsulta()) {
      return false;
    }

    this.tmpPaqueteService.consultarPaquetesFormados(this.objAnforaSeleccionada.cod_datacat,
                                                     this.objTurnoSeleccionado.numTurno,
                                                     this.fechaDesde,
                                                     this.fechaHasta).subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.listPaquetesFormados = result as PaquetesFormados[];
      //if (this.listPaquetesFormados != null && this.listPaquetesFormados != undefined && this.listPaquetesFormados.length > 0) {
      if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.listPaquetesFormados)) {
        this.cargarCalendario(this.listPaquetesFormados);
        this.ufullcalendar.calendar.gotoDate(this.fechaDesde);
      } else {
        this.listPaquetesFormados = [];
        FuncionesGenerales.getInstance().mensajeRegistrosNoEncontrados();
      }
    }, error => console.log(error));
  }

  cargarCalendario(listPaquetesFormados: PaquetesFormados[]) {
    this.listPaquetesFormados = listPaquetesFormados;
    this.ufullcalendar.calendar.removeAllEvents();
    this.ufullcalendar.calendar.addEventSource(this.listPaquetesFormados);
    this.ufullcalendar.calendar.refetchEvents();
  }

  validarDatosDeConsulta() {
    let tituloErrores: string = 'Mensajes de Error: ';
    let mensajeError: String = '';

    if (this.fechaDesde == undefined || this.fechaDesde == null) {
      mensajeError = 'Ingrese fecha de inicio.';
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, mensajeError, "");
      return false;
    }

    if (this.fechaHasta == undefined || this.fechaHasta == null) {
      mensajeError = 'Ingrese fecha de fin.';
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, mensajeError, "");
      return false;
    }

    if (FuncionesGenerales.getInstance().compararFechas(
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaDesde),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaHasta),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 1) {
      mensajeError = 'La fecha de inicio debe ser menor o igual a la fecha fin.';
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, mensajeError, '');
      return false;
    }
    return true;
  }

  eventoSiguienteAtrasCalendario(esAtras: boolean) {
    this.ufullcalendar.calendar.incrementDate({ months: (esAtras ? -1 : 1) });
  }

  eventClick(model) {
    let objStart: Date = model.event.start;
    objStart.setDate(objStart.getDate() + 1);
    this.paqueteFormado = new PaquetesFormados();
    this.paqueteFormado.start = objStart.getFullYear().toString() + "-" +
                                ("00" + (objStart.getMonth() + 1)).slice(-2).toString() + "-" +
                                ("00" + objStart.getDate()).slice(-2).toString();
    this.paqueteFormado.aduana = new Datacatalogo();
    this.paqueteFormado.anfora = new Datacatalogo();
    this.paqueteFormado.aduana = this.objAduanaSeleccionada;
    this.paqueteFormado.anfora = this.objAnforaSeleccionada;
    this.paqueteFormado.title = model.event._def.title;
    this.paqueteFormado.indice = model.event._def.extendedProps.indice;
    this.paqueteFormado.codAnfora = model.event._def.extendedProps.codAnfora;
    this.paqueteFormado.numHorario = model.event._def.extendedProps.numHorario;
    this.paqueteFormado.id = model.event._def.publicId;
    sessionStorage.setItem('paqueteFormado', JSON.stringify(this.paqueteFormado));
    this.router.navigate(['/detalle-paquetes-formados/', JSON.stringify("1")]);
  }
}
