import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute, Params } from '@angular/router';
import { PaquetesFormados } from 'src/app/models/paquetesformados';
import { ConstantesCadenas } from 'src/app/utils/constantescadenas';
import { ResponseManager } from 'src/app/models/responsemanager';
import { ResponseErrorManager } from 'src/app/models/responseerrormanager';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { TmpPaqueteService } from 'src/app/services/tmpPaquete.service';
import { TmpPaquete } from 'src/app/models/TmpPaquete';
import { ConstantesExcepciones } from 'src/app/utils/constantesExcepciones';
import { MatTableDataSource } from '@angular/material';
import { Anfora } from 'src/app/models/anfora';
import { SelectionModel } from '@angular/cdk/collections';
import { ConstantesListas } from 'src/app/utils/constanteslistas';
import { ReportePaquetesService } from 'src/app/services/reportepaquetes.service';
import { ReporteGenerico } from 'src/app/models/reportegenerico';

@Component({
  selector: 'app-detalle-paquetes-formados',
  templateUrl: './detalle-paquetes-formados.component.html',
  styleUrls: ['./detalle-paquetes-formados.component.css']
})
export class DetallePaquetesFormadosComponent implements OnInit {
  paqueteFormado: PaquetesFormados;
  responseManager: ResponseManager;
  responseErrorManager: ResponseErrorManager;
  lstDetallesPaquetes: TmpPaquete[];
  displayedColumns: string[];
  txtTotalDePaquetes: number;
  txtTotalDeCarga: string;
  txtHorario: string;
  txtAnforaCanalRojo: string;
  txtFechaAsignacion: string;
  txtAduana: string;
  selection: SelectionModel<Anfora>;
  funcionesGenerales: FuncionesGenerales;

  constructor(private route: ActivatedRoute,
              private location: Location,
              private tmpPaqueteService: TmpPaqueteService,
              private reportePaquetesService: ReportePaquetesService) { }

  ngOnInit() {
    this.funcionesGenerales = FuncionesGenerales.getInstance();
    this.txtTotalDePaquetes = 0;
    this.txtTotalDeCarga = "0";
    this.txtFechaAsignacion = "";
    this.txtHorario = "";
    this.txtAduana = "";
    this.txtAnforaCanalRojo = "";
    this.selection = new SelectionModel<Anfora>(true, []);
    this.route.params.forEach((params: Params) => {
      if (params['paqueteFormado'] != undefined && params['paqueteFormado'] != null) {
        this.paqueteFormado = JSON.parse(sessionStorage.getItem('paqueteFormado'));
        this.consultaDeclaracionPaquetesFormados(this.paqueteFormado);
      } else {
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    "Mensaje de Error: ",
                                                                    "No hay paquetes formados para este día.", "");
        this.location.back();
      }
    });
  }

  consultaDeclaracionPaquetesFormados(paqueteFormado: PaquetesFormados) {
    let fechaAsignacion: Date = new Date();
    fechaAsignacion.setFullYear(parseInt(paqueteFormado.start.split("-")[0]));
    fechaAsignacion.setMonth(parseInt(paqueteFormado.start.split("-")[1]) - 1);
    fechaAsignacion.setDate(parseInt(paqueteFormado.start.split("-")[2]));
    this.tmpPaqueteService.obtenerDetallesPaquetes(
      paqueteFormado.indice,
      paqueteFormado.numHorario,
      paqueteFormado.codAnfora,
      3, // tipo de consulta para reasignacion en bloque
      fechaAsignacion,
      new Date(), "", 0, ""
    ).subscribe(response => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.lstDetallesPaquetes = response as TmpPaquete[];
      if (this.lstDetallesPaquetes == undefined) {
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    "Mensaje de Error: ", ConstantesExcepciones.EXCEPCION_PAQUETES_NO_ENCONTRADOS, "");
        return false;
      }

      this.lstDetallesPaquetes.sort((n1,n2)=>{return n1.numeroSecuenciaPaqueteAnfora-n2.numeroSecuenciaPaqueteAnfora});
      this.lstDetallesPaquetes.forEach(x => {
       if (x.listaDuasAnfora!=undefined && x.listaDuasAnfora.length>0) {
         x.cargaLaboralPaquete=x.listaDuasAnfora.reduce((acc,obj,) => acc + obj.numeroCargaLaboral, 0);
         x.allSelected = false;
         x.anforaDS = new MatTableDataSource<Anfora>(x.listaDuasAnfora);
       }
       x.selection = new SelectionModel<Anfora>(true, []);
      });
      //this.txtTotalDeCarga = this.validarCargaLaboral(this.lstDetallesPaquetes);
      this.txtTotalDeCarga = ""+this.lstDetallesPaquetes.reduce(
        (acc,obj,) => acc + (obj.numPaquete == 0 || obj.cargaLaboralPaquete == undefined || obj.cargaLaboralPaquete == null ? 0 : obj.cargaLaboralPaquete), 0
      );
      this.txtTotalDeCarga = parseFloat(this.txtTotalDeCarga).toFixed(1);
      this.txtTotalDePaquetes = this.validarTotalPaquetes(this.lstDetallesPaquetes);
      this.txtHorario = paqueteFormado.title.substring(15, 24);
      this.txtAduana = paqueteFormado.aduana.cod_datacat + " - " + paqueteFormado.aduana.des_corta;
      this.txtAnforaCanalRojo = paqueteFormado.anfora.des_corta;
      this.txtFechaAsignacion = FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(fechaAsignacion);
      this.displayedColumns = ConstantesListas.COLUMNAS_GRID_DECLARACIONES_DETALLE_PAQUETE;

      this.selection = new SelectionModel<Anfora>(true, []);
    },
    errorResult => {
      if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
        let responseManager: ResponseManager = new ResponseManager();
        this.responseErrorManager = errorResult as ResponseErrorManager;
        responseManager.cod = errorResult.cod;
        responseManager.errors = [this.responseErrorManager];
        this.responseManager = responseManager;
        this.cargarMensajesDeclaracionPaquetesFormados(this.responseManager);
      } else {
        this.responseManager = errorResult as ResponseManager;
        this.cargarMensajesDeclaracionPaquetesFormados(this.responseManager);
      }
    });
  }

  validarTotalPaquetes(lstDetallesPaquetes: TmpPaquete[]) {
    let totalPaquetes: number = 0;
    for (let i = 0; i < lstDetallesPaquetes.length; i++) {
      if (lstDetallesPaquetes[i].numPaquete != 0) {
        totalPaquetes++;
      }
    }
    return totalPaquetes;
  }

  validarCargaLaboral(lstDetallesPaquetes: TmpPaquete[]) {
    let esCero: boolean = false;
    for (let i = 0; i < lstDetallesPaquetes.length; i++) {
      if (lstDetallesPaquetes[i].cargaLaboralPaquete == undefined ||
          lstDetallesPaquetes[i].cargaLaboralPaquete == null) {
            esCero = true;
            break;
          }
    }

    if (esCero) {
      return 0;
    } else {
      let totalCargaAsignada: number = 0;
      for (let i = 0; i < lstDetallesPaquetes.length; i++) {
        if (lstDetallesPaquetes[i].numPaquete != 0) {
          totalCargaAsignada += lstDetallesPaquetes[i].cargaLaboralPaquete;
        }
      }
      return totalCargaAsignada;
      //return lstDetallesPaquetes.reduce((acc, obj,) => acc + obj.cargaLaboralPaquete, 0);
    }
  }

  cargarMensajesDeclaracionPaquetesFormados(responseManager: ResponseManager) {
    if (responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO ||
        responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                   "Mensajes de Error: ",
                                                                    "",
                                                                    FuncionesGenerales.getInstance().mostrarTablaDeErrores(this.responseManager.errors));
    }
  }

  regresarConsultaPaquetesFormados() {
    this.location.back();
  }

  imprimir() {
    this.exportarPDFExcel(ConstantesCadenas.NOMBRE_REPORTE_PAQUETES_FORMADOS_PDF, ConstantesCadenas.TIPO_MIME_PDF);
  }

  exportarPDFExcel(nombrePaqueteFormado: string, tipoMime: string) {
    let tipoReporte: string = tipoMime == ConstantesCadenas.TIPO_MIME_EXCEL ? ConstantesCadenas.TIPO_REPORTE_XLS : ConstantesCadenas.TIPO_REPORTE_PDF;
    let fechaAsignacion: Date = new Date();
    fechaAsignacion.setFullYear(parseInt(this.paqueteFormado.start.split("-")[0]));
    fechaAsignacion.setMonth(parseInt(this.paqueteFormado.start.split("-")[1]) - 1);
    fechaAsignacion.setDate(parseInt(this.paqueteFormado.start.split("-")[2]));
    this.reportePaquetesService.reportePaquetes(tipoReporte,
                                                this.paqueteFormado.codAnfora,
                                                this.paqueteFormado.numHorario,
                                                this.paqueteFormado.indice,
                                                fechaAsignacion).subscribe(response => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      if (response != undefined && response != null) {
        let strBase64 = FuncionesGenerales.getInstance().base64ToArrayBuffer(response);
        FuncionesGenerales.getInstance().saveByteArray(nombrePaqueteFormado, strBase64, tipoMime);
      } else {
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    "Mensajes de Error: ",
                                                                    "Ocurrio un error, comuníquese con el área de sistemas", '');
      }
    }, errorResult => {
      let error: any = errorResult;
      if (error.error.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
        let responseManager: ResponseManager = new ResponseManager();
        this.responseErrorManager = error.error as ResponseErrorManager;
        responseManager.cod = error.error.cod;
        responseManager.errors = [this.responseErrorManager];
        this.responseManager = responseManager;
        this.cargarMensajesReportePaquetes(this.responseManager);
      } else {
        this.responseManager = error.error as ResponseManager;
        this.cargarMensajesReportePaquetes(this.responseManager);
      }
    });
  }

  cargarMensajesReportePaquetes(responseManager: ResponseManager) {
    if (responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO ||
        responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR ||
        responseManager.cod == "999") {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                   "Mensajes de Error: ",
                                                                    "",
                                                                    FuncionesGenerales.getInstance().mostrarTablaDeErrores(this.responseManager.errors));
    }
  }

  exportar() {
    this.exportarPDFExcel(ConstantesCadenas.NOMBRE_REPORTE_PAQUETES_FORMADOS_XLS, ConstantesCadenas.TIPO_MIME_EXCEL);
  }
}
