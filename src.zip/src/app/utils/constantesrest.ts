export class ConstantesRest {
  static CONTEXTO: string = sessionStorage.getItem("apiEndpoint");
  //environment.apiEndpoint + environment.localContext;
  //sessionStorage.getItem("apiEndpoint");//environment.apiEndpoint + environment.localContext; // "/cl-at-iaingreso-asignacion-ws";
  //Configuracion
  //static URL_LISTAR_REGIMENES: string = ConstantesRest.CONTEXTO + "/configuracion/obtenerregimenes";
  static URL_LISTAR_REGIMENES: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/obtenerregimenes";
  //static URL_LISTAR_ADUANAS: string = ConstantesRest.CONTEXTO + "/configuracion/obteneraduanas?codigoUUOO={0}&roles={1}&filtroSolicitudRF={2}"
  static URL_LISTAR_ADUANAS: string = ConstantesRest.CONTEXTO + "/funcionarios/{0}/aduanas?roles={1}&filtroSolicitudRF={2}";
  //static URL_LISTAR_ANFORAS: string = ConstantesRest.CONTEXTO + "/configuracion/{0}/anforas"
  static URL_LISTAR_ANFORAS: string = ConstantesRest.CONTEXTO + "/unidadesdespacho/{0}/anforas";
  //static URL_LISTAR_GRUPOS_TRABAJO: string = ConstantesRest.CONTEXTO + "/configuracion/obtenergrupos?roles={0}"
  static URL_LISTAR_GRUPOS_TRABAJO: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/grupostrabajo?roles={0}";
  //static URL_LISTAR_UNIDAD_DESPACHO: string = ConstantesRest.CONTEXTO + "/configuracion/obtenerunidadesdespacho?aduana={0}&estado={1}&f={2}";
  static URL_LISTAR_UNIDAD_DESPACHO: string = ConstantesRest.CONTEXTO + "/aduanas/{0}/unidaddespacho?estado={1}&f={2}";
  //static URL_VALIDAR_UNIDAD_DESPACHO: string = ConstantesRest.CONTEXTO + "/configuracion/validarunidaddespacho?numUnidadDespacho={0}&aduana={1}&descripcion={2}&indSorteoZona={3}&fecInicio={4}&fecFin={5}&regimen={6}";
  static URL_VALIDAR_UNIDAD_DESPACHO: string = ConstantesRest.CONTEXTO + "/unidadesdespacho/{0}/validarunidaddespacho?aduana={1}&descripcion={2}&indSorteoZona={3}&fecInicio={4}&fecFin={5}&regimen={6}";
  //static URL_GRABAR_UNIDAD_DESPACHO: string = ConstantesRest.CONTEXTO + "/configuracion/grabarunidaddespacho?c={0}&tk={1}";
  static URL_GRABAR_UNIDAD_DESPACHO: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/grabarunidaddespacho?c={0}&tk={1}";
  //static URL_LISTAR_ZONA: string = ConstantesRest.CONTEXTO + "/configuracion/obtenerzonas?unidad={0}&estado={1}&f={2}";
  static URL_LISTAR_ZONA: string = ConstantesRest.CONTEXTO + "/unidadesdespacho/{0}/zonas?estado={1}&f={2}";
  //static URL_GRABAR_ZONA: string = ConstantesRest.CONTEXTO + "/configuracion/grabarzona";
  static URL_GRABAR_ZONA: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/grabarzona";
  //static URL_LISTAR_TURNO: string = ConstantesRest.CONTEXTO + "/configuracion/obtenerturnos?unidad={0}&estado={1}&fechaVigenteDesde={2}&fechaVigenteHasta={3}&tipoValidacionRango={4}&f={5}";
  static URL_LISTAR_TURNO: string = ConstantesRest.CONTEXTO + "/unidadesdespacho/{0}/turnos?estado={1}&fechaVigenteDesde={2}&fechaVigenteHasta={3}&tipoValidacionRango={4}&indPermanente={5}&f={6}";
  //static URL_GRABAR_TURNO: string = ConstantesRest.CONTEXTO + "/configuracion/grabarturno";
  static URL_GRABAR_TURNO: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/grabarturno";
  //static URL_LISTAR_CRITERIO_ASIGNACION: string = ConstantesRest.CONTEXTO + "/configuracion/obtenercatalogocriterios?unidad={0}&f={1}";
  static URL_LISTAR_CRITERIO_ASIGNACION: string = ConstantesRest.CONTEXTO + "/unidadesdespacho/{0}/criteriosasignacion?f={1}";
  //static URL_GRABAR_CRITERIO_ASIGNACION: string = ConstantesRest.CONTEXTO + "/configuracion/grabarcatalogocriterios?unidad={0}";
  static URL_GRABAR_CRITERIO_ASIGNACION: string = ConstantesRest.CONTEXTO + "/unidadesdespacho/{0}/grabarcriteriosasignacion";
  //static URL_LISTAR_LUGARES_RECONOCIMIENTO: string = ConstantesRest.CONTEXTO + "/configuracion/obtenerlugaresreconocimiento?unidad={0}";
  static URL_LISTAR_LUGARES_RECONOCIMIENTO: string = ConstantesRest.CONTEXTO + "/unidadesdespacho/{0}/lugaresreconocimiento";
  //static URL_GRABAR_LUGARES_RECONOCIMIENTO: string = ConstantesRest.CONTEXTO + "/configuracion/grabarlugaresreconocimiento?unidad={0}";
  static URL_GRABAR_LUGARES_RECONOCIMIENTO: string = ConstantesRest.CONTEXTO + "/unidadesdespacho/{0}/grabarlugaresreconocimiento";


  //Programacion
  //static URL_BUSCAR_FUNCIONARIO: string = ConstantesRest.CONTEXTO + "/programacion/obtenerfuncionarios?aduana={0}&codigo={1}&nombres={2}&grupoTrabajo={3}&filtroFuncionarioPorTurno={4}";
  static URL_BUSCAR_FUNCIONARIO: string = ConstantesRest.CONTEXTO + "/aduanas/{0}/funcionarios?codigo={1}&nombres={2}&grupoTrabajo={3}&filtroFuncionarioPorTurno={4}&regimen={5}";
  //static URL_LISTAR_CATALOGO_FUNCIONARIOS: string = ConstantesRest.CONTEXTO + "/programacion/obtenercatfuncionarios?tipo={0}&unidad={1}&turno={2}&grupoTrabajo={3}&fechaInicio={4}&fechaFin={5}&codigoFuncionario={6}";
  static URL_LISTAR_CATALOGO_FUNCIONARIOS: string = ConstantesRest.CONTEXTO + "/unidadesdespacho/{1}/funcionarios?tipo={0}&turno={2}&grupoTrabajo={3}&fechaInicio={4}&fechaFin={5}&codigoFuncionario={6}";
  //static URL_GRABAR_CATALOGO_FUNCIONARIOS: string = ConstantesRest.CONTEXTO + "/programacion/grabarcatfuncionarios?turno={0}&grupoTrabajo={1}&fechaInicio={2}&fechaFin={3}";
  static URL_GRABAR_CATALOGO_FUNCIONARIOS: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/grabarfuncionarios?turno={0}&grupoTrabajo={1}&fechaInicio={2}&fechaFin={3}";
  //static URL_LISTAR_HORARIO: string = ConstantesRest.CONTEXTO + "/programacion/obtenerhorarios?codAnfora={0}&numTurno={1}&fechaConsulta={2}&tipoConsulta={3}&fechaFin={4}";
  static URL_LISTAR_HORARIO: string = ConstantesRest.CONTEXTO + "/turnos/{1}/horarios?codAnfora={0}&fechaConsulta={2}&tipoConsulta={3}&fechaFin={4}";
  //static URL_GRABAR_SORTEO: string = ConstantesRest.CONTEXTO + "/programacion/grabarsorteo";
  static URL_GRABAR_SORTEO: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/grabarsorteo";
  //############################################No esta en el excel
  //static URL_EXPORTAR_REPORTE_SORTEOS_ASIGNACION: string = ConstantesRest.CONTEXTO + "/programacion/reportesorteoasignacion?tipo={0}&turno={1}&anfora={2}&fechaInicio={3}&fechaFin={4}&f={5}";
  static URL_EXPORTAR_REPORTE_SORTEOS_ASIGNACION: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/reportesorteoasignacion?tipo={0}&turno={1}&anfora={2}&fechaInicio={3}&fechaFin={4}&f={5}";
  //static URL_ASIGNACION_FUNCIONARIOS_ZONA: string = ConstantesRest.CONTEXTO + "/programacion/obtenerfunczona?unidad={0}&mes={1}&anho={2}";
  static URL_ASIGNACION_FUNCIONARIOS_ZONA: string = ConstantesRest.CONTEXTO + "/unidadesdespacho/{0}/obtenerfuncionarioszona?mes={1}&anho={2}";
  //static URL_OBTENER_ASIGNACION_FUNCIONARIOS_ZONA: string = ConstantesRest.CONTEXTO + "/programacion/obtenerasigfunczona/{0}";
  static URL_OBTENER_ASIGNACION_FUNCIONARIOS_ZONA: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/obtenerasignacionfuncionariozona/{0}";
  //static URL_LISTAR_SORTEOS: string = ConstantesRest.CONTEXTO + "/programacion/obtenersorteos?sorteo={0}&turno={1}&anfora={2}&fechaInicio={3}&fechaFin={4}&f={5}";
  static URL_LISTAR_SORTEOS: string = ConstantesRest.CONTEXTO + "/sorteos/{0}/obtenerconfiltros?turno={1}&anfora={2}&fechaInicio={3}&fechaFin={4}&f={5}";
  //static URL_ASIGNAR_FUNCIONARIOS_ALEATORIO: string = ConstantesRest.CONTEXTO + "/programacion/sortearfunczona/{0}";
  static URL_ASIGNAR_FUNCIONARIOS_ALEATORIO: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/sortearfuncionariozona/{0}";
  //static URL_GRABAR_ASIGNACION_FUNCIONARIO_ZONA: string = ConstantesRest.CONTEXTO + "/programacion/grabarfunczona";
  static URL_GRABAR_ASIGNACION_FUNCIONARIO_ZONA: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/grabarfuncionariozona";
  //static URL_REVERTIR_ASIGNACION_FUNCIONARIO_ZONA: string = ConstantesRest.CONTEXTO + "/programacion/revertirfunczona/{0}";
  static URL_REVERTIR_ASIGNACION_FUNCIONARIO_ZONA: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/revertirfuncionariozona/{0}";
  //#############################################No esta en el excel
  //static URL_LISTA_FUNCIONARIO_DISPONIBLES: string = ConstantesRest.CONTEXTO + "/programacion/obtenerfuncdisponibles?turno={0}&fechaAsignacion={1}";
  static URL_LISTA_FUNCIONARIO_DISPONIBLES: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/obtenerfuncionariosdisponibles?turno={0}&fechaAsignacion={1}";
  //static URL_EXPORTAR_REPORTE_CATALOGO_FUNCIONARIOS: string = ConstantesRest.CONTEXTO + "/programacion/exportarfuncionarios?tipo={0}&unidad={1}&turno={2}&grupoTrabajo={3}&fechaInicio={4}&fechaFin={5}&codigoFuncionario={6}";
  static URL_EXPORTAR_REPORTE_CATALOGO_FUNCIONARIOS: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/obtenerreporte?tipo={0}&unidad={1}&turno={2}&grupoTrabajo={3}&fechaInicio={4}&fechaFin={5}&codigoFuncionario={6}";
  //Post ejecucion
  //static URL_OBTENER_DETALLES_PAQUETE: string = ConstantesRest.CONTEXTO + "/postejecucion/obtenerdetpaquete?numSorteo={0}&numHorario={1}&codAnfora={2}&tipoConsulta={3}&fecha={4}&numRucAlmacen={5}&fechaFin={6}&numeroTurno={7}&codigoRegistro={8}";
  static URL_OBTENER_DETALLES_PAQUETE: string = ConstantesRest.CONTEXTO + "/sorteos/{0}/paquetes?numHorario={1}&codAnfora={2}&tipoConsulta={3}&fecha={4}&numRucAlmacen={5}&fechaFin={6}&numeroTurno={7}&codigoRegistro={8}";
  //static URL_OBTENER_DETALLE_ASIGNACION: string = ConstantesRest.CONTEXTO + "/postejecucion/obtenerdetasignacion?codAnfora={0}&numTurno={1}&numHorario={2}&rucAlmacen={3}&codLocalAnexo={4}&codFuncionario={5}&fechaDesde={6}&fechaHasta={7}";
  static URL_OBTENER_DETALLE_ASIGNACION: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/obtenetdetalleasignacion?codAnfora={0}&numTurno={1}&numHorario={2}&rucAlmacen={3}&codLocalAnexo={4}&codFuncionario={5}&fechaDesde={6}&fechaHasta={7}";
  //static URL_GRABAR_OPTIMIZACION_PAQUETES: string = ConstantesRest.CONTEXTO + "/postejecucion/grabarpaquetes?numSorteo={0}&numHorario={1}&fechaFormacionPaquete={2}";
  static URL_GRABAR_OPTIMIZACION_PAQUETES: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/grabarpaquetes?numSorteo={0}&numHorario={1}&fechaFormacionPaquete={2}";
  //static URL_GRABAR_REASIGNACION_PAQUETES_BLOQUE: string = ConstantesRest.CONTEXTO + "/postejecucion/resignarpaquete/{0}";
  static URL_GRABAR_REASIGNACION_PAQUETES_BLOQUE: string = ConstantesRest.CONTEXTO + "/paquetes/{0}/resignaciondepaquete";
  //static URL_CONSULTA_PAQUETES_FORMADOS: string = ConstantesRest.CONTEXTO + "/postejecucion/obtenerpaquetes?anfora={0}&turno={1}&fechaInicio={2}&fechaFin={3}";
  static URL_CONSULTA_PAQUETES_FORMADOS: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/obtenerpaquetes?anfora={0}&turno={1}&fechaInicio={2}&fechaFin={3}";
  //static URL_EXPORTAR_REPORTE_PAQUETES: string = ConstantesRest.CONTEXTO + "/postejecucion/exportarpaquetes?tipoReporte={0}&anfora={1}&horario={2}&numSorteo={3}&fecha={4}";
  static URL_EXPORTAR_REPORTE_PAQUETES: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/exportarpaquetes?tipoReporte={0}&anfora={1}&horario={2}&numSorteo={3}&fecha={4}";
  //static URL_EXPORTAR_REPORTE_ASIGNACION_PAQUETES: string = ConstantesRest.CONTEXTO + "/postejecucion/exportardetasignacion?tipoReporte={0}&codAnfora={1}&numTurno={2}&numHorario={3}&rucAlmacen={4}&codLocalAnexo={5}&codFuncionario={6}&fechaDesde={7}&fechaHasta={8}&numSorteo={9}";
  static URL_EXPORTAR_REPORTE_ASIGNACION_PAQUETES: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/exportarreporteasignaciones?tipoReporte={0}&codAnfora={1}&numTurno={2}&numHorario={3}&rucAlmacen={4}&codLocalAnexo={5}&codFuncionario={6}&fechaDesde={7}&fechaHasta={8}&numSorteo={9}";
  //Manual
  //static URL_LISTAR_OPERACIONES_MANUALES: string = ConstantesRest.CONTEXTO + "/manual/obteneropermanuales?tipo={0}&roles={1}";
  static URL_LISTAR_OPERACIONES_MANUALES: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/obtenertipooperacion?tipo={0}&roles={1}";
  //static URL_LISTAR_REGIMENES_OPERACION: string = ConstantesRest.CONTEXTO + "/manual/obtenerregimenesoper?tipoOperacion={0}";
  static URL_LISTAR_REGIMENES_OPERACION: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/obteneroperacionregimenes?tipoOperacion={0}";
  //static URL_OBTENER_SERVICIO_REST: string = ConstantesRest.CONTEXTO + "/manual/obtenerservicio?tipoOperacion={0}&tipoServicio={1}";
  static URL_OBTENER_SERVICIO_REST: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/obtenerservicio?tipoOperacion={0}&tipoServicio={1}";

  static _inicializarDesarrollo(esDesarrollo: true) {
    if (esDesarrollo) {
      this.URL_LISTAR_REGIMENES = ConstantesRest.CONTEXTO + "/configuracion/obtenerregimenes";
      this.URL_LISTAR_ADUANAS = ConstantesRest.CONTEXTO + "/configuracion/obteneraduanas?codigoUUOO={0}&roles={1}&filtroSolicitudRF={2}";
      this.URL_LISTAR_ANFORAS = ConstantesRest.CONTEXTO + "/configuracion/{0}/anforas";
      this.URL_LISTAR_GRUPOS_TRABAJO = ConstantesRest.CONTEXTO + "/configuracion/obtenergrupos?roles={0}";
      this.URL_LISTAR_UNIDAD_DESPACHO = ConstantesRest.CONTEXTO + "/configuracion/obtenerunidadesdespacho?aduana={0}&estado={1}&f={2}";
      this.URL_VALIDAR_UNIDAD_DESPACHO = ConstantesRest.CONTEXTO + "/configuracion/validarunidaddespacho?numUnidadDespacho={0}&aduana={1}&descripcion={2}&indSorteoZona={3}&fecInicio={4}&fecFin={5}&regimen={6}";
      this.URL_GRABAR_UNIDAD_DESPACHO = ConstantesRest.CONTEXTO + "/configuracion/grabarunidaddespacho?c={0}&tk={1}";
      this.URL_LISTAR_ZONA = ConstantesRest.CONTEXTO + "/configuracion/obtenerzonas?unidad={0}&estado={1}&f={2}";
      this.URL_GRABAR_ZONA = ConstantesRest.CONTEXTO + "/configuracion/grabarzona";
      this.URL_LISTAR_TURNO = ConstantesRest.CONTEXTO + "/configuracion/obtenerturnos?unidad={0}&estado={1}&fechaVigenteDesde={2}&fechaVigenteHasta={3}&tipoValidacionRango={4}&indPermanente={5}&f={6}";
      this.URL_GRABAR_TURNO = ConstantesRest.CONTEXTO + "/configuracion/grabarturno";
      this.URL_LISTAR_CRITERIO_ASIGNACION = ConstantesRest.CONTEXTO + "/configuracion/obtenercatalogocriterios?unidad={0}&f={1}";
      this.URL_GRABAR_CRITERIO_ASIGNACION = ConstantesRest.CONTEXTO + "/configuracion/grabarcatalogocriterios?unidad={0}";
      this.URL_LISTAR_LUGARES_RECONOCIMIENTO = ConstantesRest.CONTEXTO + "/configuracion/obtenerlugaresreconocimiento?unidad={0}";
      this.URL_GRABAR_LUGARES_RECONOCIMIENTO = ConstantesRest.CONTEXTO + "/configuracion/grabarlugaresreconocimiento?unidad={0}";
      //Programacion
      this.URL_BUSCAR_FUNCIONARIO = ConstantesRest.CONTEXTO + "/programacion/obtenerfuncionarios?aduana={0}&codigo={1}&nombres={2}&grupoTrabajo={3}&filtroFuncionarioPorTurno={4}&regimen={5}";
      this.URL_LISTAR_CATALOGO_FUNCIONARIOS = ConstantesRest.CONTEXTO + "/programacion/obtenercatfuncionarios?tipo={0}&unidad={1}&turno={2}&grupoTrabajo={3}&fechaInicio={4}&fechaFin={5}&codigoFuncionario={6}";
      this.URL_GRABAR_CATALOGO_FUNCIONARIOS = ConstantesRest.CONTEXTO + "/programacion/grabarcatfuncionarios?turno={0}&grupoTrabajo={1}&fechaInicio={2}&fechaFin={3}";
      this.URL_LISTAR_HORARIO = ConstantesRest.CONTEXTO + "/programacion/obtenerhorarios?codAnfora={0}&numTurno={1}&fechaConsulta={2}&tipoConsulta={3}&fechaFin={4}";
      this.URL_GRABAR_SORTEO = ConstantesRest.CONTEXTO + "/programacion/grabarsorteo";
      this.URL_EXPORTAR_REPORTE_SORTEOS_ASIGNACION = ConstantesRest.CONTEXTO + "/programacion/reportesorteoasignacion?tipo={0}&turno={1}&anfora={2}&fechaInicio={3}&fechaFin={4}&f={5}";
      this.URL_ASIGNACION_FUNCIONARIOS_ZONA = ConstantesRest.CONTEXTO + "/programacion/obtenerfunczona?unidad={0}&mes={1}&anho={2}";
      this.URL_OBTENER_ASIGNACION_FUNCIONARIOS_ZONA = ConstantesRest.CONTEXTO + "/programacion/obtenerasigfunczona/{0}";
      this.URL_LISTAR_SORTEOS = ConstantesRest.CONTEXTO + "/programacion/obtenersorteos?sorteo={0}&turno={1}&anfora={2}&fechaInicio={3}&fechaFin={4}&f={5}";
      this.URL_ASIGNAR_FUNCIONARIOS_ALEATORIO = ConstantesRest.CONTEXTO + "/programacion/sortearfunczona/{0}";
      this.URL_GRABAR_ASIGNACION_FUNCIONARIO_ZONA = ConstantesRest.CONTEXTO + "/programacion/grabarfunczona";
      this.URL_REVERTIR_ASIGNACION_FUNCIONARIO_ZONA = ConstantesRest.CONTEXTO + "/programacion/revertirfunczona/{0}";
      this.URL_LISTA_FUNCIONARIO_DISPONIBLES = ConstantesRest.CONTEXTO + "/programacion/obtenerfuncdisponibles?turno={0}&fechaAsignacion={1}";
      this.URL_EXPORTAR_REPORTE_CATALOGO_FUNCIONARIOS = ConstantesRest.CONTEXTO + "/programacion/exportarfuncionarios?tipo={0}&unidad={1}&turno={2}&grupoTrabajo={3}&fechaInicio={4}&fechaFin={5}&codigoFuncionario={6}";
      //Post ejecucion
      this.URL_OBTENER_DETALLES_PAQUETE = ConstantesRest.CONTEXTO + "/postejecucion/obtenerdetpaquete?numSorteo={0}&numHorario={1}&codAnfora={2}&tipoConsulta={3}&fecha={4}&numRucAlmacen={5}&fechaFin={6}&numeroTurno={7}&codigoRegistro={8}";
      this.URL_OBTENER_DETALLE_ASIGNACION = ConstantesRest.CONTEXTO + "/postejecucion/obtenerdetasignacion?codAnfora={0}&numTurno={1}&numHorario={2}&rucAlmacen={3}&codLocalAnexo={4}&codFuncionario={5}&fechaDesde={6}&fechaHasta={7}";
      this.URL_GRABAR_OPTIMIZACION_PAQUETES = ConstantesRest.CONTEXTO + "/postejecucion/grabarpaquetes?numSorteo={0}&numHorario={1}&fechaFormacionPaquete={2}";
      this.URL_GRABAR_REASIGNACION_PAQUETES_BLOQUE = ConstantesRest.CONTEXTO + "/postejecucion/resignarpaquete/{0}";
      this.URL_CONSULTA_PAQUETES_FORMADOS = ConstantesRest.CONTEXTO + "/postejecucion/obtenerpaquetes?anfora={0}&turno={1}&fechaInicio={2}&fechaFin={3}";
      this.URL_EXPORTAR_REPORTE_PAQUETES = ConstantesRest.CONTEXTO + "/postejecucion/exportarpaquetes?tipoReporte={0}&anfora={1}&horario={2}&numSorteo={3}&fecha={4}";
      this.URL_EXPORTAR_REPORTE_ASIGNACION_PAQUETES = ConstantesRest.CONTEXTO + "/postejecucion/exportardetasignacion?tipoReporte={0}&codAnfora={1}&numTurno={2}&numHorario={3}&rucAlmacen={4}&codLocalAnexo={5}&codFuncionario={6}&fechaDesde={7}&fechaHasta={8}&numSorteo={9}";
      //Manual
      this.URL_LISTAR_OPERACIONES_MANUALES = ConstantesRest.CONTEXTO + "/manual/obteneropermanuales?tipo={0}&roles={1}";
      this.URL_LISTAR_REGIMENES_OPERACION = ConstantesRest.CONTEXTO + "/manual/obtenerregimenesoper?tipoOperacion={0}";
      this.URL_OBTENER_SERVICIO_REST = ConstantesRest.CONTEXTO + "/manual/obtenerservicio?tipoOperacion={0}&tipoServicio={1}";
    }
  }
  constructor () { }
}
//Descomentar para las pruebas en desarrollo
//Comentar cuando se genera el build para produccion
//ConstantesRest._inicializarDesarrollo(true);
